package com.example

import android.Manifest
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.os.Build
import android.os.Bundle
import android.os.IBinder
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.Bedtime
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.service.ResonancePlaybackService
import com.example.ui.components.EchoThemeDialog
import com.example.ui.screens.*
import com.example.ui.theme.*
import com.example.viewmodel.ResonanceViewModel
import com.example.viewmodel.ScreenTab
import kotlinx.coroutines.flow.StateFlow

class MainActivity : ComponentActivity() {

    private val viewModel: ResonanceViewModel by viewModels()
    private var playbackService: ResonancePlaybackService? = null
    private var isBound = false

    private val connection = object : ServiceConnection {
        override fun onServiceConnected(className: ComponentName, service: IBinder) {
            val binder = service as ResonancePlaybackService.LocalBinder
            playbackService = binder.getService()
            isBound = true
        }

        override fun onServiceDisconnected(arg0: ComponentName) {
            isBound = false
            playbackService = null
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Bind Playback Service
        val serviceIntent = Intent(this, ResonancePlaybackService::class.java)
        bindService(serviceIntent, connection, Context.BIND_AUTO_CREATE)

        setContent {
            val echoThemeSettings by viewModel.echoThemeSettings.collectAsState()
            val isThemeDialogOpen by viewModel.isThemeDialogOpen.collectAsState()

            ResonanceTheme(themeSettings = echoThemeSettings) {
                val currentTab by viewModel.currentTab.collectAsState()
                val currentTrack by viewModel.audioEngine.currentTrack.collectAsState()
                val isPlaying by viewModel.audioEngine.isPlaying.collectAsState()
                val sleepTimer by viewModel.audioEngine.sleepTimer.collectAsState()

                // Request Audio and Notification Permissions on Compose start
                val permissionLauncher = rememberLauncherForActivityResult(
                    ActivityResultContracts.RequestMultiplePermissions()
                ) { permissions ->
                    val audioGranted = permissions[Manifest.permission.READ_MEDIA_AUDIO] == true ||
                            permissions[Manifest.permission.READ_EXTERNAL_STORAGE] == true
                    if (audioGranted) {
                        viewModel.refreshLibraryScan()
                    }
                }

                LaunchedEffect(Unit) {
                    val perms = mutableListOf<String>()
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                        perms.add(Manifest.permission.READ_MEDIA_AUDIO)
                        perms.add(Manifest.permission.POST_NOTIFICATIONS)
                    } else {
                        perms.add(Manifest.permission.READ_EXTERNAL_STORAGE)
                    }
                    permissionLauncher.launch(perms.toTypedArray())
                }

                // Update Lock Screen / Notification whenever track or play status changes, or minute ticks (prevent binder IPC lag)
                val sleepMinutes = if (sleepTimer.isActive) sleepTimer.remainingSeconds / 60 else null
                LaunchedEffect(currentTrack, isPlaying, sleepTimer.isActive, sleepMinutes) {
                    val track = currentTrack
                    if (track != null && isPlaying) {
                        // Binding alone is tied to the Activity lifecycle. Start the service as well
                        // so playback and its notification can survive leaving the app.
                        val serviceIntent = Intent(this@MainActivity, ResonancePlaybackService::class.java)
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                            startForegroundService(serviceIntent)
                        } else {
                            startService(serviceIntent)
                        }
                    }
                    playbackService?.updateNotification(
                        track = track,
                        isPlaying = isPlaying,
                        sleepRemainingMin = sleepMinutes
                    )
                }

                // Handle Hardware Back Button
                BackHandler(enabled = currentTab != ScreenTab.HOME) {
                    viewModel.selectTab(ScreenTab.HOME)
                }

                Scaffold(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(echoThemeSettings.backgroundStyle.color),
                    topBar = {
                        if (currentTab != ScreenTab.NOW_PLAYING) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(echoThemeSettings.backgroundStyle.color)
                                    .windowInsetsPadding(WindowInsets.statusBars)
                                    .padding(horizontal = 14.dp, vertical = 6.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier
                                            .size(30.dp)
                                            .clip(CircleShape)
                                            .background(echoThemeSettings.accentGlowColor),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.GraphicEq,
                                            contentDescription = null,
                                            tint = echoThemeSettings.accentColor,
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = "Echo",
                                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                        color = Color.White
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(6.dp))
                                            .background(Color(0xFF141926))
                                            .padding(horizontal = 6.dp, vertical = 2.dp)
                                    ) {
                                        Text(
                                            text = echoThemeSettings.activePresetName.substringBefore('(').trim(),
                                            style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp),
                                            color = echoThemeSettings.accentColor
                                        )
                                    }
                                }

                                // Echo Theme & Appearance Button
                                IconButton(
                                    onClick = { viewModel.isThemeDialogOpen.value = true },
                                    modifier = Modifier
                                        .size(36.dp)
                                        .clip(CircleShape)
                                        .background(Color(0xFF121724))
                                        .border(1.dp, echoThemeSettings.accentColor.copy(alpha = 0.5f), CircleShape)
                                        .testTag("open_echo_theme_dialog_btn")
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Palette,
                                        contentDescription = "Echo Themes",
                                        tint = echoThemeSettings.accentColor,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }
                        }
                    },
                    bottomBar = {
                        if (currentTab != ScreenTab.NOW_PLAYING) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(echoThemeSettings.backgroundStyle.color)
                                    .windowInsetsPadding(WindowInsets.navigationBars)
                                    .padding(bottom = 6.dp)
                            ) {
                                // Persistent Floating Mini Player
                                AnimatedVisibility(
                                    visible = currentTrack != null,
                                    enter = slideInVertically(initialOffsetY = { it }) + fadeIn(),
                                    exit = slideOutVertically(targetOffsetY = { it }) + fadeOut()
                                ) {
                                    currentTrack?.let { track ->
                                        Surface(
                                            shape = RoundedCornerShape(22.dp),
                                            color = if (echoThemeSettings.isLiquidGlassEnabled) LiquidGlassSurface else DarkSurface2,
                                            border = androidx.compose.foundation.BorderStroke(1.dp, HairlineBorder),
                                            shadowElevation = 8.dp,
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(horizontal = 14.dp, vertical = 4.dp)
                                                .clickable { viewModel.selectTab(ScreenTab.NOW_PLAYING) }
                                        ) {
                                            Column {
                                                Row(
                                                    modifier = Modifier
                                                        .fillMaxWidth()
                                                        .padding(horizontal = 12.dp, vertical = 8.dp),
                                                    verticalAlignment = Alignment.CenterVertically
                                                ) {
                                                    Box(
                                                        modifier = Modifier
                                                            .size(42.dp)
                                                            .clip(RoundedCornerShape(12.dp))
                                                            .background(echoThemeSettings.accentGlowColor),
                                                        contentAlignment = Alignment.Center
                                                    ) {
                                                        Icon(
                                                            imageVector = Icons.Default.MusicNote,
                                                            contentDescription = null,
                                                            tint = echoThemeSettings.accentColor,
                                                            modifier = Modifier.size(24.dp)
                                                        )
                                                    }

                                                    Spacer(modifier = Modifier.width(12.dp))

                                                    Column(modifier = Modifier.weight(1f)) {
                                                        Text(
                                                            text = track.title,
                                                            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                                                            color = TextPrimary,
                                                            maxLines = 1,
                                                            overflow = TextOverflow.Ellipsis
                                                        )
                                                        Text(
                                                            text = "${track.artist} • ${track.format}",
                                                            style = MaterialTheme.typography.labelSmall,
                                                            color = echoThemeSettings.accentColor,
                                                            maxLines = 1,
                                                            overflow = TextOverflow.Ellipsis
                                                        )
                                                    }

                                                    com.example.ui.components.FlowerPlayButton(
                                                        isPlaying = isPlaying,
                                                        onClick = { viewModel.audioEngine.togglePlayPause() },
                                                        size = 44.dp,
                                                        containerColor = Color.White,
                                                        contentColor = Color.Black,
                                                        testTag = "mini_player_play_pause"
                                                    )

                                                    Spacer(modifier = Modifier.width(4.dp))

                                                    IconButton(
                                                        onClick = { viewModel.playNextTrack() },
                                                        modifier = Modifier.size(36.dp)
                                                    ) {
                                                        Icon(
                                                            imageVector = Icons.Default.SkipNext,
                                                            contentDescription = "Next",
                                                            tint = TextPrimary,
                                                            modifier = Modifier.size(22.dp)
                                                        )
                                                    }
                                                }

                                                // Mini Progress Bar on bottom of card (isolated to prevent recompositions)
                                                MiniPlayerProgressBar(
                                                    positionFlow = viewModel.audioEngine.currentPositionMs,
                                                    durationFlow = viewModel.audioEngine.durationMs,
                                                    accentColor = echoThemeSettings.accentColor
                                                )
                                            }
                                        }
                                    }
                                }

                                // Floating Dock Navigation Bar
                                Surface(
                                    shape = RoundedCornerShape(28.dp),
                                    color = if (echoThemeSettings.isLiquidGlassEnabled) LiquidGlassSurface else DarkSurface2,
                                    border = androidx.compose.foundation.BorderStroke(1.dp, HairlineBorder),
                                    shadowElevation = 12.dp,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 16.dp, vertical = 4.dp)
                                ) {
                                    NavigationBar(
                                        containerColor = Color.Transparent,
                                        tonalElevation = 0.dp,
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(58.dp)
                                    ) {
                                        NavigationBarItem(
                                            selected = currentTab == ScreenTab.HOME,
                                            onClick = { viewModel.selectTab(ScreenTab.HOME) },
                                            icon = {
                                                Icon(imageVector = Icons.Default.Home, contentDescription = "Home")
                                            },
                                            label = { Text("Home", fontSize = 10.sp, fontWeight = FontWeight.SemiBold) },
                                            colors = navItemColors(echoThemeSettings.accentColor),
                                            modifier = Modifier.testTag("nav_home_tab")
                                        )

                                        NavigationBarItem(
                                            selected = currentTab == ScreenTab.SEARCH,
                                            onClick = { viewModel.selectTab(ScreenTab.SEARCH) },
                                            icon = {
                                                Icon(imageVector = Icons.Default.Search, contentDescription = "Search")
                                            },
                                            label = { Text("Search", fontSize = 10.sp, fontWeight = FontWeight.SemiBold) },
                                            colors = navItemColors(echoThemeSettings.accentColor),
                                            modifier = Modifier.testTag("nav_search_tab")
                                        )

                                        NavigationBarItem(
                                            selected = currentTab == ScreenTab.LIBRARY,
                                            onClick = { viewModel.selectTab(ScreenTab.LIBRARY) },
                                            icon = {
                                                Icon(imageVector = Icons.Default.LibraryMusic, contentDescription = "Library")
                                            },
                                            label = { Text("Library", fontSize = 10.sp, fontWeight = FontWeight.SemiBold) },
                                            colors = navItemColors(echoThemeSettings.accentColor),
                                            modifier = Modifier.testTag("nav_library_tab")
                                        )
                                    }
                                }
                            }
                        }
                    }
                ) { innerPadding ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                    ) {
                        when (currentTab) {
                            ScreenTab.HOME -> HomeScreen(viewModel = viewModel)
                            ScreenTab.SEARCH -> SearchScreen(viewModel = viewModel)
                            ScreenTab.LIBRARY -> LibraryScreen(viewModel = viewModel)
                            ScreenTab.NOW_PLAYING -> NowPlayingScreen(viewModel = viewModel)
                        }
                    }
                }

                // Echo Theme & Appearance Studio Dialog
                if (isThemeDialogOpen) {
                    EchoThemeDialog(
                        themeSettings = echoThemeSettings,
                        onUpdateTheme = { viewModel.updateThemeSettings(it) },
                        onDismiss = { viewModel.isThemeDialogOpen.value = false }
                    )
                }

                // Sleep Timer Dialog (Modal on-demand option)
                val isSleepTimerDialogOpen by viewModel.isSleepTimerDialogOpen.collectAsState()
                if (isSleepTimerDialogOpen) {
                    com.example.ui.components.SleepTimerDialog(
                        sleepTimer = sleepTimer,
                        accentColor = echoThemeSettings.accentColor,
                        onSetSleepTimer = { mins, finishLast ->
                            viewModel.audioEngine.setSleepTimer(mins, finishLast)
                            viewModel.isSleepTimerDialogOpen.value = false
                        },
                        onCancelSleepTimer = {
                            viewModel.audioEngine.cancelSleepTimer()
                            viewModel.isSleepTimerDialogOpen.value = false
                        },
                        onDismiss = { viewModel.isSleepTimerDialogOpen.value = false }
                    )
                }

                // Global Long-Press Track Action Menu (Cut, Rename, Delete, etc.)
                val selectedTrackForActions by viewModel.selectedTrackForActions.collectAsState()
                val trimmingTrack by viewModel.trimmingTrack.collectAsState()
                val renamingTrack by viewModel.renamingTrack.collectAsState()
                val deletingTrack by viewModel.deletingTrack.collectAsState()

                selectedTrackForActions?.let { track ->
                    com.example.ui.components.TrackActionBottomSheet(
                        track = track,
                        accentColor = echoThemeSettings.accentColor,
                        onCutAudio = { viewModel.openTrimmer(track) },
                        onRename = { viewModel.openRenamer(track) },
                        onDelete = { viewModel.openDeleter(track) },
                        onEditTags = {
                            viewModel.isTagEditorOpen.value = true
                            viewModel.selectTrackForActions(null)
                        },
                        onInspectInfo = {
                            viewModel.inspectTrack(track)
                            viewModel.selectTrackForActions(null)
                        },
                        onPlayNext = {
                            viewModel.enqueueNext(track)
                            viewModel.selectTrackForActions(null)
                            android.widget.Toast.makeText(this@MainActivity, "Playing next: ${track.title}", android.widget.Toast.LENGTH_SHORT).show()
                        },
                        onAddToQueue = {
                            viewModel.addToQueue(1, track)
                            viewModel.selectTrackForActions(null)
                            android.widget.Toast.makeText(this@MainActivity, "Added to Queue 1 (Main)", android.widget.Toast.LENGTH_SHORT).show()
                        },
                        onDismiss = { viewModel.selectTrackForActions(null) }
                    )
                }

                // Clideo Audio Cutter Dialog
                trimmingTrack?.let { track ->
                    com.example.ui.components.ClideoAudioCutterDialog(
                        track = track,
                        accentColor = echoThemeSettings.accentColor,
                        onExportTrim = { config ->
                            viewModel.trimTrack(track, config) { trimmed ->
                                android.widget.Toast.makeText(this@MainActivity, "Exported trimmed track: ${trimmed.title}", android.widget.Toast.LENGTH_LONG).show()
                            }
                        },
                        onDismiss = { viewModel.closeTrimmer() }
                    )
                }

                // Rename Music File Dialog
                renamingTrack?.let { track ->
                    com.example.ui.components.RenameTrackDialog(
                        track = track,
                        accentColor = echoThemeSettings.accentColor,
                        onConfirmRename = { newTitle, newFileName ->
                            viewModel.renameTrack(track, newTitle, newFileName)
                            android.widget.Toast.makeText(this@MainActivity, "Renamed to $newFileName", android.widget.Toast.LENGTH_SHORT).show()
                        },
                        onDismiss = { viewModel.closeRenamer() }
                    )
                }

                // Delete Music File Confirmation Dialog
                deletingTrack?.let { track ->
                    com.example.ui.components.DeleteTrackDialog(
                        track = track,
                        onConfirmDelete = {
                            viewModel.deleteTrack(track)
                            android.widget.Toast.makeText(this@MainActivity, "Permanently deleted ${track.title}", android.widget.Toast.LENGTH_SHORT).show()
                        },
                        onDismiss = { viewModel.closeDeleter() }
                    )
                }
            }
        }
    }

    @Composable
    private fun navItemColors(accentColor: Color) = NavigationBarItemDefaults.colors(
        selectedIconColor = Color.Black,
        selectedTextColor = accentColor,
        indicatorColor = accentColor,
        unselectedIconColor = TextSecondary,
        unselectedTextColor = TextMuted
    )

    override fun onDestroy() {
        if (isBound) {
            unbindService(connection)
            isBound = false
        }
        super.onDestroy()
    }
}

@Composable
private fun MiniPlayerProgressBar(
    positionFlow: StateFlow<Long>,
    durationFlow: StateFlow<Long>,
    accentColor: Color,
    modifier: Modifier = Modifier
) {
    val currentPos by positionFlow.collectAsState()
    val totalDur by durationFlow.collectAsState()
    val progress = if (totalDur > 0) (currentPos.toFloat() / totalDur.toFloat()).coerceIn(0f, 1f) else 0f
    LinearProgressIndicator(
        progress = { progress },
        modifier = modifier
            .fillMaxWidth()
            .height(2.dp),
        color = accentColor,
        trackColor = DarkSurface3
    )
}
