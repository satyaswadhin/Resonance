package com.example.model

import androidx.compose.ui.graphics.Color
import com.example.ui.theme.*

enum class BackgroundStyle(val displayName: String, val color: Color) {
    AMOLED_BLACK("Pure AMOLED (#000000)", AmoledBlack),
    MIDNIGHT_OBSIDIAN("Midnight Obsidian (#05080E)", MidnightObsidian),
    CHARCOAL_SLATE("Charcoal Slate (#0A0D14)", CharcoalSlate),
    VELVET_WINE("Velvet Wine (#0C0306)", VelvetWine),
    SAPPHIRE_OBSIDIAN("Sapphire Obsidian (#030711)", SapphireObsidian),
    EMERALD_OBSIDIAN("Emerald Obsidian (#020A05)", EmeraldObsidian)
}

data class ColorCombinationPreset(
    val name: String,
    val primaryColor: Color,
    val glowColor: Color,
    val description: String
)

val ECHO_PRESETS = listOf(
    ColorCombinationPreset("Champagne Gold", ChampagneGold, ChampagneGoldGlow, "Audiophile DAP & Sony Walkman signature gold"),
    ColorCombinationPreset("Echo Coral", EchoCoral, EchoCoralGlow, "Warm glowing rose-coral master"),
    ColorCombinationPreset("Cyber Cyan", CyberCyan, CyberCyanGlow, "Studio DAC & precision monitor cyan"),
    ColorCombinationPreset("High-Res Emerald", EmeraldNeon, EmeraldGlow, "Master DSD high-resolution green"),
    ColorCombinationPreset("Amethyst Violet", AmethystViolet, AmethystGlow, "Luminous deep acoustic purple"),
    ColorCombinationPreset("Solar Amber", SolarAmber, SolarAmberGlow, "Warm analog vacuum-tube filament"),
    ColorCombinationPreset("Brushed Sapphire", CobaltBlue, CobaltGlow, "Deep electric precision blue"),
    ColorCombinationPreset("Hot Magenta", HotMagenta, HotMagentaGlow, "Radiant punchy synthwave magenta")
)

data class EchoThemeSettings(
    val accentColor: Color = EchoCoral,
    val accentGlowColor: Color = EchoCoralGlow,
    val activePresetName: String = "Echo Coral",
    val customHue: Float = 345f,
    val backgroundStyle: BackgroundStyle = BackgroundStyle.AMOLED_BLACK,
    val isLiquidGlassEnabled: Boolean = true,
    val isWavyProgressEnabled: Boolean = true,
    val dynamicAlbumArtColor: Boolean = false
)
