package com.example.model

import android.net.Uri

data class Track(
    val id: Long = 0,
    val uri: Uri,
    val filePath: String,
    val title: String,
    val artist: String,
    val artists: List<String> = emptyList(), // Parsed multi-value artists
    val album: String,
    val albumArtist: String = "",
    val durationMs: Long,
    val format: String = "FLAC",
    val sampleRateHz: Int = 44100,
    val bitDepth: Int = 16,
    val bitrateKbps: Int = 320,
    val trackNumber: Int = 1,
    val discNumber: Int = 1,
    val year: Int = 2024,
    val genres: List<String> = emptyList(),
    val replayGainTrackDb: Float = 0f,
    val replayGainAlbumDb: Float = 0f,
    val albumArtUri: Uri? = null,
    val playCount: Int = 0,
    val skipCount: Int = 0,
    val lastPlayedTimestamp: Long = 0L,
    val cueSheetPath: String? = null,
    val cueTrackOffsetMs: Long = 0L,
    val isVirtualCueTrack: Boolean = false
) {
    val formattedDuration: String
        get() {
            val totalSecs = durationMs / 1000
            val minutes = totalSecs / 60
            val seconds = totalSecs % 60
            return "%d:%02d".format(minutes, seconds)
        }

    val audioQualityBadge: String
        get() {
            return if (bitDepth >= 24 || sampleRateHz >= 96000) {
                "Hi-Res • %d-bit/%dkHz %s".format(bitDepth, sampleRateHz / 1000, format)
            } else {
                "%s • %dkbps".format(format, bitrateKbps)
            }
        }
}

enum class PlayerSkin(val displayName: String) {
    SLEEP_BEDTIME("Bedtime Sleep"),
    AMOLED_GLASS("AMOLED Glass"),
    RETRO_VINYL("Retro Vinyl"),
    RETRO_CASSETTE("Analog Cassette"),
    CHRONOGRAPH("Chronograph")
}

data class FolderNode(
    val path: String,
    val name: String,
    val isDirectory: Boolean,
    val trackCount: Int = 0,
    val isWhitelisted: Boolean = true,
    val isBlacklisted: Boolean = false
)

data class FilterSettings(
    val minDurationSecs: Int = 30,
    val whitelistedDirectories: Set<String> = emptySet(),
    val blacklistedDirectories: Set<String> = setOf(
        "/WhatsApp", "/Notifications", "/Ringtones", "/Voice Notes", "/Recordings"
    )
)

data class LrcLine(
    val timeMs: Long,
    val text: String,
    val words: List<LrcWord> = emptyList()
)

data class LrcWord(
    val timeMs: Long,
    val text: String
)

data class AbLoop(
    val startMs: Long? = null,
    val endMs: Long? = null,
    val isEnabled: Boolean = false
)

enum class FilterType {
    PEAK, LOW_SHELF, HIGH_SHELF, BAND_PASS
}

data class ParametricBand(
    val id: String,
    val frequencyHz: Float,
    val gainDb: Float,
    val qFactor: Float,
    val filterType: FilterType = FilterType.PEAK,
    val isEnabled: Boolean = true
)

data class EqualizerConfig(
    val isEnabled: Boolean = true,
    val preampDb: Float = 0f,
    // 10 standard graphic frequencies: 31, 62, 125, 250, 500, 1k, 2k, 4k, 8k, 16k
    val graphicBandGainsDb: Map<Int, Float> = mapOf(
        31 to 0f, 62 to 0f, 125 to 0f, 250 to 0f, 500 to 0f,
        1000 to 0f, 2000 to 0f, 4000 to 0f, 8000 to 0f, 16000 to 0f
    ),
    val parametricBands: List<ParametricBand> = listOf(
        ParametricBand("band-sub", 80f, 1.5f, 1.2f, FilterType.LOW_SHELF),
        ParametricBand("band-presence", 3200f, 2.0f, 1.5f, FilterType.PEAK),
        ParametricBand("band-air", 12000f, 1.0f, 0.7f, FilterType.HIGH_SHELF)
    ),
    val bassBoostStrength: Int = 0, // 0 - 1000
    val playbackPitch: Float = 1.0f, // 0.5x to 2.0x
    val playbackTempo: Float = 1.0f, // 0.25x to 3.0x
    val linkPitchTempo: Boolean = false,
    val replayGainEnabled: Boolean = true,
    val targetReplayGainDb: Float = -14.0f,
    val channelBalance: Float = 0.0f, // -1.0 (Left) to +1.0 (Right)
    val crossfadeDurationSecs: Int = 3,
    val gaplessEnabled: Boolean = true,
    val activeAutoEqProfileName: String? = null
)

data class SleepTimerConfig(
    val isActive: Boolean = false,
    val targetTimestampMs: Long = 0L,
    val totalDurationMinutes: Int = 30,
    val remainingSeconds: Int = 0,
    val finishLastSongFirst: Boolean = true,
    val fadeOutDurationSeconds: Int = 60,
    val isCurrentlyFading: Boolean = false
)

data class Album(
    val title: String,
    val artist: String,
    val trackCount: Int,
    val year: Int,
    val albumArtUri: Uri?,
    val tracks: List<Track>
)

data class ArtistGroup(
    val name: String,
    val trackCount: Int,
    val albumsCount: Int,
    val tracks: List<Track>
)

enum class RepeatMode {
    OFF, ALL, ONE
}

data class MultiQueue(
    val id: Int,
    val name: String,
    val tracks: List<Track> = emptyList(),
    val currentIndex: Int = 0
)

data class SmartPlaylistRule(
    val id: Long = 0,
    val name: String,
    val genreFilter: String = "",
    val artistFilter: String = "",
    val minPlayCount: Int = 0,
    val minBitrateKbps: Int = 0,
    val minYear: Int = 0,
    val sortBy: String = "lastPlayed" // "playCount", "title", "artist", "lastPlayed"
)
