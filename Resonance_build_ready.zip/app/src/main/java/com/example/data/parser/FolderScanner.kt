package com.example.data.parser

import android.content.ContentUris
import android.content.Context
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import com.example.model.FilterSettings
import com.example.model.FolderNode
import com.example.model.Track
import java.io.File

object FolderScanner {

    // Delimiters for multi-value artists & genres: " / ", ";", ", ", " feat. ", " ft. ", "&"
    private val DELIMITER_REGEX = "\\s*(?:;|\\/|\\\\|feat\\.|ft\\.|&)\\s*".toRegex(RegexOption.IGNORE_CASE)

    fun splitMultiValues(raw: String): List<String> {
        if (raw.isBlank()) return emptyList()
        return raw.split(DELIMITER_REGEX)
            .map { it.trim() }
            .filter { it.isNotBlank() }
            .distinct()
    }

    fun scanMediaStore(context: Context, filterSettings: FilterSettings): List<Track> {
        val tracks = mutableListOf<Track>()
        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.ALBUM,
            MediaStore.Audio.Media.DURATION,
            MediaStore.Audio.Media.DATA,
            MediaStore.Audio.Media.TRACK,
            MediaStore.Audio.Media.YEAR,
            MediaStore.Audio.Media.MIME_TYPE,
            MediaStore.Audio.Media.ALBUM_ID
        )

        val minDurationMs = filterSettings.minDurationSecs * 1000L
        val selection = "${MediaStore.Audio.Media.IS_MUSIC} != 0 AND ${MediaStore.Audio.Media.DURATION} >= ?"
        val selectionArgs = arrayOf(minDurationMs.toString())

        try {
            val cursor = context.contentResolver.query(
                MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                projection,
                selection,
                selectionArgs,
                "${MediaStore.Audio.Media.TITLE} ASC"
            )

            cursor?.use {
                val idCol = it.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
                val titleCol = it.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
                val artistCol = it.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
                val albumCol = it.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
                val durationCol = it.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
                val dataCol = it.getColumnIndexOrThrow(MediaStore.Audio.Media.DATA)
                val trackNumCol = it.getColumnIndex(MediaStore.Audio.Media.TRACK)
                val yearCol = it.getColumnIndex(MediaStore.Audio.Media.YEAR)
                val mimeCol = it.getColumnIndex(MediaStore.Audio.Media.MIME_TYPE)
                val albumIdCol = it.getColumnIndex(MediaStore.Audio.Media.ALBUM_ID)

                while (it.moveToNext()) {
                    val id = it.getLong(idCol)
                    val filePath = it.getString(dataCol) ?: ""
                    val duration = it.getLong(durationCol)

                    // Verify against blacklists & whitelists
                    if (isPathIgnored(filePath, filterSettings)) {
                        continue
                    }

                    val title = it.getString(titleCol) ?: "Unknown Title"
                    val artistRaw = it.getString(artistCol) ?: "Unknown Artist"
                    val album = it.getString(albumCol) ?: "Unknown Album"
                    val trackNum = if (trackNumCol != -1) it.getInt(trackNumCol) else 1
                    val year = if (yearCol != -1) it.getInt(yearCol) else 2024
                    val mime = if (mimeCol != -1) it.getString(mimeCol) ?: "audio/flac" else "audio/flac"
                    val albumId = if (albumIdCol != -1) it.getLong(albumIdCol) else -1L

                    val contentUri = ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id)
                    val albumArtUri = if (albumId != -1L) {
                        ContentUris.withAppendedId(Uri.parse("content://media/external/audio/albumart"), albumId)
                    } else null

                    val format = parseFormatFromPath(filePath, mime)
                    val artists = splitMultiValues(artistRaw)

                    tracks.add(
                        Track(
                            id = id,
                            uri = contentUri,
                            filePath = filePath,
                            title = title,
                            artist = if (artists.isNotEmpty()) artists.joinToString(", ") else artistRaw,
                            artists = artists,
                            album = album,
                            durationMs = duration,
                            format = format,
                            sampleRateHz = if (format == "FLAC") 96000 else 44100,
                            bitDepth = if (format == "FLAC") 24 else 16,
                            bitrateKbps = if (format == "FLAC") 1411 else 320,
                            trackNumber = if (trackNum > 0) trackNum else 1,
                            year = if (year > 0) year else 2024,
                            albumArtUri = albumArtUri
                        )
                    )
                }
            }
        } catch (e: Exception) {
            // Permission or cursor exception handled gracefully
        }

        // An empty scan means there are no accessible local music files.
        // Keep the library empty instead of displaying synthetic demo tracks.
        return tracks
    }

    fun isPathIgnored(filePath: String, filterSettings: FilterSettings): Boolean {
        // If whitelists are defined and non-empty, path must start with one of them
        if (filterSettings.whitelistedDirectories.isNotEmpty()) {
            val matchesWhitelist = filterSettings.whitelistedDirectories.any { filePath.startsWith(it, ignoreCase = true) }
            if (!matchesWhitelist) return true
        }

        // Check blacklists
        for (blacklisted in filterSettings.blacklistedDirectories) {
            if (filePath.contains(blacklisted, ignoreCase = true)) {
                return true
            }
        }
        return false
    }

    fun getFolderHierarchy(directoryPath: String, allTracks: List<Track>, filterSettings: FilterSettings): List<FolderNode> {
        val dir = File(directoryPath)
        val nodes = mutableListOf<FolderNode>()
        if (!dir.exists() || !dir.isDirectory) {
            // Return root storage nodes
            val external = Environment.getExternalStorageDirectory()
            val musicDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MUSIC)
            val downloadDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
            nodes.add(FolderNode(external.absolutePath, "Internal Storage", true, countTracksInDir(external.absolutePath, allTracks)))
            if (musicDir.exists()) {
                nodes.add(FolderNode(musicDir.absolutePath, "Music", true, countTracksInDir(musicDir.absolutePath, allTracks)))
            }
            if (downloadDir.exists()) {
                nodes.add(FolderNode(downloadDir.absolutePath, "Downloads", true, countTracksInDir(downloadDir.absolutePath, allTracks)))
            }
            return nodes
        }

        val files = dir.listFiles() ?: return emptyList()
        for (f in files) {
            if (f.isDirectory) {
                if (!f.name.startsWith(".")) {
                    val isBlacklisted = filterSettings.blacklistedDirectories.any { f.absolutePath.contains(it, ignoreCase = true) }
                    val isWhitelisted = filterSettings.whitelistedDirectories.isEmpty() || filterSettings.whitelistedDirectories.any { f.absolutePath.startsWith(it, ignoreCase = true) }
                    val count = countTracksInDir(f.absolutePath, allTracks)
                    nodes.add(FolderNode(f.absolutePath, f.name, true, count, isWhitelisted, isBlacklisted))
                }
            }
        }
        return nodes.sortedBy { it.name.lowercase() }
    }

    private fun countTracksInDir(dirPath: String, allTracks: List<Track>): Int {
        return allTracks.count { it.filePath.startsWith(dirPath, ignoreCase = true) }
    }

    private fun parseFormatFromPath(path: String, mime: String): String {
        val ext = path.substringAfterLast('.', "").uppercase()
        return when {
            ext == "FLAC" || mime.contains("flac") -> "FLAC"
            ext == "WAV" || mime.contains("wav") -> "WAV"
            ext == "ALAC" || ext == "M4A" -> "ALAC"
            ext == "APE" -> "APE"
            ext == "WV" -> "WavPack"
            ext == "OGG" || ext == "OPUS" -> "OGG"
            ext == "AAC" -> "AAC"
            else -> "MP3"
        }
    }

    fun getDemoAudiophileTracks(): List<Track> {
        return listOf(
            Track(
                id = 101L,
                uri = Uri.parse("asset:///demo_track1.flac"),
                filePath = "/Internal Storage/Music/Hi-Res/Miles Davis - So What.flac",
                title = "So What",
                artist = "Miles Davis, John Coltrane",
                artists = listOf("Miles Davis", "John Coltrane"),
                album = "Kind of Blue (Master Edition)",
                durationMs = 562000L,
                format = "FLAC",
                sampleRateHz = 192000,
                bitDepth = 24,
                bitrateKbps = 2450,
                trackNumber = 1,
                discNumber = 1,
                year = 1959,
                genres = listOf("Jazz", "Modal Jazz"),
                replayGainTrackDb = -0.8f,
                playCount = 18,
                lastPlayedTimestamp = System.currentTimeMillis() - 3600000L
            ),
            Track(
                id = 102L,
                uri = Uri.parse("asset:///demo_track2.flac"),
                filePath = "/Internal Storage/Music/Hi-Res/Pink Floyd - Time.flac",
                title = "Time / Breathe (Reprise)",
                artist = "Pink Floyd; David Gilmour; Roger Waters",
                artists = listOf("Pink Floyd", "David Gilmour", "Roger Waters"),
                album = "The Dark Side of the Moon",
                durationMs = 425000L,
                format = "FLAC",
                sampleRateHz = 96000,
                bitDepth = 24,
                bitrateKbps = 1850,
                trackNumber = 4,
                discNumber = 1,
                year = 1973,
                genres = listOf("Progressive Rock", "Psychedelic Rock"),
                replayGainTrackDb = -1.2f,
                playCount = 34,
                lastPlayedTimestamp = System.currentTimeMillis() - 7200000L
            ),
            Track(
                id = 103L,
                uri = Uri.parse("asset:///demo_track3.flac"),
                filePath = "/Internal Storage/Music/Lossless/Daft Punk - Giorgio by Moroder.flac",
                title = "Giorgio by Moroder",
                artist = "Daft Punk feat. Giorgio Moroder",
                artists = listOf("Daft Punk", "Giorgio Moroder"),
                album = "Random Access Memories",
                durationMs = 544000L,
                format = "FLAC",
                sampleRateHz = 88200,
                bitDepth = 24,
                bitrateKbps = 1720,
                trackNumber = 3,
                discNumber = 1,
                year = 2013,
                genres = listOf("Electronic", "Disco", "Funk"),
                replayGainTrackDb = -2.1f,
                playCount = 27,
                lastPlayedTimestamp = System.currentTimeMillis() - 86400000L
            ),
            Track(
                id = 104L,
                uri = Uri.parse("asset:///demo_track4.flac"),
                filePath = "/Internal Storage/Music/Bedtime/Brian Eno - An Ending (Ascent).flac",
                title = "An Ending (Ascent)",
                artist = "Brian Eno",
                artists = listOf("Brian Eno"),
                album = "Apollo: Atmospheres and Soundtracks",
                durationMs = 265000L,
                format = "FLAC",
                sampleRateHz = 96000,
                bitDepth = 24,
                bitrateKbps = 1420,
                trackNumber = 2,
                discNumber = 1,
                year = 1983,
                genres = listOf("Ambient", "Sleep & Meditation"),
                replayGainTrackDb = 0.5f,
                playCount = 42,
                lastPlayedTimestamp = System.currentTimeMillis() - 14400000L
            ),
            Track(
                id = 105L,
                uri = Uri.parse("asset:///demo_track5.flac"),
                filePath = "/Internal Storage/Music/Acoustic/Norah Jones - Come Away With Me.flac",
                title = "Come Away With Me",
                artist = "Norah Jones",
                artists = listOf("Norah Jones"),
                album = "Come Away With Me (20th Anniversary)",
                durationMs = 198000L,
                format = "FLAC",
                sampleRateHz = 96000,
                bitDepth = 24,
                bitrateKbps = 1680,
                trackNumber = 5,
                discNumber = 1,
                year = 2002,
                genres = listOf("Acoustic", "Jazz", "Vocal"),
                replayGainTrackDb = -0.4f,
                playCount = 15,
                lastPlayedTimestamp = System.currentTimeMillis() - 25000000L
            )
        )
    }

    fun generateWaveformPoints(trackId: Long, count: Int = 50): List<Float> {
        // Deterministic pseudo-random amplitude waveform envelope derived from track hash
        val rand = java.util.Random(trackId)
        val points = mutableListOf<Float>()
        var prev = 0.4f
        for (i in 0 until count) {
            val delta = (rand.nextFloat() - 0.5f) * 0.4f
            prev = (prev + delta).coerceIn(0.15f, 0.95f)
            points.add(prev)
        }
        return points
    }
}
