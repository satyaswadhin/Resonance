package com.example.data.parser

import android.content.Context
import android.net.Uri
import com.example.model.Track
import java.io.File

object Id3Editor {

    data class EditableMetadata(
        val title: String,
        val artist: String,
        val album: String,
        val albumArtist: String,
        val genre: String,
        val year: Int,
        val trackNumber: Int,
        val discNumber: Int,
        val customArtUri: Uri? = null
    )

    fun applyMetadataToTrack(track: Track, metadata: EditableMetadata): Track {
        val parsedArtists = FolderScanner.splitMultiValues(metadata.artist)
        val parsedGenres = FolderScanner.splitMultiValues(metadata.genre)

        return track.copy(
            title = metadata.title.ifBlank { track.title },
            artist = metadata.artist.ifBlank { track.artist },
            artists = if (parsedArtists.isNotEmpty()) parsedArtists else listOf(metadata.artist),
            album = metadata.album.ifBlank { track.album },
            albumArtist = metadata.albumArtist,
            year = if (metadata.year > 0) metadata.year else track.year,
            trackNumber = if (metadata.trackNumber > 0) metadata.trackNumber else track.trackNumber,
            discNumber = if (metadata.discNumber > 0) metadata.discNumber else track.discNumber,
            genres = if (parsedGenres.isNotEmpty()) parsedGenres else track.genres,
            albumArtUri = metadata.customArtUri ?: track.albumArtUri
        )
    }

    fun batchUpdateTracks(tracks: List<Track>, commonAlbum: String?, commonArtist: String?, commonGenre: String?, commonYear: Int?): List<Track> {
        return tracks.map { track ->
            var updated = track
            if (!commonAlbum.isNullOrBlank()) updated = updated.copy(album = commonAlbum)
            if (!commonArtist.isNullOrBlank()) {
                val artists = FolderScanner.splitMultiValues(commonArtist)
                updated = updated.copy(artist = commonArtist, artists = artists)
            }
            if (!commonGenre.isNullOrBlank()) {
                val genres = FolderScanner.splitMultiValues(commonGenre)
                updated = updated.copy(genres = genres)
            }
            if (commonYear != null && commonYear > 0) updated = updated.copy(year = commonYear)
            updated
        }
    }
}
