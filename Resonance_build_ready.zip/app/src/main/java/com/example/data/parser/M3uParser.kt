package com.example.data.parser

import android.content.Context
import android.net.Uri
import com.example.model.Track
import java.io.BufferedReader
import java.io.File
import java.io.InputStream
import java.io.InputStreamReader

object M3uParser {

    fun parseM3u(inputStream: InputStream): List<String> {
        val pathsOrUris = mutableListOf<String>()
        BufferedReader(InputStreamReader(inputStream, Charsets.UTF_8)).useLines { lines ->
            for (line in lines) {
                val trimmed = line.trim()
                if (trimmed.isEmpty() || trimmed.startsWith("#")) {
                    continue
                }
                pathsOrUris.add(trimmed)
            }
        }
        return pathsOrUris
    }

    fun exportToM3u8(playlistName: String, tracks: List<Track>, outputFile: File): Boolean {
        return try {
            val sb = StringBuilder()
            sb.append("#EXTM3U\n")
            sb.append("#PLAYLIST:$playlistName\n")
            for (track in tracks) {
                sb.append("#EXTINF:${track.durationMs / 1000},${track.artist} - ${track.title}\n")
                sb.append("${track.filePath}\n")
            }
            outputFile.writeText(sb.toString(), Charsets.UTF_8)
            true
        } catch (e: Exception) {
            false
        }
    }
}
