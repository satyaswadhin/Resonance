package com.example.data.parser

import android.net.Uri
import com.example.model.Track
import java.io.BufferedReader
import java.io.File
import java.io.InputStream
import java.io.InputStreamReader

object CueSheetParser {

    data class CueTrackInfo(
        val trackNumber: Int,
        val title: String,
        val performer: String,
        val offsetMs: Long
    )

    fun parseCueSheet(inputStream: InputStream, audioFile: File): List<Track> {
        val tracks = mutableListOf<CueTrackInfo>()
        var albumTitle = audioFile.nameWithoutExtension
        var albumPerformer = "Unknown Artist"

        var currentTrackNumber = 1
        var currentTitle = ""
        var currentPerformer = ""
        var currentOffsetMs = 0L
        var insideTrack = false

        BufferedReader(InputStreamReader(inputStream)).useLines { lines ->
            for (rawLine in lines) {
                val line = rawLine.trim()
                when {
                    line.startsWith("TITLE ", ignoreCase = true) && !insideTrack -> {
                        albumTitle = line.removePrefix("TITLE ").removePrefix("title ").trim('"', ' ')
                    }
                    line.startsWith("PERFORMER ", ignoreCase = true) && !insideTrack -> {
                        albumPerformer = line.removePrefix("PERFORMER ").removePrefix("performer ").trim('"', ' ')
                    }
                    line.startsWith("TRACK ", ignoreCase = true) -> {
                        if (insideTrack) {
                            tracks.add(CueTrackInfo(currentTrackNumber, currentTitle, currentPerformer, currentOffsetMs))
                        }
                        insideTrack = true
                        val parts = line.split("\\s+".toRegex())
                        currentTrackNumber = parts.getOrNull(1)?.toIntOrNull() ?: (tracks.size + 1)
                        currentTitle = "Track $currentTrackNumber"
                        currentPerformer = albumPerformer
                        currentOffsetMs = 0L
                    }
                    line.startsWith("TITLE ", ignoreCase = true) && insideTrack -> {
                        currentTitle = line.substring(6).trim('"', ' ')
                    }
                    line.startsWith("PERFORMER ", ignoreCase = true) && insideTrack -> {
                        currentPerformer = line.substring(10).trim('"', ' ')
                    }
                    line.startsWith("INDEX 01", ignoreCase = true) -> {
                        val parts = line.split("\\s+".toRegex())
                        val timeStr = parts.lastOrNull() ?: "00:00:00"
                        currentOffsetMs = parseIndexTimeToMs(timeStr)
                    }
                }
            }
            if (insideTrack) {
                tracks.add(CueTrackInfo(currentTrackNumber, currentTitle, currentPerformer, currentOffsetMs))
            }
        }

        val resultTracks = mutableListOf<Track>()
        val totalFileDurationMs = 3600000L // 1 hour default fallback if not known

        for (i in tracks.indices) {
            val curr = tracks[i]
            val nextOffset = if (i + 1 < tracks.size) tracks[i + 1].offsetMs else (curr.offsetMs + 240000L)
            val durationMs = (nextOffset - curr.offsetMs).coerceAtLeast(1000L)

            resultTracks.add(
                Track(
                    id = (audioFile.absolutePath.hashCode().toLong() shl 16) + curr.trackNumber,
                    uri = Uri.fromFile(audioFile),
                    filePath = audioFile.absolutePath,
                    title = curr.title,
                    artist = curr.performer.ifEmpty { albumPerformer },
                    artists = listOf(curr.performer.ifEmpty { albumPerformer }),
                    album = albumTitle,
                    durationMs = durationMs,
                    format = "FLAC (CUE)",
                    sampleRateHz = 96000,
                    bitDepth = 24,
                    bitrateKbps = 1411,
                    trackNumber = curr.trackNumber,
                    cueSheetPath = audioFile.absolutePath + ".cue",
                    cueTrackOffsetMs = curr.offsetMs,
                    isVirtualCueTrack = true
                )
            )
        }
        return resultTracks
    }

    private fun parseIndexTimeToMs(time: String): Long {
        // Format: MM:SS:FF (where FF is frames, 75 frames = 1 second)
        val parts = time.split(":")
        if (parts.size != 3) return 0L
        val min = parts[0].toLongOrNull() ?: 0L
        val sec = parts[1].toLongOrNull() ?: 0L
        val frames = parts[2].toLongOrNull() ?: 0L
        return (min * 60 * 1000) + (sec * 1000) + ((frames * 1000) / 75)
    }
}
