package com.example.data.database

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface TrackDao {
    @Query("SELECT * FROM tracks ORDER BY title ASC")
    fun getAllTracks(): Flow<List<TrackEntity>>

    @Query("SELECT * FROM tracks WHERE isFavorite = 1 ORDER BY title ASC")
    fun getFavoriteTracks(): Flow<List<TrackEntity>>

    @Query("SELECT * FROM tracks WHERE filePath = :path LIMIT 1")
    suspend fun getTrackByPath(path: String): TrackEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdateTrack(track: TrackEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdateTracks(tracks: List<TrackEntity>)

    @Query("UPDATE tracks SET playCount = playCount + 1, lastPlayedTimestamp = :timestamp WHERE filePath = :path")
    suspend fun incrementPlayCount(path: String, timestamp: Long)

    @Query("UPDATE tracks SET skipCount = skipCount + 1 WHERE filePath = :path")
    suspend fun incrementSkipCount(path: String)

    @Query("UPDATE tracks SET isFavorite = :isFavorite WHERE filePath = :path")
    suspend fun setFavorite(path: String, isFavorite: Boolean)

    @Query("SELECT * FROM tracks ORDER BY playCount DESC LIMIT 20")
    fun getTopPlayedTracks(): Flow<List<TrackEntity>>

    @Query("SELECT * FROM tracks ORDER BY lastPlayedTimestamp DESC LIMIT 30")
    fun getRecentlyPlayedTracks(): Flow<List<TrackEntity>>

    @Query("DELETE FROM tracks WHERE filePath = :path")
    suspend fun deleteTrackByPath(path: String)
}

@Dao
interface FolderRuleDao {
    @Query("SELECT * FROM folder_rules")
    fun getAllRules(): Flow<List<FolderRuleEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRule(rule: FolderRuleEntity)

    @Query("DELETE FROM folder_rules WHERE folderPath = :folderPath")
    suspend fun deleteRule(folderPath: String)
}

@Dao
interface SmartPlaylistDao {
    @Query("SELECT * FROM smart_playlists ORDER BY name ASC")
    fun getAllSmartPlaylists(): Flow<List<SmartPlaylistEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPlaylist(playlist: SmartPlaylistEntity): Long

    @Delete
    suspend fun deletePlaylist(playlist: SmartPlaylistEntity)
}

@Dao
interface AnalyticsDao {
    @Insert
    suspend fun recordPlayEvent(event: PlayHistoryEntity)

    @Query("SELECT * FROM play_history ORDER BY timestamp DESC LIMIT 100")
    fun getRecentHistory(): Flow<List<PlayHistoryEntity>>

    @Query("SELECT SUM(durationListenedMs) FROM play_history")
    fun getTotalListeningTimeMs(): Flow<Long?>

    @Query("SELECT COUNT(*) FROM play_history")
    fun getTotalTracksPlayed(): Flow<Int>
}

@Database(
    entities = [
        TrackEntity::class,
        FolderRuleEntity::class,
        SmartPlaylistEntity::class,
        PlayHistoryEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class ResonanceDatabase : RoomDatabase() {
    abstract fun trackDao(): TrackDao
    abstract fun folderRuleDao(): FolderRuleDao
    abstract fun smartPlaylistDao(): SmartPlaylistDao
    abstract fun analyticsDao(): AnalyticsDao
}
