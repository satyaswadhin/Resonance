package com.example.data.database

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "tracks")
data class TrackEntity(
    @PrimaryKey val filePath: String,
    val title: String,
    val artist: String,
    val album: String,
    val durationMs: Long,
    val format: String,
    val sampleRateHz: Int,
    val bitDepth: Int,
    val bitrateKbps: Int,
    val trackNumber: Int,
    val discNumber: Int,
    val year: Int,
    val genres: String, // Delimited by ;
    val replayGainTrackDb: Float,
    val replayGainAlbumDb: Float,
    val playCount: Int = 0,
    val skipCount: Int = 0,
    val lastPlayedTimestamp: Long = 0L,
    val isFavorite: Boolean = false,
    val cueSheetPath: String? = null
)

@Entity(tableName = "folder_rules")
data class FolderRuleEntity(
    @PrimaryKey val folderPath: String,
    val isWhitelisted: Boolean,
    val isBlacklisted: Boolean
)

@Entity(tableName = "smart_playlists")
data class SmartPlaylistEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val genreFilter: String,
    val artistFilter: String,
    val minPlayCount: Int,
    val minBitrateKbps: Int,
    val minYear: Int,
    val sortBy: String
)

@Entity(tableName = "play_history")
data class PlayHistoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val filePath: String,
    val title: String,
    val artist: String,
    val timestamp: Long,
    val durationListenedMs: Long
)
