package com.example.data.parser

import com.example.model.ParametricBand
import com.example.model.FilterType

data class AutoEqProfile(
    val name: String,
    val description: String,
    val graphicBandGains: Map<Int, Float>,
    val parametricBands: List<ParametricBand> = emptyList(),
    val targetDeviceType: String = "All" // "Wired 3.5mm", "USB DAC", "Bluetooth", "Speaker"
)

object AutoEqParser {

    val BUILTIN_PROFILES = listOf(
        AutoEqProfile(
            name = "Harman Target (Audiophile)",
            description = "Sub-bass elevation with transparent mids and smoothed treble response",
            graphicBandGains = mapOf(
                31 to 4.5f, 62 to 4.0f, 125 to 2.2f, 250 to 0.5f, 500 to 0.0f,
                1000 to 0.0f, 2000 to 1.8f, 4000 to 2.5f, 8000 to 1.2f, 16000 to -1.0f
            ),
            targetDeviceType = "Wired 3.5mm"
        ),
        AutoEqProfile(
            name = "Studio Reference Flat",
            description = "Uncolored, linear monitoring for pristine high-resolution FLAC mastering",
            graphicBandGains = mapOf(
                31 to 0.0f, 62 to 0.0f, 125 to 0.0f, 250 to 0.0f, 500 to 0.0f,
                1000 to 0.0f, 2000 to 0.0f, 4000 to 0.0f, 8000 to 0.0f, 16000 to 0.0f
            ),
            targetDeviceType = "USB DAC"
        ),
        AutoEqProfile(
            name = "Analog Tube Warmth",
            description = "Rich 2nd-harmonic mid-bass weight and silky rolled-off highs",
            graphicBandGains = mapOf(
                31 to 2.8f, 62 to 3.2f, 125 to 2.5f, 250 to 1.0f, 500 to 0.5f,
                1000 to 0.0f, 2000 to -0.5f, 4000 to -1.2f, 8000 to -2.0f, 16000 to -3.5f
            ),
            targetDeviceType = "Bluetooth"
        ),
        AutoEqProfile(
            name = "Acoustic Vocal Clarity",
            description = "Enhanced presence zone for intimate vocals, folk, and classical strings",
            graphicBandGains = mapOf(
                31 to -1.0f, 62 to -0.5f, 125 to 0.0f, 250 to 0.5f, 500 to 1.5f,
                1000 to 2.5f, 2000 to 3.0f, 4000 to 2.0f, 8000 to 1.5f, 16000 to 0.5f
            ),
            targetDeviceType = "Speaker"
        ),
        AutoEqProfile(
            name = "Deep Bass Impact",
            description = "Punchy low-end extension without muddying midrange separation",
            graphicBandGains = mapOf(
                31 to 6.5f, 62 to 5.5f, 125 to 3.5f, 250 to 1.5f, 500 to 0.0f,
                1000 to -0.5f, 2000 to 0.0f, 4000 to 1.0f, 8000 to 2.0f, 16000 to 1.5f
            ),
            targetDeviceType = "Wired 3.5mm"
        )
    )

    fun parseAutoEqText(text: String, profileName: String = "Imported AutoEQ"): AutoEqProfile {
        val targetFreqs = listOf(31, 62, 125, 250, 500, 1000, 2000, 4000, 8000, 16000)
        val gains = mutableMapOf<Int, Float>()
        for (f in targetFreqs) gains[f] = 0f

        val lines = text.lines()
        for (line in lines) {
            val trimmed = line.trim()
            if (trimmed.startsWith("GraphicEQ:", ignoreCase = true)) {
                val data = trimmed.removePrefix("GraphicEQ:").trim()
                val pairs = data.split(";")
                for (pair in pairs) {
                    val tokens = pair.trim().split("\\s+".toRegex())
                    if (tokens.size >= 2) {
                        val freq = tokens[0].toFloatOrNull() ?: continue
                        val gain = tokens[1].toFloatOrNull() ?: continue
                        // map to closest standard graphic band
                        val closest = targetFreqs.minByOrNull { Math.abs(it - freq) }
                        if (closest != null && Math.abs(closest - freq) < (closest * 0.6f)) {
                            gains[closest] = gain.coerceIn(-15f, 15f)
                        }
                    }
                }
            } else if (trimmed.contains(",") && !trimmed.startsWith("#") && !trimmed.startsWith("freq")) {
                // CSV line: freq,gain
                val parts = trimmed.split(",")
                val freq = parts.getOrNull(0)?.trim()?.toFloatOrNull() ?: continue
                val gain = parts.getOrNull(1)?.trim()?.toFloatOrNull() ?: continue
                val closest = targetFreqs.minByOrNull { Math.abs(it - freq) }
                if (closest != null && Math.abs(closest - freq) < (closest * 0.5f)) {
                    gains[closest] = gain.coerceIn(-15f, 15f)
                }
            }
        }

        return AutoEqProfile(
            name = profileName,
            description = "Imported custom AutoEQ curve",
            graphicBandGains = gains
        )
    }
}
