package com.example.data.parser

import com.example.model.LrcLine
import com.example.model.LrcWord
import java.io.File
import java.util.regex.Pattern

object LrcParser {

    private val LINE_TAG_PATTERN = Pattern.compile("\\[(\\d{2}):(\\d{2})(?:\\.(\\d{2,3}))?\\]")
    private val WORD_TAG_PATTERN = Pattern.compile("<(\\d{2}):(\\d{2})(?:\\.(\\d{2,3}))?>([^<]+)")

    fun parse(content: String, offsetMs: Long = 0L): List<LrcLine> {
        val lines = mutableListOf<LrcLine>()
        val rawLines = content.lines()

        for (rawLine in rawLines) {
            val trimmed = rawLine.trim()
            if (trimmed.isEmpty() || trimmed.startsWith("[ti:") || trimmed.startsWith("[ar:") ||
                trimmed.startsWith("[al:") || trimmed.startsWith("[by:") || trimmed.startsWith("[offset:")
            ) {
                continue
            }

            val matcher = LINE_TAG_PATTERN.matcher(trimmed)
            if (matcher.find()) {
                val min = matcher.group(1)?.toLongOrNull() ?: 0L
                val sec = matcher.group(2)?.toLongOrNull() ?: 0L
                val fraction = matcher.group(3)
                val millis = when (fraction?.length) {
                    2 -> fraction.toLong() * 10
                    3 -> fraction.toLong()
                    else -> 0L
                }
                val lineTimeMs = (min * 60 * 1000) + (sec * 1000) + millis + offsetMs

                val remainingText = trimmed.substring(matcher.end()).trim()

                // Check for word-by-word tags <mm:ss.xx>word
                val words = mutableListOf<LrcWord>()
                val wordMatcher = WORD_TAG_PATTERN.matcher(remainingText)
                var hasWords = false
                while (wordMatcher.find()) {
                    hasWords = true
                    val wMin = wordMatcher.group(1)?.toLongOrNull() ?: 0L
                    val wSec = wordMatcher.group(2)?.toLongOrNull() ?: 0L
                    val wFrac = wordMatcher.group(3)
                    val wMillis = when (wFrac?.length) {
                        2 -> wFrac.toLong() * 10
                        3 -> wFrac.toLong()
                        else -> 0L
                    }
                    val wordTimeMs = (wMin * 60 * 1000) + (wSec * 1000) + wMillis + offsetMs
                    val wordContent = wordMatcher.group(4) ?: ""
                    words.add(LrcWord(wordTimeMs, wordContent))
                }

                val cleanText = if (hasWords) {
                    words.joinToString("") { it.text }
                } else {
                    remainingText
                }

                if (cleanText.isNotBlank()) {
                    lines.add(LrcLine(lineTimeMs.coerceAtLeast(0L), cleanText, words))
                }
            }
        }

        return lines.sortedBy { it.timeMs }
    }

    fun loadFromFile(audioFilePath: String): List<LrcLine>? {
        val audioFile = File(audioFilePath)
        val lrcFile = File(audioFile.parentFile, "${audioFile.nameWithoutExtension}.lrc")
        return if (lrcFile.exists() && lrcFile.canRead()) {
            try {
                parse(lrcFile.readText(Charsets.UTF_8))
            } catch (e: Exception) {
                null
            }
        } else {
            null
        }
    }

    fun formatToLrcString(lines: List<LrcLine>): String {
        val sb = StringBuilder()
        sb.append("[ti:Resonance Synced Lyrics]\n")
        sb.append("[re:Resonance Pure Offline Audio Player]\n")
        for (line in lines) {
            val totalSec = line.timeMs / 1000
            val min = totalSec / 60
            val sec = totalSec % 60
            val hundredths = (line.timeMs % 1000) / 10
            sb.append(String.format("[%02d:%02d.%02d]%s\n", min, sec, hundredths, line.text))
        }
        return sb.toString()
    }

    fun saveToFile(audioFilePath: String, lines: List<LrcLine>): Boolean {
        return try {
            val audioFile = File(audioFilePath)
            val lrcFile = File(audioFile.parentFile, "${audioFile.nameWithoutExtension}.lrc")
            lrcFile.writeText(formatToLrcString(lines), Charsets.UTF_8)
            true
        } catch (e: Exception) {
            false
        }
    }
}
