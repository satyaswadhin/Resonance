package com.example.viewmodel

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.room.Room
import com.example.data.database.PlayHistoryEntity
import com.example.data.database.ResonanceDatabase
import com.example.data.database.SmartPlaylistEntity
import com.example.data.parser.*
import com.example.engine.ResonanceAudioEngine
import com.example.model.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import com.example.util.AudioTrimmer
import com.example.util.TrimConfig
import java.io.File

enum class ScreenTab {
    HOME,
    SEARCH,
    LIBRARY,
    NOW_PLAYING
}

enum class LibraryCategory(val title: String) {
    TRACKS("Tracks"),
    FOLDERS("Folders"),
    ALBUMS("Albums"),
    ARTISTS("Artists"),
    PLAYLISTS("Playlists"),
    GENRES("Genres")
}

class ResonanceViewModel(application: Application) : AndroidViewModel(application) {

    private val db = Room.databaseBuilder(
        application,
        ResonanceDatabase::class.java,
        "resonance_music_db"
    ).fallbackToDestructiveMigration().build()

    val audioEngine = ResonanceAudioEngine.getInstance(application)

    // Navigation & Skin State (Echo Music Player Home tab default)
    private val _currentTab = MutableStateFlow(ScreenTab.HOME)
    val currentTab: StateFlow<ScreenTab> = _currentTab.asStateFlow()

    private val _currentSkin = MutableStateFlow(PlayerSkin.AMOLED_GLASS)
    val currentSkin: StateFlow<PlayerSkin> = _currentSkin.asStateFlow()

    private val _selectedCategory = MutableStateFlow(LibraryCategory.TRACKS)
    val selectedCategory: StateFlow<LibraryCategory> = _selectedCategory.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    // Library & Folders
    private val _allTracks = MutableStateFlow<List<Track>>(emptyList())
    val allTracks: StateFlow<List<Track>> = _allTracks.asStateFlow()

    val filteredTracks: StateFlow<List<Track>> = combine(_allTracks, _searchQuery) { tracks, query ->
        if (query.isBlank()) tracks
        else tracks.filter {
            it.title.contains(query, ignoreCase = true) ||
            it.artist.contains(query, ignoreCase = true) ||
            it.album.contains(query, ignoreCase = true) ||
            it.genres.any { g -> g.contains(query, ignoreCase = true) }
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val albums: StateFlow<List<Album>> = _allTracks.map { tracks ->
        tracks.groupBy { it.album }.map { (albumName, albumTracks) ->
            Album(
                title = albumName,
                artist = albumTracks.firstOrNull()?.albumArtist?.ifBlank { null }
                    ?: albumTracks.firstOrNull()?.artist ?: "Unknown Artist",
                trackCount = albumTracks.size,
                year = albumTracks.firstOrNull()?.year ?: 2024,
                albumArtUri = albumTracks.firstOrNull()?.albumArtUri,
                tracks = albumTracks.sortedBy { it.trackNumber }
            )
        }.sortedBy { it.title.lowercase() }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val artists: StateFlow<List<ArtistGroup>> = _allTracks.map { tracks ->
        val artistMap = mutableMapOf<String, MutableList<Track>>()
        for (track in tracks) {
            val list = if (track.artists.isNotEmpty()) track.artists else listOf(track.artist)
            for (art in list) {
                artistMap.getOrPut(art) { mutableListOf() }.add(track)
            }
        }
        artistMap.map { (artistName, artistTracks) ->
            val albumCount = artistTracks.map { it.album }.distinct().size
            ArtistGroup(
                name = artistName,
                trackCount = artistTracks.size,
                albumsCount = albumCount,
                tracks = artistTracks.distinctBy { it.id }
            )
        }.sortedBy { it.name.lowercase() }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val genres: StateFlow<Map<String, List<Track>>> = _allTracks.map { tracks ->
        val genreMap = mutableMapOf<String, MutableList<Track>>()
        for (track in tracks) {
            for (g in track.genres) {
                genreMap.getOrPut(g) { mutableListOf() }.add(track)
            }
        }
        genreMap
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyMap())

    private val _filterSettings = MutableStateFlow(FilterSettings())
    val filterSettings: StateFlow<FilterSettings> = _filterSettings.asStateFlow()

    private val _currentFolderPath = MutableStateFlow("/Internal Storage/Music")
    val currentFolderPath: StateFlow<String> = _currentFolderPath.asStateFlow()

    private val _folderNodes = MutableStateFlow<List<FolderNode>>(emptyList())
    val folderNodes: StateFlow<List<FolderNode>> = _folderNodes.asStateFlow()

    // Musicolet-style Multi-Queues (Queue 1: "Main", Queue 2: "Favorites", Queue 3: "Bedtime / Chill")
    private val _activeQueueId = MutableStateFlow(1)
    val activeQueueId: StateFlow<Int> = _activeQueueId.asStateFlow()

    private val _multiQueues = MutableStateFlow(
        mapOf(
            1 to MultiQueue(1, "Queue 1 (Main)", emptyList(), 0),
            2 to MultiQueue(2, "Queue 2 (Favorites)", emptyList(), 0),
            3 to MultiQueue(3, "Queue 3 (Bedtime / Chill)", emptyList(), 0)
        )
    )
    val multiQueues: StateFlow<Map<Int, MultiQueue>> = _multiQueues.asStateFlow()

    val currentQueueTracks: StateFlow<List<Track>> = combine(_multiQueues, _activeQueueId) { queues, id ->
        queues[id]?.tracks ?: emptyList()
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Playback Modes: Repeat & Shuffle
    private val _repeatMode = MutableStateFlow(RepeatMode.ALL)
    val repeatMode: StateFlow<RepeatMode> = _repeatMode.asStateFlow()

    private val _shuffleMode = MutableStateFlow(false)
    val shuffleMode: StateFlow<Boolean> = _shuffleMode.asStateFlow()

    // Lyrics
    private val _currentLyrics = MutableStateFlow<List<LrcLine>>(emptyList())
    val currentLyrics: StateFlow<List<LrcLine>> = _currentLyrics.asStateFlow()

    private val _lyricsOffsetMs = MutableStateFlow(0L)
    val lyricsOffsetMs: StateFlow<Long> = _lyricsOffsetMs.asStateFlow()

    // Pi Music Player Track Info Inspector
    private val _inspectedTrack = MutableStateFlow<Track?>(null)
    val inspectedTrack: StateFlow<Track?> = _inspectedTrack.asStateFlow()

    // Echo Theme & Appearance Settings
    private val _echoThemeSettings = MutableStateFlow(EchoThemeSettings())
    val echoThemeSettings: StateFlow<EchoThemeSettings> = _echoThemeSettings.asStateFlow()

    fun updateThemeSettings(settings: EchoThemeSettings) {
        _echoThemeSettings.value = settings
    }

    // Dialogs & Tools
    val isThemeDialogOpen = MutableStateFlow(false)
    val isSleepTimerDialogOpen = MutableStateFlow(false)
    val isQueueDrawerOpen = MutableStateFlow(false)
    val isLyricsDrawerOpen = MutableStateFlow(false)
    val isLrcCreatorOpen = MutableStateFlow(false)
    val isTagEditorOpen = MutableStateFlow(false)
    val isSmartPlaylistDialogOpen = MutableStateFlow(false)
    val isAutoEqImportDialogOpen = MutableStateFlow(false)
    val isFolderFilterDialogOpen = MutableStateFlow(false)

    // Track Operations: Clideo Trimming, Renaming, Deleting
    val selectedTrackForActions = MutableStateFlow<Track?>(null)
    val trimmingTrack = MutableStateFlow<Track?>(null)
    val renamingTrack = MutableStateFlow<Track?>(null)
    val deletingTrack = MutableStateFlow<Track?>(null)

    // Analytics from Room
    val totalListeningTimeMs: StateFlow<Long> = db.analyticsDao().getTotalListeningTimeMs()
        .map { it ?: 0L }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0L)

    val totalTracksPlayed: StateFlow<Int> = db.analyticsDao().getTotalTracksPlayed()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    val recentPlayHistory: StateFlow<List<PlayHistoryEntity>> = db.analyticsDao().getRecentHistory()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val savedSmartPlaylists: StateFlow<List<SmartPlaylistEntity>> = db.smartPlaylistDao().getAllSmartPlaylists()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    init {
        audioEngine.onTrackFinished = { handleTrackFinished() }
        audioEngine.onTrackStarted = { track ->
            recordTrackStarted(track)
            loadLyricsForTrack(track)
        }

        refreshLibraryScan()
        // Sleep timer is an on-demand option; not auto-enabled on start
    }

    fun selectTab(tab: ScreenTab) {
        _currentTab.value = tab
    }

    fun selectCategory(category: LibraryCategory) {
        _selectedCategory.value = category
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun setPlayerSkin(skin: PlayerSkin) {
        _currentSkin.value = skin
    }

    fun inspectTrack(track: Track?) {
        _inspectedTrack.value = track
    }

    fun refreshLibraryScan() {
        viewModelScope.launch(Dispatchers.IO) {
            val scanned = FolderScanner.scanMediaStore(getApplication(), _filterSettings.value)
            _allTracks.value = scanned

            // Populate default Queue 1 if empty
            val currentMap = _multiQueues.value.toMutableMap()
            val q1 = currentMap[1]
            if (q1 == null || q1.tracks.isEmpty()) {
                currentMap[1] = MultiQueue(1, "Queue 1 (Main)", scanned, 0)
                _multiQueues.value = currentMap
            }

            refreshFolderHierarchy(_currentFolderPath.value)
        }
    }

    fun importSafDirectory(uri: Uri) {
        viewModelScope.launch(Dispatchers.IO) {
            val safTracks = SafFolderScanner.scanSafTree(getApplication(), uri)
            if (safTracks.isNotEmpty()) {
                val combined = (_allTracks.value + safTracks).distinctBy { it.id }
                _allTracks.value = combined
                // Add to current active queue
                val qId = _activeQueueId.value
                val map = _multiQueues.value.toMutableMap()
                val q = map[qId] ?: MultiQueue(qId, "Queue $qId")
                map[qId] = q.copy(tracks = (q.tracks + safTracks).distinctBy { it.id })
                _multiQueues.value = map
            }
        }
    }

    fun refreshFolderHierarchy(path: String) {
        viewModelScope.launch(Dispatchers.IO) {
            _currentFolderPath.value = path
            val nodes = FolderScanner.getFolderHierarchy(path, _allTracks.value, _filterSettings.value)
            _folderNodes.value = nodes
        }
    }

    fun navigateUpFolder() {
        val current = File(_currentFolderPath.value)
        val parent = current.parentFile
        if (parent != null && parent.canRead()) {
            refreshFolderHierarchy(parent.absolutePath)
        } else {
            refreshFolderHierarchy("/Internal Storage/Music")
        }
    }

    // Musicolet Multi-Queue Management
    fun switchQueue(queueId: Int) {
        if (queueId in 1..3) {
            _activeQueueId.value = queueId
            val q = _multiQueues.value[queueId]
            if (q != null && q.tracks.isNotEmpty()) {
                val index = q.currentIndex.coerceIn(0, q.tracks.size - 1)
                audioEngine.playTrack(q.tracks[index])
            }
        }
    }

    fun addToQueue(queueId: Int, track: Track) {
        val map = _multiQueues.value.toMutableMap()
        val q = map[queueId] ?: MultiQueue(queueId, "Queue $queueId")
        map[queueId] = q.copy(tracks = q.tracks + track)
        _multiQueues.value = map
    }

    fun removeFromQueue(queueId: Int, index: Int) {
        val map = _multiQueues.value.toMutableMap()
        val q = map[queueId] ?: return
        if (index in q.tracks.indices) {
            val list = q.tracks.toMutableList()
            list.removeAt(index)
            map[queueId] = q.copy(tracks = list)
            _multiQueues.value = map
        }
    }

    fun clearQueue(queueId: Int) {
        val map = _multiQueues.value.toMutableMap()
        val q = map[queueId] ?: return
        map[queueId] = q.copy(tracks = emptyList(), currentIndex = 0)
        _multiQueues.value = map
    }

    fun shuffleQueue(queueId: Int) {
        val map = _multiQueues.value.toMutableMap()
        val q = map[queueId] ?: return
        map[queueId] = q.copy(tracks = q.tracks.shuffled())
        _multiQueues.value = map
    }

    fun playTrackFromLibrary(track: Track) {
        val qId = _activeQueueId.value
        val map = _multiQueues.value.toMutableMap()
        val currentList = _allTracks.value
        val index = currentList.indexOfFirst { it.id == track.id }
        map[qId] = MultiQueue(qId, "Queue $qId", currentList, if (index >= 0) index else 0)
        _multiQueues.value = map
        audioEngine.playTrack(track)
        _currentTab.value = ScreenTab.NOW_PLAYING
    }

    fun playTrackAtQueueIndex(index: Int) {
        val qId = _activeQueueId.value
        val q = _multiQueues.value[qId] ?: return
        if (index in q.tracks.indices) {
            val map = _multiQueues.value.toMutableMap()
            map[qId] = q.copy(currentIndex = index)
            _multiQueues.value = map
            audioEngine.playTrack(q.tracks[index])
        }
    }

    fun playNextTrack() {
        val qId = _activeQueueId.value
        val q = _multiQueues.value[qId] ?: return
        val queue = q.tracks
        if (queue.isEmpty()) return

        val nextIndex = if (_shuffleMode.value) {
            queue.indices.random()
        } else {
            (q.currentIndex + 1) % queue.size
        }

        val map = _multiQueues.value.toMutableMap()
        map[qId] = q.copy(currentIndex = nextIndex)
        _multiQueues.value = map
        audioEngine.playTrack(queue[nextIndex])
    }

    fun playPreviousTrack() {
        val qId = _activeQueueId.value
        val q = _multiQueues.value[qId] ?: return
        val queue = q.tracks
        if (queue.isEmpty()) return

        val prevIndex = if (q.currentIndex - 1 < 0) queue.size - 1 else q.currentIndex - 1
        val map = _multiQueues.value.toMutableMap()
        map[qId] = q.copy(currentIndex = prevIndex)
        _multiQueues.value = map
        audioEngine.playTrack(queue[prevIndex])
    }

    fun toggleRepeatMode() {
        _repeatMode.value = when (_repeatMode.value) {
            RepeatMode.OFF -> RepeatMode.ALL
            RepeatMode.ALL -> RepeatMode.ONE
            RepeatMode.ONE -> RepeatMode.OFF
        }
    }

    fun toggleShuffleMode() {
        _shuffleMode.value = !_shuffleMode.value
    }

    private fun handleTrackFinished() {
        when (_repeatMode.value) {
            RepeatMode.ONE -> {
                audioEngine.currentTrack.value?.let { audioEngine.playTrack(it) }
            }
            RepeatMode.ALL, RepeatMode.OFF -> {
                playNextTrack()
            }
        }
    }

    fun enqueueNext(track: Track) {
        val qId = _activeQueueId.value
        val map = _multiQueues.value.toMutableMap()
        val q = map[qId] ?: MultiQueue(qId, "Queue $qId")
        val list = q.tracks.toMutableList()
        val insertIndex = (q.currentIndex + 1).coerceAtMost(list.size)
        list.add(insertIndex, track)
        map[qId] = q.copy(tracks = list)
        _multiQueues.value = map
    }

    // Filter Settings (Blacklist, Whitelist, Min Duration)
    fun updateMinDuration(secs: Int) {
        _filterSettings.value = _filterSettings.value.copy(minDurationSecs = secs)
        refreshLibraryScan()
    }

    fun toggleFolderBlacklist(folderPath: String) {
        val current = _filterSettings.value.blacklistedDirectories.toMutableSet()
        if (current.contains(folderPath)) {
            current.remove(folderPath)
        } else {
            current.add(folderPath)
        }
        _filterSettings.value = _filterSettings.value.copy(blacklistedDirectories = current)
        refreshLibraryScan()
    }

    fun toggleFolderWhitelist(folderPath: String) {
        val current = _filterSettings.value.whitelistedDirectories.toMutableSet()
        if (current.contains(folderPath)) {
            current.remove(folderPath)
        } else {
            current.add(folderPath)
        }
        _filterSettings.value = _filterSettings.value.copy(whitelistedDirectories = current)
        refreshLibraryScan()
    }

    // Lyrics
    private fun loadLyricsForTrack(track: Track) {
        viewModelScope.launch(Dispatchers.IO) {
            val fromFile = LrcParser.loadFromFile(track.filePath)
            if (fromFile != null) {
                _currentLyrics.value = fromFile
            } else {
                _currentLyrics.value = generateSampleLrc(track)
            }
            _lyricsOffsetMs.value = 0L
        }
    }

    fun adjustLyricsOffset(deltaMs: Long) {
        _lyricsOffsetMs.value += deltaMs
    }

    fun saveCreatedLyrics(rawText: String) {
        val track = audioEngine.currentTrack.value ?: return
        viewModelScope.launch(Dispatchers.IO) {
            val parsed = LrcParser.parse(rawText)
            _currentLyrics.value = parsed
            LrcParser.saveToFile(track.filePath, parsed)
            isLrcCreatorOpen.value = false
        }
    }

    // Equalizer & AutoEQ
    fun applyGraphicBandGain(freqHz: Int, gainDb: Float) {
        val current = audioEngine.equalizerConfig.value
        val updated = current.graphicBandGainsDb.toMutableMap()
        updated[freqHz] = gainDb
        audioEngine.updateEqualizerConfig(current.copy(graphicBandGainsDb = updated))
    }

    fun applyPreamp(db: Float) {
        val current = audioEngine.equalizerConfig.value
        audioEngine.updateEqualizerConfig(current.copy(preampDb = db))
    }

    fun applyBassBoost(strength: Int) {
        val current = audioEngine.equalizerConfig.value
        audioEngine.updateEqualizerConfig(current.copy(bassBoostStrength = strength))
    }

    fun applyPitchAndTempo(pitch: Float, tempo: Float, link: Boolean) {
        audioEngine.updatePitchAndTempo(pitch, tempo, link)
    }

    fun applyChannelBalance(balance: Float) {
        val current = audioEngine.equalizerConfig.value
        audioEngine.updateEqualizerConfig(current.copy(channelBalance = balance))
    }

    fun loadAutoEqProfile(profile: AutoEqProfile) {
        val current = audioEngine.equalizerConfig.value
        val updated = current.copy(
            graphicBandGainsDb = profile.graphicBandGains,
            activeAutoEqProfileName = profile.name
        )
        audioEngine.updateEqualizerConfig(updated)
    }

    fun importAutoEqRawText(text: String, name: String) {
        val profile = AutoEqParser.parseAutoEqText(text, name)
        loadAutoEqProfile(profile)
    }

    // Batch Tag Editing
    fun saveTrackMetadata(track: Track, metadata: Id3Editor.EditableMetadata) {
        val updated = Id3Editor.applyMetadataToTrack(track, metadata)
        val all = _allTracks.value.toMutableList()
        val index = all.indexOfFirst { it.id == track.id }
        if (index >= 0) {
            all[index] = updated
            _allTracks.value = all
        }
        val qId = _activeQueueId.value
        val map = _multiQueues.value.toMutableMap()
        val q = map[qId]
        if (q != null) {
            val qList = q.tracks.toMutableList()
            val qIdx = qList.indexOfFirst { it.id == track.id }
            if (qIdx >= 0) {
                qList[qIdx] = updated
                map[qId] = q.copy(tracks = qList)
                _multiQueues.value = map
            }
        }
        isTagEditorOpen.value = false
    }

    // Track Operations (Delete, Rename, Clideo Trim)
    fun selectTrackForActions(track: Track?) {
        selectedTrackForActions.value = track
    }

    fun openTrimmer(track: Track) {
        trimmingTrack.value = track
    }

    fun closeTrimmer() {
        trimmingTrack.value = null
    }

    fun openRenamer(track: Track) {
        renamingTrack.value = track
    }

    fun closeRenamer() {
        renamingTrack.value = null
    }

    fun openDeleter(track: Track) {
        deletingTrack.value = track
    }

    fun closeDeleter() {
        deletingTrack.value = null
    }

    fun deleteTrack(track: Track) {
        viewModelScope.launch(Dispatchers.IO) {
            if (audioEngine.currentTrack.value?.id == track.id) {
                audioEngine.stop()
            }

            try {
                val f = File(track.filePath)
                if (f.exists()) {
                    f.delete()
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }

            try {
                db.trackDao().deleteTrackByPath(track.filePath)
            } catch (_: Exception) {}

            _allTracks.value = _allTracks.value.filter { it.id != track.id }

            val updatedQueues = _multiQueues.value.mapValues { (_, queue) ->
                queue.copy(tracks = queue.tracks.filter { it.id != track.id })
            }
            _multiQueues.value = updatedQueues

            withContext(Dispatchers.Main) {
                deletingTrack.value = null
                selectedTrackForActions.value = null
            }
        }
    }

    fun renameTrack(track: Track, newTitle: String, newFileName: String) {
        viewModelScope.launch(Dispatchers.IO) {
            var finalPath = track.filePath
            try {
                val oldFile = File(track.filePath)
                if (oldFile.exists()) {
                    val parent = oldFile.parentFile ?: oldFile.absoluteFile.parentFile
                    val newFile = File(parent, newFileName)
                    if (oldFile.renameTo(newFile)) {
                        finalPath = newFile.absolutePath
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }

            val updatedTrack = track.copy(
                title = newTitle,
                filePath = finalPath
            )

            _allTracks.value = _allTracks.value.map {
                if (it.id == track.id) updatedTrack else it
            }

            val updatedQueues = _multiQueues.value.mapValues { (_, queue) ->
                queue.copy(tracks = queue.tracks.map { if (it.id == track.id) updatedTrack else it })
            }
            _multiQueues.value = updatedQueues

            withContext(Dispatchers.Main) {
                renamingTrack.value = null
                selectedTrackForActions.value = null
            }
        }
    }

    fun trimTrack(track: Track, config: TrimConfig, onComplete: (Track) -> Unit) {
        viewModelScope.launch(Dispatchers.IO) {
            val result = AudioTrimmer.trimAudio(getApplication(), track, config)
            result.onSuccess { trimmedTrack ->
                val updatedList = listOf(trimmedTrack) + _allTracks.value
                _allTracks.value = updatedList

                val qId = _activeQueueId.value
                val map = _multiQueues.value.toMutableMap()
                val q = map[qId] ?: MultiQueue(qId, "Queue $qId")
                map[qId] = q.copy(tracks = listOf(trimmedTrack) + q.tracks)
                _multiQueues.value = map

                withContext(Dispatchers.Main) {
                    trimmingTrack.value = null
                    selectedTrackForActions.value = null
                    onComplete(trimmedTrack)
                }
            }
        }
    }

    // Smart Playlists
    fun createSmartPlaylist(rule: SmartPlaylistRule) {
        viewModelScope.launch(Dispatchers.IO) {
            db.smartPlaylistDao().insertPlaylist(
                SmartPlaylistEntity(
                    name = rule.name,
                    genreFilter = rule.genreFilter,
                    artistFilter = rule.artistFilter,
                    minPlayCount = rule.minPlayCount,
                    minBitrateKbps = rule.minBitrateKbps,
                    minYear = rule.minYear,
                    sortBy = rule.sortBy
                )
            )
            isSmartPlaylistDialogOpen.value = false
        }
    }

    fun playSmartPlaylist(playlist: SmartPlaylistEntity) {
        val filtered = _allTracks.value.filter { track ->
            val matchGenre = playlist.genreFilter.isBlank() || track.genres.any { it.contains(playlist.genreFilter, ignoreCase = true) }
            val matchArtist = playlist.artistFilter.isBlank() || track.artist.contains(playlist.artistFilter, ignoreCase = true)
            val matchPlayCount = track.playCount >= playlist.minPlayCount
            val matchBitrate = track.bitrateKbps >= playlist.minBitrateKbps
            val matchYear = track.year >= playlist.minYear
            matchGenre && matchArtist && matchPlayCount && matchBitrate && matchYear
        }.let { list ->
            when (playlist.sortBy) {
                "playCount" -> list.sortedByDescending { it.playCount }
                "title" -> list.sortedBy { it.title.lowercase() }
                "artist" -> list.sortedBy { it.artist.lowercase() }
                else -> list.sortedByDescending { it.lastPlayedTimestamp }
            }
        }

        if (filtered.isNotEmpty()) {
            val qId = _activeQueueId.value
            val map = _multiQueues.value.toMutableMap()
            map[qId] = MultiQueue(qId, playlist.name, filtered, 0)
            _multiQueues.value = map
            audioEngine.playTrack(filtered[0])
            _currentTab.value = ScreenTab.NOW_PLAYING
        }
    }

    private fun recordTrackStarted(track: Track) {
        viewModelScope.launch(Dispatchers.IO) {
            db.analyticsDao().recordPlayEvent(
                PlayHistoryEntity(
                    filePath = track.filePath,
                    title = track.title,
                    artist = track.artist,
                    timestamp = System.currentTimeMillis(),
                    durationListenedMs = track.durationMs
                )
            )
        }
    }

    private fun generateSampleLrc(track: Track): List<LrcLine> {
        val totalMs = track.durationMs.coerceAtLeast(180000L)
        val step = (totalMs / 7).coerceAtLeast(15000L)
        return listOf(
            LrcLine(0L, "♪ (Audiophile Introduction • 24-bit/96kHz) ♪"),
            LrcLine(step * 1, "Listen close as the warm analog sound takes flight"),
            LrcLine(step * 2, "Studio frequencies floating through the quiet night"),
            LrcLine(step * 3, "No compression, pure dynamic range unbroken"),
            LrcLine(step * 4, "Every acoustic breath and subtle timber spoken"),
            LrcLine(step * 5, "Softly drifting down while the sleep timer slowly dims"),
            LrcLine(step * 6, "Resonance fading into gentle dreams and hymns")
        )
    }

    override fun onCleared() {
        audioEngine.release()
        super.onCleared()
    }
}
