package com.example.engine

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.PlaybackParams
import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer
import android.net.Uri
import android.os.Build
import com.example.model.*
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.io.File

class ResonanceAudioEngine(private val context: Context) {

    private val engineScope = CoroutineScope(Dispatchers.Main + SupervisorJob())

    private var primaryPlayer: MediaPlayer? = null
    private var nextPlayer: MediaPlayer? = null
    private var equalizer: Equalizer? = null
    private var bassBoost: BassBoost? = null

    private val _currentTrack = MutableStateFlow<Track?>(null)
    val currentTrack: StateFlow<Track?> = _currentTrack.asStateFlow()

    private val _isPlaying = MutableStateFlow(false)
    val isPlaying: StateFlow<Boolean> = _isPlaying.asStateFlow()

    private val _currentPositionMs = MutableStateFlow(0L)
    val currentPositionMs: StateFlow<Long> = _currentPositionMs.asStateFlow()

    private val _durationMs = MutableStateFlow(0L)
    val durationMs: StateFlow<Long> = _durationMs.asStateFlow()

    private val _equalizerConfig = MutableStateFlow(EqualizerConfig())
    val equalizerConfig: StateFlow<EqualizerConfig> = _equalizerConfig.asStateFlow()

    private val _sleepTimer = MutableStateFlow(SleepTimerConfig())
    val sleepTimer: StateFlow<SleepTimerConfig> = _sleepTimer.asStateFlow()

    private val _abLoop = MutableStateFlow(AbLoop())
    val abLoop: StateFlow<AbLoop> = _abLoop.asStateFlow()

    var onTrackFinished: (() -> Unit)? = null
    var onTrackStarted: ((Track) -> Unit)? = null

    private var progressJob: Job? = null
    private var sleepTimerJob: Job? = null
    private var crossfadeJob: Job? = null

    private var currentMasterVolume = 1.0f

    init {
        startProgressTracker()
    }

    companion object {
        @Volatile
        private var INSTANCE: ResonanceAudioEngine? = null

        fun getInstance(context: Context): ResonanceAudioEngine {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: ResonanceAudioEngine(context.applicationContext).also { INSTANCE = it }
            }
        }
    }

    private fun startProgressTracker() {
        progressJob?.cancel()
        progressJob = engineScope.launch {
            while (isActive) {
                try {
                    val player = primaryPlayer
                    if (player != null && _isPlaying.value) {
                        val pos = player.currentPosition.toLong()
                        _currentPositionMs.value = pos

                        // A-B Loop Check
                        val loop = _abLoop.value
                        if (loop.isEnabled && loop.startMs != null && loop.endMs != null) {
                            if (pos >= loop.endMs) {
                                player.seekTo(loop.startMs.toInt())
                                _currentPositionMs.value = loop.startMs
                            }
                        }
                    }
                } catch (e: Exception) {
                    // Ignored if player state transition
                }
                delay(250) // Throttled to 250ms for low battery usage and smooth UI
            }
        }
    }

    fun playTrack(track: Track, startOffsetMs: Long = 0L) {
        engineScope.launch {
            try {
                crossfadeJob?.cancel()
                val oldPlayer = primaryPlayer

                val (newPlayer, fileOpened) = withContext(Dispatchers.IO) {
                    val player = MediaPlayer().apply {
                        setAudioAttributes(
                            AudioAttributes.Builder()
                                .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                                .setUsage(AudioAttributes.USAGE_MEDIA)
                                .build()
                        )
                    }

                    var opened = false
                    if (track.filePath.isNotBlank()) {
                        val file = File(track.filePath)
                        if (file.exists() && file.canRead()) {
                            try {
                                player.setDataSource(file.absolutePath)
                                opened = true
                            } catch (e: Exception) {
                                opened = false
                            }
                        }
                    }
                    if (!opened && track.uri != Uri.EMPTY && !track.uri.toString().startsWith("asset:///")) {
                        try {
                            player.setDataSource(context, track.uri)
                            opened = true
                        } catch (e: Exception) {
                            opened = false
                        }
                    }

                    if (opened) {
                        try {
                            player.prepare()
                        } catch (e: Exception) {
                            opened = false
                        }
                    }
                    Pair(player, opened)
                }

                // Clean up old player asynchronously on IO
                withContext(Dispatchers.IO) {
                    try {
                        oldPlayer?.stop()
                        oldPlayer?.release()
                    } catch (e: Exception) {
                    }
                }

                primaryPlayer = newPlayer
                _currentTrack.value = track

                val seekTarget = if (track.isVirtualCueTrack) track.cueTrackOffsetMs else startOffsetMs
                if (seekTarget > 0 && fileOpened) {
                    try { newPlayer.seekTo(seekTarget.toInt()) } catch (e: Exception) {}
                }

                if (fileOpened) {
                    // Setup audio effects safely on IO dispatcher so AudioFlinger IPC doesn't freeze the UI
                    withContext(Dispatchers.IO) {
                        try {
                            attachAudioEffects(newPlayer.audioSessionId)
                            applyPlaybackParams(newPlayer)
                            applyVolumeAndBalance(newPlayer)
                        } catch (e: Exception) {}
                    }

                    newPlayer.start()
                    _isPlaying.value = true
                    _durationMs.value = if (track.isVirtualCueTrack) track.durationMs else newPlayer.duration.toLong()
                } else {
                    // Do not report playback as active when the URI/path cannot be opened.
                    try { newPlayer.release() } catch (_: Exception) {}
                    _isPlaying.value = false
                    _durationMs.value = 0L
                    _currentPositionMs.value = 0L
                    _currentTrack.value = null
                    return@launch
                }

                newPlayer.setOnCompletionListener {
                    handleTrackCompletion()
                }

                _currentPositionMs.value = seekTarget
                onTrackStarted?.invoke(track)

            } catch (e: Exception) {
                // Playback failed: keep UI state honest instead of showing a fake playing track.
                _isPlaying.value = false
                _durationMs.value = 0L
                _currentPositionMs.value = 0L
                _currentTrack.value = null
                try { primaryPlayer?.release() } catch (_: Exception) {}
                primaryPlayer = null
            }
        }
    }

    private fun handleTrackCompletion() {
        val timer = _sleepTimer.value
        if (timer.isActive && timer.finishLastSongFirst && timer.remainingSeconds <= 0) {
            pause()
            _sleepTimer.value = timer.copy(isActive = false)
            return
        }

        onTrackFinished?.invoke()
    }

    fun togglePlayPause() {
        if (_isPlaying.value) {
            pause()
        } else {
            resume()
        }
    }

    fun resume() {
        val player = primaryPlayer
        if (player == null) {
            _isPlaying.value = false
            return
        }
        try {
            player.start()
            _isPlaying.value = true
        } catch (_: Exception) {
            _isPlaying.value = false
        }
    }

    fun pause() {
        try {
            primaryPlayer?.pause()
            _isPlaying.value = false
        } catch (e: Exception) {
            _isPlaying.value = false
        }
    }

    fun stop() {
        val player = primaryPlayer
        primaryPlayer = null
        try { player?.stop() } catch (_: Exception) {}
        try { player?.release() } catch (_: Exception) {}
        _isPlaying.value = false
        _currentTrack.value = null
        _currentPositionMs.value = 0L
        _durationMs.value = 0L
    }

    fun seekTo(positionMs: Long) {
        val target = positionMs.coerceIn(0L, _durationMs.value.coerceAtLeast(1000L))
        _currentPositionMs.value = target
        try {
            primaryPlayer?.seekTo(target.toInt())
        } catch (e: Exception) {
            // Handled
        }
    }

    fun setAbLoop(startMs: Long?, endMs: Long?) {
        _abLoop.value = AbLoop(
            startMs = startMs,
            endMs = endMs,
            isEnabled = startMs != null && endMs != null
        )
    }

    fun clearAbLoop() {
        _abLoop.value = AbLoop()
    }

    // DSP: Pitch & Tempo
    fun updatePitchAndTempo(pitch: Float, tempo: Float, link: Boolean) {
        val finalPitch = if (link) tempo else pitch
        _equalizerConfig.value = _equalizerConfig.value.copy(
            playbackPitch = finalPitch,
            playbackTempo = tempo,
            linkPitchTempo = link
        )
        primaryPlayer?.let { applyPlaybackParams(it) }
    }

    private fun applyPlaybackParams(player: MediaPlayer) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            try {
                val config = _equalizerConfig.value
                val params = PlaybackParams()
                    .setPitch(config.playbackPitch.coerceIn(0.5f, 2.0f))
                    .setSpeed(config.playbackTempo.coerceIn(0.25f, 3.0f))
                player.playbackParams = params
            } catch (e: Exception) {
                // Some device HALs restrict PlaybackParams
            }
        }
    }

    // Audio Effects: Graphic EQ & Bass Boost
    private fun attachAudioEffects(sessionId: Int) {
        try {
            equalizer?.release()
            bassBoost?.release()

            equalizer = Equalizer(0, sessionId).apply {
                enabled = _equalizerConfig.value.isEnabled
            }
            bassBoost = BassBoost(0, sessionId).apply {
                enabled = _equalizerConfig.value.isEnabled
                if (strengthSupported) {
                    setStrength(_equalizerConfig.value.bassBoostStrength.toShort())
                }
            }
            applyEqualizerGains()
        } catch (e: Exception) {
            // AudioEffect may require system permissions on some custom ROMs
        }
    }

    fun updateEqualizerConfig(newConfig: EqualizerConfig) {
        _equalizerConfig.value = newConfig
        applyEqualizerGains()
        primaryPlayer?.let {
            applyVolumeAndBalance(it)
            applyPlaybackParams(it)
        }
    }

    private fun applyEqualizerGains() {
        val eq = equalizer ?: return
        val config = _equalizerConfig.value
        try {
            eq.enabled = config.isEnabled
            val numBands = eq.numberOfBands.toInt()
            val minEqLevel = eq.bandLevelRange[0]
            val maxEqLevel = eq.bandLevelRange[1]

            for (i in 0 until numBands) {
                val centerFreqHz = eq.getCenterFreq(i.toShort()) / 1000
                // Match to our graphic band
                val closestKey = config.graphicBandGainsDb.keys.minByOrNull { Math.abs(it - centerFreqHz) }
                val gainDb = (config.graphicBandGainsDb[closestKey] ?: 0f) + config.preampDb
                val millibels = (gainDb * 100).toInt().coerceIn(minEqLevel.toInt(), maxEqLevel.toInt())
                eq.setBandLevel(i.toShort(), millibels.toShort())
            }

            bassBoost?.let {
                it.enabled = config.isEnabled
                if (it.strengthSupported) {
                    it.setStrength(config.bassBoostStrength.toShort())
                }
            }
        } catch (e: Exception) {
            // Handled
        }
    }

    // ReplayGain & Stereo Balance
    private fun applyVolumeAndBalance(player: MediaPlayer) {
        val config = _equalizerConfig.value
        val track = _currentTrack.value

        var gainFactor = 1.0f
        if (config.replayGainEnabled && track != null && track.replayGainTrackDb != 0f) {
            // ReplayGain formula: 10 ^ ((trackGain + (target - (-14))) / 20)
            val deltaDb = track.replayGainTrackDb + (config.targetReplayGainDb - (-14f))
            gainFactor = Math.pow(10.0, (deltaDb / 20.0).toDouble()).toFloat().coerceIn(0.2f, 2.0f)
        }

        val baseVol = currentMasterVolume * gainFactor
        val balance = config.channelBalance.coerceIn(-1.0f, 1.0f)

        // Left / Right channel splitting
        val left = (baseVol * if (balance > 0f) (1f - balance) else 1f).coerceIn(0f, 1f)
        val right = (baseVol * if (balance < 0f) (1f + balance) else 1f).coerceIn(0f, 1f)

        try {
            player.setVolume(left, right)
        } catch (e: Exception) {
            // Handled
        }
    }

    // Sleep Timer with gentle 60s fade-out curve
    fun setSleepTimer(minutes: Int, finishLastSongFirst: Boolean = true, fadeOutSecs: Int = 60) {
        sleepTimerJob?.cancel()
        val totalSecs = minutes * 60
        _sleepTimer.value = SleepTimerConfig(
            isActive = true,
            targetTimestampMs = System.currentTimeMillis() + (totalSecs * 1000L),
            totalDurationMinutes = minutes,
            remainingSeconds = totalSecs,
            finishLastSongFirst = finishLastSongFirst,
            fadeOutDurationSeconds = fadeOutSecs,
            isCurrentlyFading = false
        )

        sleepTimerJob = engineScope.launch {
            var secsLeft = totalSecs
            while (secsLeft > 0 && isActive) {
                delay(1000)
                secsLeft--
                val isFading = secsLeft <= fadeOutSecs

                if (isFading && fadeOutSecs > 0) {
                    // Linear volume fade-down to 0
                    currentMasterVolume = (secsLeft.toFloat() / fadeOutSecs.toFloat()).coerceIn(0f, 1f)
                    primaryPlayer?.let { applyVolumeAndBalance(it) }
                }

                _sleepTimer.value = _sleepTimer.value.copy(
                    remainingSeconds = secsLeft,
                    isCurrentlyFading = isFading
                )
            }

            // Timer expired
            if (_sleepTimer.value.finishLastSongFirst) {
                // If finishLastSongFirst is true, wait for track completion
                _sleepTimer.value = _sleepTimer.value.copy(remainingSeconds = 0)
            } else {
                pause()
                currentMasterVolume = 1.0f
                _sleepTimer.value = _sleepTimer.value.copy(isActive = false, isCurrentlyFading = false)
            }
        }
    }

    fun cancelSleepTimer() {
        sleepTimerJob?.cancel()
        currentMasterVolume = 1.0f
        primaryPlayer?.let { applyVolumeAndBalance(it) }
        _sleepTimer.value = SleepTimerConfig(isActive = false)
    }

    fun release() {
        progressJob?.cancel()
        sleepTimerJob?.cancel()
        crossfadeJob?.cancel()
        try { primaryPlayer?.release() } catch (_: Exception) {}
        try { nextPlayer?.release() } catch (_: Exception) {}
        try { equalizer?.release() } catch (_: Exception) {}
        try { bassBoost?.release() } catch (_: Exception) {}
        primaryPlayer = null
        nextPlayer = null
        equalizer = null
        bassBoost = null
        _isPlaying.value = false
        engineScope.cancel()
    }
}
