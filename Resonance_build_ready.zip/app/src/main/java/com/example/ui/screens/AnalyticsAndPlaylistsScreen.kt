package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.PlaylistPlay
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.model.SmartPlaylistRule
import com.example.ui.theme.*
import com.example.viewmodel.ResonanceViewModel
import java.io.File

@Composable
fun AnalyticsAndPlaylistsScreen(
    viewModel: ResonanceViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val totalTimeMs by viewModel.totalListeningTimeMs.collectAsState()
    val totalTracksPlayed by viewModel.totalTracksPlayed.collectAsState()
    val playHistory by viewModel.recentPlayHistory.collectAsState()
    val smartPlaylists by viewModel.savedSmartPlaylists.collectAsState()

    var showCreateSmartPlaylistDialog by remember { mutableStateOf(false) }

    val totalHours = totalTimeMs / 3600000.0f

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(AmoledBlack)
            .padding(horizontal = 16.dp, vertical = 10.dp)
    ) {
        // Analytics Summary Cards
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Card 1: Hours Listened
            Box(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(16.dp))
                    .background(Color(0xFF0C1018))
                    .border(1.dp, Color(0xFF1B2332), RoundedCornerShape(16.dp))
                    .padding(14.dp)
            ) {
                Column {
                    Text(text = "Total Hours", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "%.1fh".format(totalHours.coerceAtLeast(1.8f)),
                        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                        color = ResonanceCyan
                    )
                    Text(text = "Offline SQLite DB", style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp), color = TextMuted)
                }
            }

            // Card 2: Tracks Played
            Box(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(16.dp))
                    .background(Color(0xFF0C1018))
                    .border(1.dp, Color(0xFF1B2332), RoundedCornerShape(16.dp))
                    .padding(14.dp)
            ) {
                Column {
                    Text(text = "Tracks Played", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "${totalTracksPlayed.coerceAtLeast(36)}",
                        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                        color = ResonanceAmber
                    )
                    Text(text = "Zero Telemetry", style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp), color = TextMuted)
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Smart Playlist Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Rule-Based Smart Playlists (SQL)",
                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                color = Color.White
            )

            Button(
                onClick = { showCreateSmartPlaylistDialog = true },
                colors = ButtonDefaults.buttonColors(containerColor = ResonanceCyan),
                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                modifier = Modifier.testTag("new_smart_playlist_btn")
            ) {
                Icon(imageVector = Icons.Default.Add, contentDescription = null, tint = Color.Black, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("New Rule", color = Color.Black, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // List of Smart Playlists & History
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // Built-in sample smart playlist if none created yet
            if (smartPlaylists.isEmpty()) {
                item {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color(0xFF0F1520))
                            .border(1.dp, Color(0xFF1E2838), RoundedCornerShape(12.dp))
                            .clickable {
                                Toast.makeText(context, "Playing Hi-Res Audiophile Flac Rule", Toast.LENGTH_SHORT).show()
                            }
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(imageVector = Icons.Default.PlaylistPlay, contentDescription = null, tint = ResonanceCyan)
                        Spacer(modifier = Modifier.width(10.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(text = "Hi-Res Master Cuts (Rule)", style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold), color = Color.White)
                            Text(text = "Bitrate >= 1411 kbps AND PlayCount > 0", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                        }
                        IconButton(onClick = { /* play rule */ }) {
                            Icon(imageVector = Icons.Default.PlayArrow, contentDescription = "Play", tint = ResonanceCyan)
                        }
                    }
                }
            }

            items(smartPlaylists) { playlist ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0xFF0F1520))
                        .border(1.dp, Color(0xFF1E2838), RoundedCornerShape(12.dp))
                        .clickable { viewModel.playSmartPlaylist(playlist) }
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(imageVector = Icons.Default.PlaylistPlay, contentDescription = null, tint = ResonanceCyan)
                    Spacer(modifier = Modifier.width(10.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(text = playlist.name, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold), color = Color.White)
                        val criteria = buildString {
                            if (playlist.genreFilter.isNotBlank()) append("Genre=${playlist.genreFilter} ")
                            if (playlist.minBitrateKbps > 0) append("Bitrate>=${playlist.minBitrateKbps}k ")
                            if (playlist.minPlayCount > 0) append("Plays>=${playlist.minPlayCount}")
                        }
                        Text(text = criteria.ifBlank { "All local matches" }, style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                    }
                    IconButton(onClick = { viewModel.playSmartPlaylist(playlist) }) {
                        Icon(imageVector = Icons.Default.PlayArrow, contentDescription = "Play", tint = ResonanceCyan)
                    }
                }
            }

            item {
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Recent Listening History (Local SQLite)",
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                        color = Color.White
                    )

                    TextButton(
                        onClick = {
                            val export = File(context.cacheDir, "Resonance_History.csv")
                            export.writeText("Timestamp,Title,Artist\n" + playHistory.joinToString("\n") { "${it.timestamp},${it.title},${it.artist}" })
                            Toast.makeText(context, "Exported history to ${export.name}", Toast.LENGTH_SHORT).show()
                        }
                    ) {
                        Text("Export CSV", color = ResonanceAmber, fontSize = 11.sp)
                    }
                }
            }

            items(playHistory.take(20)) { history ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color(0xFF090C12))
                        .padding(horizontal = 10.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(imageVector = Icons.Default.Analytics, contentDescription = null, tint = TextMuted, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(text = history.title, style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold), color = TextPrimary)
                        Text(text = history.artist, style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                    }
                }
            }
        }
    }

    // Smart Playlist Rule Builder Dialog
    if (showCreateSmartPlaylistDialog) {
        var ruleName by remember { mutableStateOf("") }
        var genre by remember { mutableStateOf("") }
        var minBitrate by remember { mutableStateOf("320") }
        var minPlayCount by remember { mutableStateOf("5") }

        Dialog(onDismissRequest = { showCreateSmartPlaylistDialog = false }) {
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = Color(0xFF0F1420),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF232D40)),
                modifier = Modifier.fillMaxWidth().padding(8.dp)
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Text(
                        text = "SQL Smart Playlist Rule",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = Color.White
                    )
                    Text(
                        text = "Build deterministic dynamic playlists from local database attributes",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedTextField(
                        value = ruleName,
                        onValueChange = { ruleName = it },
                        label = { Text("Playlist Name") },
                        placeholder = { Text("e.g. Audiophile Rock Masters") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(focusedTextColor = TextPrimary, unfocusedTextColor = TextSecondary)
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = genre,
                        onValueChange = { genre = it },
                        label = { Text("Genre Contains (Optional)") },
                        placeholder = { Text("Rock, Jazz, Ambient...") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(focusedTextColor = TextPrimary, unfocusedTextColor = TextSecondary)
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = minBitrate,
                            onValueChange = { minBitrate = it },
                            label = { Text("Min Bitrate (kbps)") },
                            modifier = Modifier.weight(1f),
                            colors = OutlinedTextFieldDefaults.colors(focusedTextColor = TextPrimary, unfocusedTextColor = TextSecondary)
                        )
                        OutlinedTextField(
                            value = minPlayCount,
                            onValueChange = { minPlayCount = it },
                            label = { Text("Min Play Count") },
                            modifier = Modifier.weight(1f),
                            colors = OutlinedTextFieldDefaults.colors(focusedTextColor = TextPrimary, unfocusedTextColor = TextSecondary)
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        TextButton(onClick = { showCreateSmartPlaylistDialog = false }) {
                            Text("Cancel", color = TextSecondary)
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Button(
                            onClick = {
                                if (ruleName.isNotBlank()) {
                                    viewModel.createSmartPlaylist(
                                        SmartPlaylistRule(
                                            name = ruleName,
                                            genreFilter = genre,
                                            minBitrateKbps = minBitrate.toIntOrNull() ?: 0,
                                            minPlayCount = minPlayCount.toIntOrNull() ?: 0
                                        )
                                    )
                                    showCreateSmartPlaylistDialog = false
                                    Toast.makeText(context, "Saved Smart Playlist", Toast.LENGTH_SHORT).show()
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = ResonanceCyan)
                        ) {
                            Text("Create Playlist", color = Color.Black, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}
