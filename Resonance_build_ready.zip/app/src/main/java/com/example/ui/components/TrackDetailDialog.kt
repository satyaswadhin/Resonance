package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.model.Track
import com.example.ui.theme.ResonanceAmber
import com.example.ui.theme.ResonanceCyan
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun TrackDetailDialog(
    track: Track,
    onDismiss: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = Color(0xFF0F1420),
            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF232D42)),
            modifier = Modifier.fillMaxWidth().padding(8.dp)
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                Text(
                    text = "Audio File Inspector",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = Color.White
                )
                Text(
                    text = "Bit-exact hardware stream information",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary
                )

                Spacer(modifier = Modifier.height(14.dp))

                DetailRow("Title", track.title)
                DetailRow("Artist", track.artist)
                DetailRow("Album", track.album)
                DetailRow("Format / Codec", track.format, isHighlight = true)
                DetailRow("Bit Depth", "${track.bitDepth}-bit Lossless", isHighlight = true)
                DetailRow("Sample Rate", "${track.sampleRateHz} Hz (${track.sampleRateHz / 1000} kHz)", isHighlight = true)
                DetailRow("Bitrate", "${track.bitrateKbps} kbps")
                DetailRow("Duration", track.formattedDuration)
                DetailRow("Track / Disc", "#${track.trackNumber} / Disc ${track.discNumber}")
                DetailRow("Release Year", "${track.year}")
                DetailRow("ReplayGain Track", "%+.1f dB".format(track.replayGainTrackDb))
                DetailRow("Storage Path", track.filePath, isMonospace = true)

                Spacer(modifier = Modifier.height(18.dp))

                Button(
                    onClick = onDismiss,
                    colors = ButtonDefaults.buttonColors(containerColor = ResonanceCyan),
                    modifier = Modifier.align(Alignment.End).testTag("close_track_detail_btn")
                ) {
                    Text("Close", color = Color.Black, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
private fun DetailRow(
    label: String,
    value: String,
    isHighlight: Boolean = false,
    isMonospace: Boolean = false
) {
    Column(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
        Text(text = label, style = MaterialTheme.typography.labelSmall, color = TextMuted)
        Text(
            text = value,
            style = MaterialTheme.typography.bodyMedium.copy(
                fontWeight = if (isHighlight) FontWeight.Bold else FontWeight.Normal,
                fontFamily = if (isMonospace) FontFamily.Monospace else FontFamily.Default,
                fontSize = if (isMonospace) 11.sp else 13.sp
            ),
            color = if (isHighlight) ResonanceCyan else TextPrimary
        )
        HorizontalDivider(color = Color(0xFF18202E), modifier = Modifier.padding(top = 4.dp))
    }
}
