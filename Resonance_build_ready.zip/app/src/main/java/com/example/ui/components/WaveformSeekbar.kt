package com.example.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.parser.FolderScanner
import com.example.model.AbLoop
import com.example.ui.theme.ResonanceAmber
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextSecondary
import kotlin.math.sin

@Composable
fun WaveformSeekbar(
    trackId: Long,
    currentPositionMs: Long,
    durationMs: Long,
    abLoop: AbLoop,
    onSeek: (Long) -> Unit,
    accentColor: Color = Color(0xFFED5564), // Echo signature default
    isWavy: Boolean = true,
    isPlaying: Boolean = false,
    modifier: Modifier = Modifier
) {
    val waveformPoints = remember(trackId) {
        FolderScanner.generateWaveformPoints(trackId, count = 48)
    }

    // Wavy phase animation for Echo fluid progress bar
    val infiniteTransition = rememberInfiniteTransition(label = "wavy_scrubber")
    val wavePhase by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 6.28f, // 2*PI
        animationSpec = infiniteRepeatable(
            animation = tween(2400, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "phase"
    )

    val progress = if (durationMs > 0) {
        (currentPositionMs.toFloat() / durationMs.toFloat()).coerceIn(0f, 1f)
    } else 0f

    Column(modifier = modifier.fillMaxWidth()) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
                .testTag("waveform_seekbar")
                .pointerInput(trackId, durationMs) {
                    detectTapGestures { offset ->
                        val ratio = (offset.x / size.width).coerceIn(0f, 1f)
                        val targetMs = (ratio * durationMs).toLong()
                        onSeek(targetMs)
                    }
                }
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val progressX = size.width * progress
                val centerY = size.height / 2f

                if (isWavy) {
                    // Echo's signature Wavy Fluid Sine-Wave Progress Bar
                    val wavePathPlayed = Path()
                    val wavePathUnplayed = Path()
                    val amplitude = if (isPlaying) 7.dp.toPx() else 4.dp.toPx()
                    val frequency = 0.04f
                    val phase = if (isPlaying) wavePhase else 0f

                    wavePathPlayed.moveTo(0f, centerY + (amplitude * sin(phase)))
                    var x = 0f
                    val step = 4f
                    while (x <= progressX) {
                        val y = centerY + (amplitude * sin((x * frequency) + phase))
                        wavePathPlayed.lineTo(x, y)
                        x += step
                    }

                    wavePathUnplayed.moveTo(progressX, centerY + (amplitude * sin((progressX * frequency) + phase)))
                    while (x <= size.width) {
                        val y = centerY + (amplitude * sin((x * frequency) + phase))
                        wavePathUnplayed.lineTo(x, y)
                        x += step
                    }

                    // Draw played wave with Echo accent glow
                    drawPath(
                        path = wavePathPlayed,
                        color = accentColor,
                        style = Stroke(width = 3.5.dp.toPx(), cap = StrokeCap.Round)
                    )

                    // Draw unplayed remaining track with muted contrast
                    drawPath(
                        path = wavePathUnplayed,
                        color = Color(0xFF263248),
                        style = Stroke(width = 2.dp.toPx(), cap = StrokeCap.Round)
                    )
                } else {
                    // Classic Amplitude Waveform
                    val barCount = waveformPoints.size
                    val barWidth = size.width / (barCount * 1.4f)
                    val spacing = barWidth * 0.4f
                    val cornerRadius = CornerRadius(barWidth / 2f, barWidth / 2f)

                    for (i in 0 until barCount) {
                        val x = i * (barWidth + spacing)
                        val amp = waveformPoints[i]
                        val barHeight = (size.height * 0.85f * amp).coerceAtLeast(6f)
                        val y = centerY - (barHeight / 2f)

                        val isPlayed = (x + barWidth) <= progressX
                        val barColor = if (isPlayed) accentColor else Color(0xFF232D3F)

                        drawRoundRect(
                            color = barColor,
                            topLeft = Offset(x, y),
                            size = Size(barWidth, barHeight),
                            cornerRadius = cornerRadius
                        )
                    }
                }

                // A-B Loop Indicator flags
                if (abLoop.isEnabled && durationMs > 0) {
                    abLoop.startMs?.let { start ->
                        val startX = (start.toFloat() / durationMs.toFloat()) * size.width
                        drawLine(
                            color = ResonanceAmber,
                            start = Offset(startX, 0f),
                            end = Offset(startX, size.height),
                            strokeWidth = 3.dp.toPx()
                        )
                    }
                    abLoop.endMs?.let { end ->
                        val endX = (end.toFloat() / durationMs.toFloat()) * size.width
                        drawLine(
                            color = ResonanceAmber,
                            start = Offset(endX, 0f),
                            end = Offset(endX, size.height),
                            strokeWidth = 3.dp.toPx()
                        )
                    }
                }

                // Active Scrubber Head
                drawCircle(
                    color = Color.White,
                    radius = 5.dp.toPx(),
                    center = Offset(progressX, centerY)
                )
                drawCircle(
                    color = accentColor,
                    radius = 3.dp.toPx(),
                    center = Offset(progressX, centerY)
                )
            }
        }

        // Timestamp labels
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 4.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = formatDuration(currentPositionMs),
                style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                color = TextSecondary
            )
            if (abLoop.isEnabled && abLoop.startMs != null && abLoop.endMs != null) {
                Text(
                    text = "A-B [${formatDuration(abLoop.startMs)} → ${formatDuration(abLoop.endMs)}]",
                    style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                    color = ResonanceAmber
                )
            }
            Text(
                text = formatDuration(durationMs),
                style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                color = TextMuted
            )
        }
    }
}

private fun formatDuration(millis: Long): String {
    val totalSecs = (millis / 1000).coerceAtLeast(0L)
    val mins = totalSecs / 60
    val secs = totalSecs % 60
    return "%d:%02d".format(mins, secs)
}
