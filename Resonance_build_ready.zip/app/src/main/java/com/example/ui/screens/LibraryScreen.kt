package com.example.ui.screens

import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.combinedClickable
import com.example.model.Album
import com.example.model.ArtistGroup
import com.example.model.Track
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.viewmodel.LibraryCategory
import com.example.viewmodel.ResonanceViewModel

@OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)
@Composable
fun LibraryScreen(
    viewModel: ResonanceViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val themeSettings by viewModel.echoThemeSettings.collectAsState()
    val selectedCategory by viewModel.selectedCategory.collectAsState()
    val searchQuery by viewModel.searchQuery.collectAsState()
    val tracks by viewModel.filteredTracks.collectAsState()
    val albums by viewModel.albums.collectAsState()
    val artists by viewModel.artists.collectAsState()
    val genres by viewModel.genres.collectAsState()
    val inspectedTrack by viewModel.inspectedTrack.collectAsState()
    val currentFolderPath by viewModel.currentFolderPath.collectAsState()
    val folderNodes by viewModel.folderNodes.collectAsState()

    var editingTrack by remember { mutableStateOf<Track?>(null) }
    var trackMenuTarget by remember { mutableStateOf<Track?>(null) }
    val trimmingTrack by viewModel.trimmingTrack.collectAsState()
    val renamingTrack by viewModel.renamingTrack.collectAsState()
    val deletingTrack by viewModel.deletingTrack.collectAsState()

    // SAF Directory Picker to select any directory from device file manager
    val safFolderLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocumentTree()
    ) { uri: Uri? ->
        if (uri != null) {
            viewModel.importSafDirectory(uri)
            Toast.makeText(context, "Scanning folder from File Manager...", Toast.LENGTH_SHORT).show()
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(themeSettings.backgroundStyle.color)
            .padding(horizontal = 14.dp, vertical = 8.dp)
    ) {
        // High-End Audio Library Search Bar
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { viewModel.setSearchQuery(it) },
            placeholder = { Text("Search local tracks, artists, albums...", color = TextMuted, fontSize = 13.sp) },
            leadingIcon = {
                Icon(imageVector = Icons.Default.Search, contentDescription = "Search", tint = themeSettings.accentColor, modifier = Modifier.size(20.dp))
            },
            trailingIcon = {
                if (searchQuery.isNotEmpty()) {
                    IconButton(onClick = { viewModel.setSearchQuery("") }) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "Clear", tint = TextSecondary, modifier = Modifier.size(18.dp))
                    }
                }
            },
            singleLine = true,
            modifier = Modifier
                .fillMaxWidth()
                .testTag("library_search_input"),
            colors = OutlinedTextFieldDefaults.colors(
                focusedTextColor = TextPrimary,
                unfocusedTextColor = TextPrimary,
                focusedBorderColor = themeSettings.accentColor,
                unfocusedBorderColor = HairlineBorder,
                focusedContainerColor = DarkSurface2,
                unfocusedContainerColor = DarkSurface2
            ),
            shape = RoundedCornerShape(14.dp)
        )

        Spacer(modifier = Modifier.height(10.dp))

        // Category Filter Chips Row
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            LibraryCategory.values().forEach { category ->
                val isSelected = selectedCategory == category
                FilterChip(
                    selected = isSelected,
                    onClick = { viewModel.selectCategory(category) },
                    label = {
                        Text(
                            text = category.title,
                            fontSize = 12.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                        )
                    },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = themeSettings.accentColor,
                        selectedLabelColor = Color.Black,
                        containerColor = DarkSurface2,
                        labelColor = TextSecondary
                    ),
                    border = FilterChipDefaults.filterChipBorder(
                        borderColor = if (isSelected) themeSettings.accentColor else HairlineBorder,
                        enabled = true,
                        selected = isSelected
                    ),
                    shape = RoundedCornerShape(20.dp),
                    modifier = Modifier.testTag("category_${category.name.lowercase()}")
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Content Area based on Category
        when (selectedCategory) {
            LibraryCategory.TRACKS -> {
                // Tracks List
                Row(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 2.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "${tracks.size} Tracks",
                        style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                        color = TextSecondary
                    )
                    TextButton(onClick = { viewModel.refreshLibraryScan() }) {
                        Icon(imageVector = Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(14.dp), tint = ResonanceCyan)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Rescan", color = ResonanceCyan, fontSize = 11.sp)
                    }
                }

                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    items(tracks) { track ->
                        TrackRowItem(
                            track = track,
                            onPlay = { viewModel.playTrackFromLibrary(track) },
                            onMoreOptions = { trackMenuTarget = track }
                        )
                    }
                }
            }

            LibraryCategory.FOLDERS -> {
                // True Folder Hierarchy & SAF File Manager Access
                Row(
                    modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Button(
                        onClick = { safFolderLauncher.launch(null) },
                        colors = ButtonDefaults.buttonColors(containerColor = ResonanceAmber),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                        modifier = Modifier.testTag("saf_picker_btn")
                    ) {
                        Icon(imageVector = Icons.Default.FolderOpen, contentDescription = null, tint = Color.Black, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Pick Folder via File Manager", color = Color.Black, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }

                    IconButton(onClick = { viewModel.navigateUpFolder() }) {
                        Icon(imageVector = Icons.Default.ArrowUpward, contentDescription = "Up", tint = ResonanceCyan)
                    }
                }

                Text(
                    text = currentFolderPath,
                    style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                    color = TextMuted,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )

                Spacer(modifier = Modifier.height(6.dp))

                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    items(folderNodes) { node ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(DarkSurface2)
                                .border(1.dp, HairlineBorder, RoundedCornerShape(12.dp))
                                .clickable { viewModel.refreshFolderHierarchy(node.path) }
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(imageVector = Icons.Default.Folder, contentDescription = null, tint = themeSettings.accentColor)
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(text = node.name, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold), color = TextPrimary)
                                Text(text = "${node.trackCount} audio tracks", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                            }
                        }
                    }
                }
            }

            LibraryCategory.ALBUMS -> {
                // Albums Grid
                LazyVerticalGrid(
                    columns = GridCells.Fixed(2),
                    modifier = Modifier.fillMaxSize(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(albums) { album ->
                        Column(
                            modifier = Modifier
                                .clip(RoundedCornerShape(14.dp))
                                .background(DarkSurface2)
                                .border(1.dp, HairlineBorder, RoundedCornerShape(14.dp))
                                .clickable {
                                    if (album.tracks.isNotEmpty()) {
                                        viewModel.playTrackFromLibrary(album.tracks.first())
                                    }
                                }
                                .padding(12.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(110.dp)
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(DarkSurface3),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(imageVector = Icons.Default.Album, contentDescription = null, tint = themeSettings.accentColor, modifier = Modifier.size(48.dp))
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(text = album.title, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold), color = TextPrimary, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(text = album.artist, style = MaterialTheme.typography.labelSmall, color = themeSettings.accentColor, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(text = "${album.trackCount} tracks • ${album.year}", style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp), color = TextMuted)
                        }
                    }
                }
            }

            LibraryCategory.ARTISTS -> {
                // Artists List / Grid
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(artists) { artist ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(DarkSurface2)
                                .border(1.dp, HairlineBorder, RoundedCornerShape(12.dp))
                                .clickable {
                                    if (artist.tracks.isNotEmpty()) {
                                        viewModel.playTrackFromLibrary(artist.tracks.first())
                                    }
                                }
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(46.dp)
                                    .clip(CircleShape)
                                    .background(DarkSurface3),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(imageVector = Icons.Default.Person, contentDescription = null, tint = themeSettings.accentColor, modifier = Modifier.size(24.dp))
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(text = artist.name, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold), color = TextPrimary)
                                Text(text = "${artist.trackCount} songs • ${artist.albumsCount} albums", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                            }
                        }
                    }
                }
            }

            LibraryCategory.GENRES -> {
                // Genres Chips
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(genres.toList()) { (genreName, genreTracks) ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(DarkSurface2)
                                .border(1.dp, HairlineBorder, RoundedCornerShape(12.dp))
                                .clickable {
                                    if (genreTracks.isNotEmpty()) {
                                        viewModel.playTrackFromLibrary(genreTracks.first())
                                    }
                                }
                                .padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(text = genreName, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold), color = TextPrimary)
                            Text(text = "${genreTracks.size} songs", style = MaterialTheme.typography.labelSmall, color = themeSettings.accentColor)
                        }
                    }
                }
            }

            LibraryCategory.PLAYLISTS -> {
                // Playlists & Smart Playlists quick view
                Text(
                    text = "Tap Analytics & Playlists in navigation bar to build SQL-style smart playlists",
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextMuted,
                    modifier = Modifier.padding(16.dp)
                )
            }
        }
    }

    // Long-Press Track Action Menu (Clideo Cut, Rename, Delete, ID3 Tags, Inspector)
    val activeActionTrack = trackMenuTarget ?: viewModel.selectedTrackForActions.collectAsState().value
    activeActionTrack?.let { track ->
        TrackActionBottomSheet(
            track = track,
            accentColor = themeSettings.accentColor,
            onCutAudio = {
                viewModel.openTrimmer(track)
                trackMenuTarget = null
            },
            onRename = {
                viewModel.openRenamer(track)
                trackMenuTarget = null
            },
            onDelete = {
                viewModel.openDeleter(track)
                trackMenuTarget = null
            },
            onEditTags = {
                editingTrack = track
                trackMenuTarget = null
                viewModel.selectTrackForActions(null)
            },
            onInspectInfo = {
                viewModel.inspectTrack(track)
                trackMenuTarget = null
                viewModel.selectTrackForActions(null)
            },
            onPlayNext = {
                viewModel.enqueueNext(track)
                trackMenuTarget = null
                viewModel.selectTrackForActions(null)
                Toast.makeText(context, "Playing next: ${track.title}", Toast.LENGTH_SHORT).show()
            },
            onAddToQueue = {
                viewModel.addToQueue(1, track)
                trackMenuTarget = null
                viewModel.selectTrackForActions(null)
                Toast.makeText(context, "Added to Queue 1 (Main)", Toast.LENGTH_SHORT).show()
            },
            onDismiss = {
                trackMenuTarget = null
                viewModel.selectTrackForActions(null)
            }
        )
    }

    // Clideo Audio Cutter Dialog
    trimmingTrack?.let { track ->
        ClideoAudioCutterDialog(
            track = track,
            accentColor = themeSettings.accentColor,
            onExportTrim = { config ->
                viewModel.trimTrack(track, config) { trimmed ->
                    Toast.makeText(context, "Exported trimmed track: ${trimmed.title}", Toast.LENGTH_LONG).show()
                }
            },
            onDismiss = { viewModel.closeTrimmer() }
        )
    }

    // Rename Music File Dialog
    renamingTrack?.let { track ->
        RenameTrackDialog(
            track = track,
            accentColor = themeSettings.accentColor,
            onConfirmRename = { newTitle, newFileName ->
                viewModel.renameTrack(track, newTitle, newFileName)
                Toast.makeText(context, "Renamed to $newFileName", Toast.LENGTH_SHORT).show()
            },
            onDismiss = { viewModel.closeRenamer() }
        )
    }

    // Delete Music File Confirmation Dialog
    deletingTrack?.let { track ->
        DeleteTrackDialog(
            track = track,
            onConfirmDelete = {
                viewModel.deleteTrack(track)
                Toast.makeText(context, "Permanently deleted ${track.title}", Toast.LENGTH_SHORT).show()
            },
            onDismiss = { viewModel.closeDeleter() }
        )
    }

    // Pi Music Player Audio File Inspector
    inspectedTrack?.let { track ->
        TrackDetailDialog(
            track = track,
            onDismiss = { viewModel.inspectTrack(null) }
        )
    }

    // ID3 Tag Editor
    editingTrack?.let { track ->
        TagEditorDialog(
            track = track,
            onSave = { targetTrack, metadata ->
                viewModel.saveTrackMetadata(targetTrack, metadata)
                editingTrack = null
                Toast.makeText(context, "Updated tags for ${targetTrack.title}", Toast.LENGTH_SHORT).show()
            },
            onDismiss = { editingTrack = null }
        )
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun TrackRowItem(
    track: Track,
    onPlay: () -> Unit,
    onMoreOptions: () -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(DarkSurface2)
            .border(1.dp, HairlineBorder, RoundedCornerShape(12.dp))
            .combinedClickable(
                onClick = onPlay,
                onLongClick = onMoreOptions
            )
            .padding(horizontal = 10.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Format & Bit depth Badge
        Box(
            modifier = Modifier
                .size(42.dp)
                .clip(RoundedCornerShape(8.dp))
                .background(if (track.format == "FLAC") Color(0xFF003844) else DarkSurface3),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = track.format,
                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, fontSize = 9.sp),
                    color = if (track.format == "FLAC") CyberCyan else ChampagneGold
                )
                Text(
                    text = "${track.bitDepth}b",
                    style = MaterialTheme.typography.labelSmall.copy(fontSize = 8.sp, fontWeight = FontWeight.SemiBold),
                    color = TextMuted
                )
            }
        }

        Spacer(modifier = Modifier.width(10.dp))

        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = track.title,
                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
                color = TextPrimary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = "${track.artist} • ${track.formattedDuration}",
                style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                color = TextSecondary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }

        IconButton(
            onClick = onMoreOptions,
            modifier = Modifier.size(32.dp).testTag("more_opts_track_${track.id}")
        ) {
            Icon(imageVector = Icons.Default.MoreVert, contentDescription = "Options", tint = TextSecondary, modifier = Modifier.size(18.dp))
        }
    }
}
