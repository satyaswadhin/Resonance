package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FileOpen
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.parser.AutoEqParser
import com.example.data.parser.AutoEqProfile
import com.example.ui.theme.*
import com.example.viewmodel.ResonanceViewModel

@Composable
fun EqualizerScreen(
    viewModel: ResonanceViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val eqConfig by viewModel.audioEngine.equalizerConfig.collectAsState()

    var showAutoEqDialog by remember { mutableStateOf(false) }
    var rawAutoEqText by remember { mutableStateOf("") }
    var selectedTab by remember { mutableStateOf(0) } // 0: Graphic EQ, 1: Pitch & Tempo DSP, 2: AutoEQ Presets

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(AmoledBlack)
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 10.dp)
    ) {
        // Equalizer Header & Enable Toggle
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "Studio DSP Equalizer",
                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                    color = Color.White
                )
                Text(
                    text = eqConfig.activeAutoEqProfileName ?: "Direct High-Definition Processing",
                    style = MaterialTheme.typography.bodySmall,
                    color = ResonanceCyan
                )
            }

            Switch(
                checked = eqConfig.isEnabled,
                onCheckedChange = {
                    viewModel.audioEngine.updateEqualizerConfig(eqConfig.copy(isEnabled = it))
                },
                colors = SwitchDefaults.colors(
                    checkedThumbColor = ResonanceCyan,
                    checkedTrackColor = Color(0xFF003842)
                ),
                modifier = Modifier.testTag("eq_master_toggle")
            )
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Tabs: Graphic EQ, DSP Shifter, AutoEQ Presets
        TabRow(
            selectedTabIndex = selectedTab,
            containerColor = Color(0xFF0C1018),
            contentColor = ResonanceCyan,
            modifier = Modifier.clip(RoundedCornerShape(12.dp))
        ) {
            Tab(
                selected = selectedTab == 0,
                onClick = { selectedTab = 0 },
                text = { Text("10-Band EQ", fontSize = 12.sp) }
            )
            Tab(
                selected = selectedTab == 1,
                onClick = { selectedTab = 1 },
                text = { Text("Pitch & Tempo", fontSize = 12.sp) }
            )
            Tab(
                selected = selectedTab == 2,
                onClick = { selectedTab = 2 },
                text = { Text("AutoEQ Curves", fontSize = 12.sp) }
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        when (selectedTab) {
            0 -> {
                // 10-Band Graphic EQ View
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(18.dp))
                        .background(Color(0xFF090D15))
                        .border(1.dp, Color(0xFF1E2638), RoundedCornerShape(18.dp))
                        .padding(16.dp)
                ) {
                    Text(
                        text = "10-Band Graphic Sliders (-12dB to +12dB)",
                        style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                        color = Color.White
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    val standardBands = listOf(31, 62, 125, 250, 500, 1000, 2000, 4000, 8000, 16000)

                    standardBands.forEach { freq ->
                        val gain = eqConfig.graphicBandGainsDb[freq] ?: 0f
                        val label = if (freq >= 1000) "${freq / 1000}kHz" else "${freq}Hz"

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 2.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = label,
                                style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                                color = TextSecondary,
                                modifier = Modifier.width(46.dp)
                            )
                            Slider(
                                value = gain,
                                onValueChange = { viewModel.applyGraphicBandGain(freq, it) },
                                valueRange = -12f..12f,
                                modifier = Modifier.weight(1f).testTag("eq_slider_$freq"),
                                colors = SliderDefaults.colors(
                                    thumbColor = ResonanceCyan,
                                    activeTrackColor = ResonanceCyan,
                                    inactiveTrackColor = Color(0xFF1C2434)
                                )
                            )
                            Text(
                                text = "%+.1f dB".format(gain),
                                style = MaterialTheme.typography.bodySmall.copy(fontSize = 10.sp),
                                color = if (gain != 0f) ResonanceAmber else TextMuted,
                                modifier = Modifier.width(52.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Bass Boost Slider
                    Text(
                        text = "Hardware Bass Boost (${eqConfig.bassBoostStrength / 10}%)",
                        style = MaterialTheme.typography.labelMedium,
                        color = TextSecondary
                    )
                    Slider(
                        value = eqConfig.bassBoostStrength.toFloat(),
                        onValueChange = { viewModel.applyBassBoost(it.toInt()) },
                        valueRange = 0f..1000f,
                        colors = SliderDefaults.colors(
                            thumbColor = ResonanceAmber,
                            activeTrackColor = ResonanceAmber,
                            inactiveTrackColor = Color(0xFF1C2434)
                        ),
                        modifier = Modifier.testTag("bass_boost_slider")
                    )
                }
            }
            1 -> {
                // Pitch & Tempo DSP
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(18.dp))
                        .background(Color(0xFF090D15))
                        .border(1.dp, Color(0xFF1E2638), RoundedCornerShape(18.dp))
                        .padding(16.dp)
                ) {
                    Text(
                        text = "Real-Time DSP Pitch & Tempo Shifter",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = Color.White
                    )
                    Text(
                        text = "Independently alter speed without altering key, or link them for analog tape/vinyl effects",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    // Playback Tempo (Speed: 0.25x to 3.0x)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(text = "Tempo (Playback Speed)", color = TextPrimary, style = MaterialTheme.typography.bodyMedium)
                        Text(text = "%.2fx".format(eqConfig.playbackTempo), color = ResonanceCyan, fontWeight = FontWeight.Bold)
                    }
                    Slider(
                        value = eqConfig.playbackTempo,
                        onValueChange = {
                            viewModel.applyPitchAndTempo(eqConfig.playbackPitch, it, eqConfig.linkPitchTempo)
                        },
                        valueRange = 0.25f..3.0f,
                        colors = SliderDefaults.colors(thumbColor = ResonanceCyan, activeTrackColor = ResonanceCyan),
                        modifier = Modifier.testTag("tempo_slider")
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    // Playback Pitch (0.5x to 2.0x, ±12 semitones)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(text = "Pitch Key Shifter", color = TextPrimary, style = MaterialTheme.typography.bodyMedium)
                        Text(text = "%.2fx Key".format(eqConfig.playbackPitch), color = ResonanceAmber, fontWeight = FontWeight.Bold)
                    }
                    Slider(
                        value = eqConfig.playbackPitch,
                        onValueChange = {
                            viewModel.applyPitchAndTempo(it, eqConfig.playbackTempo, false)
                        },
                        enabled = !eqConfig.linkPitchTempo,
                        valueRange = 0.5f..2.0f,
                        colors = SliderDefaults.colors(thumbColor = ResonanceAmber, activeTrackColor = ResonanceAmber),
                        modifier = Modifier.testTag("pitch_slider")
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    // Link Pitch & Tempo (Classic Tape Effect)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color(0xFF121723))
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(text = "Link Pitch & Tempo (Tape / Vinyl Speed)", color = Color.White, style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold))
                            Text(text = "Speeding up raises pitch proportionally", color = TextMuted, style = MaterialTheme.typography.labelSmall)
                        }
                        Switch(
                            checked = eqConfig.linkPitchTempo,
                            onCheckedChange = {
                                viewModel.applyPitchAndTempo(eqConfig.playbackTempo, eqConfig.playbackTempo, it)
                            },
                            colors = SwitchDefaults.colors(checkedThumbColor = ResonanceCyan)
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Stereo Balance Slider (Left / Right)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(text = "Stereo Balance", color = TextPrimary, style = MaterialTheme.typography.bodyMedium)
                        Text(
                            text = when {
                                eqConfig.channelBalance < -0.05f -> "L %d%%".format((-eqConfig.channelBalance * 100).toInt())
                                eqConfig.channelBalance > 0.05f -> "R %d%%".format((eqConfig.channelBalance * 100).toInt())
                                else -> "Center"
                            },
                            color = Color.White,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Slider(
                        value = eqConfig.channelBalance,
                        onValueChange = { viewModel.applyChannelBalance(it) },
                        valueRange = -1.0f..1.0f,
                        colors = SliderDefaults.colors(thumbColor = Color.White, activeTrackColor = ResonanceCyan)
                    )
                }
            }
            2 -> {
                // AutoEQ Profiles View
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(18.dp))
                        .background(Color(0xFF090D15))
                        .border(1.dp, Color(0xFF1E2638), RoundedCornerShape(18.dp))
                        .padding(16.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "AutoEQ Calibration Presets",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = Color.White
                        )
                        Button(
                            onClick = { showAutoEqDialog = true },
                            colors = ButtonDefaults.buttonColors(containerColor = ResonanceAmber),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                            modifier = Modifier.testTag("import_autoeq_btn")
                        ) {
                            Icon(imageVector = Icons.Default.FileOpen, contentDescription = null, modifier = Modifier.size(16.dp), tint = Color.Black)
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Import .txt/.csv", color = Color.Black, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    AutoEqParser.BUILTIN_PROFILES.forEach { profile ->
                        val isCurrent = eqConfig.activeAutoEqProfileName == profile.name
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(if (isCurrent) Color(0xFF003842) else Color(0xFF101520))
                                .clickable {
                                    viewModel.loadAutoEqProfile(profile)
                                    Toast.makeText(context, "Applied ${profile.name}", Toast.LENGTH_SHORT).show()
                                }
                                .padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = profile.name,
                                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                                    color = if (isCurrent) ResonanceCyan else Color.White
                                )
                                Text(
                                    text = profile.description,
                                    style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                                    color = TextSecondary
                                )
                            }
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(Color(0xFF1E2838))
                                    .padding(horizontal = 6.dp, vertical = 4.dp)
                            ) {
                                Text(
                                    text = profile.targetDeviceType,
                                    style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp),
                                    color = ResonanceAmber
                                )
                            }
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))
    }

    // AutoEQ Raw Text / CSV Importer Dialog
    if (showAutoEqDialog) {
        Dialog(onDismissRequest = { showAutoEqDialog = false }) {
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = Color(0xFF0F1420),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF263145)),
                modifier = Modifier.fillMaxWidth().padding(8.dp)
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Text(
                        text = "Import AutoEQ Frequency Response",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = Color.White
                    )
                    Text(
                        text = "Paste standard GraphicEQ line or CSV frequencies:",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = rawAutoEqText,
                        onValueChange = { rawAutoEqText = it },
                        placeholder = { Text("GraphicEQ: 31 1.2; 62 2.5; 125 0.5; ...\nor 31,1.2\n62,2.5") },
                        modifier = Modifier.fillMaxWidth().height(140.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextSecondary
                        )
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        TextButton(onClick = { showAutoEqDialog = false }) {
                            Text("Cancel", color = TextSecondary)
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Button(
                            onClick = {
                                if (rawAutoEqText.isNotBlank()) {
                                    viewModel.importAutoEqRawText(rawAutoEqText, "Custom AutoEQ Import")
                                    showAutoEqDialog = false
                                    Toast.makeText(context, "Loaded Custom AutoEQ Profile", Toast.LENGTH_SHORT).show()
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = ResonanceCyan)
                        ) {
                            Text("Apply Profile", color = Color.Black, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}
