package com.example.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.Bedtime
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.SleepTimerConfig
import com.example.model.Track
import com.example.ui.theme.*

@Composable
fun SleepBedtimeView(
    track: Track?,
    isPlaying: Boolean,
    sleepTimer: SleepTimerConfig,
    onSetSleepTimer: (minutes: Int, finishLastSongFirst: Boolean) -> Unit,
    onCancelSleepTimer: () -> Unit,
    onTogglePlayPause: () -> Unit,
    onNext: () -> Unit,
    onPrevious: () -> Unit,
    modifier: Modifier = Modifier
) {
    var finishLastSong by remember { mutableStateOf(sleepTimer.finishLastSongFirst) }

    // Ambient soothing pulsing glow
    val infiniteTransition = rememberInfiniteTransition(label = "sleep_glow")
    val glowAlpha by infiniteTransition.animateFloat(
        initialValue = 0.2f,
        targetValue = 0.5f,
        animationSpec = infiniteRepeatable(
            animation = tween(4000, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "glowAlpha"
    )

    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(24.dp))
            .background(Color(0xFF07090E))
            .border(1.dp, Color(0xFF1B2232), RoundedCornerShape(24.dp))
            .padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Bedtime Banner Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(ResonanceCyanGlow),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Outlined.Bedtime,
                        contentDescription = "Bedtime Sleep Mode",
                        tint = ResonanceCyan,
                        modifier = Modifier.size(20.dp)
                    )
                }
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text(
                        text = "Bedtime Sleep Sanctuary",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = Color.White
                    )
                    Text(
                        text = if (sleepTimer.isActive) "Auto-pauses without disrupting sleep" else "Select a timer preset to enable",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )
                }
            }

            if (sleepTimer.isActive) {
                TextButton(
                    onClick = onCancelSleepTimer,
                    modifier = Modifier.testTag("cancel_sleep_timer_btn")
                ) {
                    Text("Turn Off", color = Color(0xFFFF5252), fontSize = 12.sp)
                }
            }
        }

        Spacer(modifier = Modifier.height(18.dp))

        // Center Big Countdown Clock / Status
        Box(
            modifier = Modifier
                .size(170.dp)
                .clip(CircleShape)
                .background(
                    Brush.radialGradient(
                        listOf(
                            ResonanceCyan.copy(alpha = if (sleepTimer.isActive) glowAlpha else 0.05f),
                            Color(0xFF0F1420),
                            Color(0xFF07090E)
                        )
                    )
                )
                .border(
                    2.dp,
                    if (sleepTimer.isCurrentlyFading) ResonanceAmber else if (sleepTimer.isActive) ResonanceCyan else Color(0xFF222B3B),
                    CircleShape
                ),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                if (sleepTimer.isActive) {
                    val mins = sleepTimer.remainingSeconds / 60
                    val secs = sleepTimer.remainingSeconds % 60
                    Text(
                        text = "%02d:%02d".format(mins, secs),
                        style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Bold),
                        color = Color.White
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = if (sleepTimer.isCurrentlyFading) "Fading Out Volume..." else "Timer Active",
                        style = MaterialTheme.typography.labelSmall,
                        color = if (sleepTimer.isCurrentlyFading) ResonanceAmber else ResonanceCyan
                    )
                } else {
                    Icon(
                        imageVector = Icons.Default.Bedtime,
                        contentDescription = null,
                        tint = TextMuted,
                        modifier = Modifier.size(36.dp)
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Timer Off",
                        style = MaterialTheme.typography.titleSmall,
                        color = TextSecondary
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(18.dp))

        // Quick Preset Chips
        Text(
            text = "Bedtime Timer Presets",
            style = MaterialTheme.typography.labelMedium,
            color = TextSecondary,
            modifier = Modifier.align(Alignment.Start)
        )
        Spacer(modifier = Modifier.height(8.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            listOf(15, 30, 45, 60).forEach { mins ->
                val isSelected = sleepTimer.isActive && sleepTimer.totalDurationMinutes == mins
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(12.dp))
                        .background(if (isSelected) ResonanceCyan else Color(0xFF131924))
                        .clickable { onSetSleepTimer(mins, finishLastSong) }
                        .padding(vertical = 10.dp)
                        .testTag("preset_${mins}m_btn"),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "${mins}m",
                        color = if (isSelected) AmoledBlack else TextPrimary,
                        style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // "Finish Last Song First" Toggle Card
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(14.dp))
                .background(Color(0xFF101520))
                .padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "Finish Last Song First",
                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
                    color = Color.White
                )
                Text(
                    text = "Never cuts off mid-track; finishes the final track before sleeping",
                    style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                    color = TextSecondary
                )
            }
            Switch(
                checked = finishLastSong,
                onCheckedChange = {
                    finishLastSong = it
                    if (sleepTimer.isActive) {
                        onSetSleepTimer(sleepTimer.totalDurationMinutes, it)
                    }
                },
                colors = SwitchDefaults.colors(
                    checkedThumbColor = ResonanceCyan,
                    checkedTrackColor = Color(0xFF003842),
                    uncheckedTrackColor = Color(0xFF1C2433)
                ),
                modifier = Modifier.testTag("finish_last_song_toggle")
            )
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Gentle 60s Fade-Out Info Note
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Default.VolumeDown,
                contentDescription = null,
                tint = ResonanceAmber,
                modifier = Modifier.size(14.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = "Includes gentle 60-second volume fade-down curve",
                style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                color = TextSecondary
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Soothing Playback Controls Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = onPrevious,
                modifier = Modifier
                    .size(48.dp)
                    .clip(CircleShape)
                    .background(Color(0xFF131824))
                    .testTag("bedtime_prev_btn")
            ) {
                Icon(
                    imageVector = Icons.Default.SkipPrevious,
                    contentDescription = "Previous Track",
                    tint = Color.White
                )
            }

            IconButton(
                onClick = onTogglePlayPause,
                modifier = Modifier
                    .size(64.dp)
                    .clip(CircleShape)
                    .background(ResonanceCyan)
                    .testTag("bedtime_play_pause_btn")
            ) {
                Icon(
                    imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                    contentDescription = if (isPlaying) "Pause" else "Play",
                    tint = AmoledBlack,
                    modifier = Modifier.size(36.dp)
                )
            }

            IconButton(
                onClick = onNext,
                modifier = Modifier
                    .size(48.dp)
                    .clip(CircleShape)
                    .background(Color(0xFF131824))
                    .testTag("bedtime_next_btn")
            ) {
                Icon(
                    imageVector = Icons.Default.SkipNext,
                    contentDescription = "Next Track",
                    tint = Color.White
                )
            }
        }
    }
}
