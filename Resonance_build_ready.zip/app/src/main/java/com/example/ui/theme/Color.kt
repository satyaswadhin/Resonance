package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Pure Pitch Black AMOLED Base (0% emission for OLED displays)
val AmoledBlack = Color(0xFF000000)

// Layered Audiophile Dark Surfaces (Smoked Obsidian & Polished Titanium Depth)
val DarkSurface1 = Color(0xFF080B11) // Level 1: Subtly elevated canvas for bottom sheets & panels
val DarkSurface2 = Color(0xFF0E131E) // Level 2: Crisp card bodies, floating dock & search containers
val DarkSurface3 = Color(0xFF161F2E) // Level 3: Elevated control capsules, pills & chip backgrounds
val DarkSurfaceElevated = Color(0xFF1D283C) // Level 4: Modal dialogs, popup menus & active surfaces

// Precision Hairline Structural Borders (Tactile definition against #000000)
val HairlineBorder = Color(0xFF1F293D)
val HairlineBorderActive = Color(0xFF2E3D56)

// Translucent Frosted Liquid Glass
val LiquidGlassSurface = Color(0xE00C111C)
val LiquidGlassBorder = Color(0x40364866)

// High-End Audio Equipment Accent Signatures
val ChampagneGold = Color(0xFFE5C07B) // Astell&Kern / Sony Signature DAP Gold
val ChampagneGoldGlow = Color(0x33E5C07B)

val EchoCoral = Color(0xFFFF5E7E) // Echo's warm radiant coral signature
val EchoCoralGlow = Color(0x33FF5E7E)

val CyberCyan = Color(0xFF00E5FF) // Studio DAC & DSP Monitor Cyan
val CyberCyanGlow = Color(0x3300E5FF)

val EmeraldNeon = Color(0xFF00E676) // High-Res DSD / Master Emerald
val EmeraldGlow = Color(0x3300E676)

val AmethystViolet = Color(0xFFB388FF) // Luminous luxury amethyst
val AmethystGlow = Color(0x33B388FF)

val SolarAmber = Color(0xFFFF9E1B) // Analog vacuum tube filament glow
val SolarAmberGlow = Color(0x33FF9E1B)

val HotMagenta = Color(0xFFFF3377) // Radiant punchy magenta
val HotMagentaGlow = Color(0x33FF3377)

val CobaltBlue = Color(0xFF3D82FF) // Precision brushed sapphire
val CobaltGlow = Color(0x333D82FF)

// Background Base Styles (Deep Dark Tones)
val MidnightObsidian = Color(0xFF05080E)
val CharcoalSlate = Color(0xFF0A0D14)
val VelvetWine = Color(0xFF0C0306)
val SapphireObsidian = Color(0xFF030711)
val EmeraldObsidian = Color(0xFF020A05)

// Maximum Contrast & Readability Typography Tokens (WCAG AAA against #000000)
val TextPrimary = Color(0xFFFFFFFF) // 21:1 Pristine White for titles & track names
val TextSecondary = Color(0xFFB8C4D8) // 10.5:1 High-clarity platinum for artists & body
val TextMuted = Color(0xFF7A899F) // 5.5:1 Crisp steel silver for timestamps, formats, metadata
val TextDisabled = Color(0xFF475263)

// Backward-compatible aliases
val ResonanceCyan = CyberCyan
val ResonanceCyanGlow = CyberCyanGlow
val ResonanceAmber = SolarAmber
val ResonanceAmberDim = SolarAmberGlow
val ResonanceViolet = AmethystViolet

