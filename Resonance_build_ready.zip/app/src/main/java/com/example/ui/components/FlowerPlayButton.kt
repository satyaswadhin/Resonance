package com.example.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.GenericShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Icon
import androidx.compose.material3.ripple
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/**
 * Creates the iconic 8-petal scalloped flower / starburst squircle shape
 * seen in modern Android music players (SimpMusic / InnerTune / ViMusic style).
 */
val ScallopedFlowerShape: Shape = GenericShape { size, _ ->
    val cx = size.width / 2f
    val cy = size.height / 2f
    val outerRadius = (size.width.coerceAtMost(size.height) / 2f) * 0.98f
    val innerRadius = outerRadius * 0.78f // subtle scalloped waist
    val petals = 8
    val points = petals * 2
    val step = (2.0 * PI / points).toFloat()

    val path = Path()
    var isFirst = true

    for (i in 0 until points) {
        val angle = i * step - (PI / 2f).toFloat()
        val r = if (i % 2 == 0) outerRadius else innerRadius
        val x = cx + r * cos(angle)
        val y = cy + r * sin(angle)

        if (isFirst) {
            path.moveTo(x, y)
            isFirst = false
        } else {
            // Cubic curve to round the petal smoothly
            val prevAngle = (i - 1) * step - (PI / 2f).toFloat()
            val prevR = if ((i - 1) % 2 == 0) outerRadius else innerRadius
            val cpAngle = prevAngle + step / 2f
            val cpR = (prevR + r) / 2f * 1.05f
            val cpx = cx + cpR * cos(cpAngle)
            val cpy = cy + cpR * sin(cpAngle)
            path.quadraticTo(cpx, cpy, x, y)
        }
    }
    // Connect back to start
    val angle0 = - (PI / 2f).toFloat()
    val r0 = outerRadius
    val endAngle = (points - 1) * step - (PI / 2f).toFloat()
    val endR = innerRadius
    val cpAngle = endAngle + step / 2f
    val cpR = (endR + r0) / 2f * 1.05f
    path.quadraticTo(cx + cpR * cos(cpAngle), cy + cpR * sin(cpAngle), cx + r0 * cos(angle0), cy + r0 * sin(angle0))
    path.close()

    addPath(path)
}

/**
 * FlowerPlayButton: The signature scalloped play/pause button.
 */
@Composable
fun FlowerPlayButton(
    isPlaying: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    size: Dp = 68.dp,
    containerColor: Color = Color.White,
    contentColor: Color = Color(0xFF0C0F17),
    testTag: String = "echo_play_pause_btn"
) {
    val scale by animateFloatAsState(
        targetValue = if (isPlaying) 1.0f else 0.96f,
        animationSpec = spring(dampingRatio = 0.65f),
        label = "flower_scale"
    )

    Box(
        modifier = modifier
            .size(size)
            .scale(scale)
            .shadow(elevation = 12.dp, shape = ScallopedFlowerShape, ambientColor = containerColor.copy(alpha = 0.35f), spotColor = containerColor.copy(alpha = 0.5f))
            .clip(ScallopedFlowerShape)
            .background(containerColor)
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = ripple(bounded = true, color = contentColor.copy(alpha = 0.2f)),
                onClick = onClick
            )
            .testTag(testTag),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
            contentDescription = if (isPlaying) "Pause" else "Play",
            tint = contentColor,
            modifier = Modifier.size(size * 0.52f)
        )
    }
}
