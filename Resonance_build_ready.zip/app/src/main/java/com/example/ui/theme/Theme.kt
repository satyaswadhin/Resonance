package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import com.example.model.BackgroundStyle
import com.example.model.EchoThemeSettings

@Composable
fun ResonanceTheme(
    themeSettings: EchoThemeSettings = EchoThemeSettings(),
    content: @Composable () -> Unit
) {
    val accent = themeSettings.accentColor
    val bg = themeSettings.backgroundStyle.color
    val surface = when (themeSettings.backgroundStyle) {
        BackgroundStyle.AMOLED_BLACK -> DarkSurface2
        BackgroundStyle.MIDNIGHT_OBSIDIAN -> Color(0xFF0C1019)
        BackgroundStyle.CHARCOAL_SLATE -> Color(0xFF111622)
        BackgroundStyle.VELVET_WINE -> Color(0xFF14080D)
        BackgroundStyle.SAPPHIRE_OBSIDIAN -> Color(0xFF090E1C)
        BackgroundStyle.EMERALD_OBSIDIAN -> Color(0xFF07120C)
    }

    val dynamicScheme = darkColorScheme(
        primary = accent,
        onPrimary = Color.Black,
        primaryContainer = accent.copy(alpha = 0.22f),
        onPrimaryContainer = Color.White,
        secondary = ChampagneGold,
        onSecondary = Color.Black,
        secondaryContainer = Color(0xFF382910),
        onSecondaryContainer = Color(0xFFFFECC4),
        tertiary = AmethystViolet,
        background = bg,
        onBackground = TextPrimary,
        surface = surface,
        onSurface = TextPrimary,
        surfaceVariant = DarkSurface3,
        onSurfaceVariant = TextSecondary,
        outline = HairlineBorder,
        outlineVariant = HairlineBorderActive
    )

    MaterialTheme(
        colorScheme = dynamicScheme,
        typography = Typography,
        content = content
    )
}

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true,
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    ResonanceTheme(content = content)
}
