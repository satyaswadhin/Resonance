package com.example.ui.components

import android.media.MediaPlayer
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.parser.FolderScanner
import com.example.model.Track
import com.example.ui.theme.*
import com.example.util.TrimConfig
import com.example.util.TrimMode
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun ClideoAudioCutterDialog(
    track: Track,
    accentColor: Color,
    onExportTrim: (TrimConfig) -> Unit,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    val totalDurationMs = track.durationMs.coerceAtLeast(5000L)

    // Selection ranges in milliseconds
    var startMs by remember { mutableStateOf((totalDurationMs * 0.15f).toLong()) }
    var endMs by remember { mutableStateOf((totalDurationMs * 0.75f).toLong().coerceAtLeast(startMs + 1000L)) }

    // Mode: Extract Selected or Delete Selected (as seen in Clideo screenshot)
    var trimMode by remember { mutableStateOf(TrimMode.EXTRACT_SELECTED) }

    // Fades
    var fadeIn by remember { mutableStateOf(false) }
    var fadeOut by remember { mutableStateOf(false) }

    // Output Format
    var selectedFormat by remember { mutableStateOf("MP3") }
    var isFormatDropdownOpen by remember { mutableStateOf(false) }

    // Preview Player State
    var isPreviewPlaying by remember { mutableStateOf(false) }
    var previewPositionMs by remember { mutableStateOf(startMs) }
    var previewPlayer by remember { mutableStateOf<MediaPlayer?>(null) }

    // Waveform points
    val waveformPoints = remember(track.id) {
        FolderScanner.generateWaveformPoints(track.id, count = 75)
    }

    // Cleanup MediaPlayer on exit
    DisposableEffect(track) {
        onDispose {
            try {
                previewPlayer?.stop()
                previewPlayer?.release()
                previewPlayer = null
            } catch (_: Exception) {}
        }
    }

    // Preview play loop
    LaunchedEffect(isPreviewPlaying, startMs, endMs) {
        if (isPreviewPlaying) {
            try {
                if (previewPlayer == null) {
                    val p = MediaPlayer().apply {
                        if (track.filePath.startsWith("/Internal Storage") || !java.io.File(track.filePath).exists()) {
                            // If virtual track, play using track URI or tone
                            setDataSource(context, track.uri)
                        } else {
                            setDataSource(track.filePath)
                        }
                        prepare()
                    }
                    previewPlayer = p
                }

                previewPlayer?.let { player ->
                    player.seekTo(previewPositionMs.toInt())
                    player.start()

                    while (isPreviewPlaying && player.isPlaying) {
                        val pos = player.currentPosition.toLong()
                        previewPositionMs = pos

                        if (trimMode == TrimMode.EXTRACT_SELECTED) {
                            if (pos >= endMs || pos < startMs) {
                                player.pause()
                                previewPositionMs = startMs
                                isPreviewPlaying = false
                                break
                            }
                        } else {
                            // Delete selected: skip over startMs..endMs
                            if (pos in startMs..endMs) {
                                player.seekTo(endMs.toInt())
                            }
                        }
                        delay(50)
                    }
                }
            } catch (e: Exception) {
                // If native audio file unavailable, simulate smooth preview playhead
                while (isPreviewPlaying) {
                    delay(50)
                    previewPositionMs += 50
                    if (previewPositionMs >= endMs) {
                        previewPositionMs = startMs
                        isPreviewPlaying = false
                        break
                    }
                }
            }
        } else {
            try {
                previewPlayer?.pause()
            } catch (_: Exception) {}
        }
    }

    // Calculated Final Output Duration
    val outputDurationMs = remember(startMs, endMs, trimMode, totalDurationMs) {
        if (trimMode == TrimMode.EXTRACT_SELECTED) {
            (endMs - startMs).coerceAtLeast(0L)
        } else {
            (totalDurationMs - (endMs - startMs)).coerceAtLeast(0L)
        }
    }

    fun formatTimePrecision(ms: Long): String {
        val totalSecs = ms / 1000
        val minutes = totalSecs / 60
        val seconds = totalSecs % 60
        val hundredths = (ms % 1000) / 10
        return "%02d:%02d.%02d".format(minutes, seconds, hundredths)
    }

    fun formatDurationSimple(ms: Long): String {
        val totalSecs = ms / 1000
        val minutes = totalSecs / 60
        val seconds = totalSecs % 60
        return "%02d:%02d".format(minutes, seconds)
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxSize()
                .padding(top = 28.dp),
            color = DarkSurface1,
            border = androidx.compose.foundation.BorderStroke(1.dp, HairlineBorder),
            shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 16.dp, vertical = 12.dp)
            ) {
                // Top Header: Close button, Clideo Branding & Track Info
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(DarkSurface2)
                            .border(1.dp, HairlineBorder, CircleShape)
                    ) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = TextPrimary)
                    }

                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(imageVector = Icons.Default.ContentCut, contentDescription = null, tint = Color(0xFF1E88E5), modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Cut Audio",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                color = TextPrimary
                            )
                        }
                        Text(
                            text = track.title,
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary,
                            maxLines = 1
                        )
                    }

                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0xFF161B26))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = track.format,
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                            color = Color(0xFF1E88E5)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(18.dp))

                // Clideo Waveform Card with Draggable Yellow Handles
                var waveformSize by remember { mutableStateOf(IntSize.Zero) }

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(130.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(Color(0xFF121622))
                        .border(1.dp, Color(0xFF1E2638), RoundedCornerShape(14.dp))
                        .onSizeChanged { waveformSize = it }
                ) {
                    val widthPx = waveformSize.width.toFloat().coerceAtLeast(1f)
                    val heightPx = waveformSize.height.toFloat().coerceAtLeast(1f)

                    val startFrac = (startMs.toFloat() / totalDurationMs.toFloat()).coerceIn(0f, 0.98f)
                    val endFrac = (endMs.toFloat() / totalDurationMs.toFloat()).coerceIn(startFrac + 0.02f, 1f)

                    val startX = startFrac * widthPx
                    val endX = endFrac * widthPx

                    // Waveform Canvas
                    androidx.compose.foundation.Canvas(modifier = Modifier.fillMaxSize()) {
                        val barCount = waveformPoints.size
                        val barSpacing = size.width / barCount
                        val barWidth = barSpacing * 0.65f
                        val centerY = size.height / 2f

                        // Draw Waveform Bars
                        waveformPoints.forEachIndexed { i, point ->
                            val x = i * barSpacing + barSpacing / 2f
                            val barHeight = point * (size.height * 0.78f)

                            val isInActiveRange = x in startX..endX
                            val barColor = if (isInActiveRange) {
                                Color(0xFF00E5FF)
                            } else {
                                Color(0xFF4B5568)
                            }

                            drawRoundRect(
                                color = barColor,
                                topLeft = Offset(x - barWidth / 2f, centerY - barHeight / 2f),
                                size = Size(barWidth, barHeight),
                                cornerRadius = androidx.compose.ui.geometry.CornerRadius(3f, 3f)
                            )
                        }

                        // Background overlays matching Clideo
                        // Left Dimmed Region
                        drawRect(
                            color = Color(0x99080B12),
                            topLeft = Offset(0f, 0f),
                            size = Size(startX, size.height)
                        )

                        // Selected Region Highlight (Clideo Vibrant Royal Blue)
                        drawRect(
                            color = Color(0x331E88E5),
                            topLeft = Offset(startX, 0f),
                            size = Size(endX - startX, size.height)
                        )

                        // Right Dimmed Region
                        drawRect(
                            color = Color(0x99080B12),
                            topLeft = Offset(endX, 0f),
                            size = Size(size.width - endX, size.height)
                        )

                        // Playhead line when previewing
                        val playheadFrac = (previewPositionMs.toFloat() / totalDurationMs.toFloat()).coerceIn(0f, 1f)
                        val playheadX = playheadFrac * size.width
                        drawLine(
                            color = Color.White,
                            start = Offset(playheadX, 0f),
                            end = Offset(playheadX, size.height),
                            strokeWidth = 3f
                        )
                    }

                    // Draggable Left Handle (Clideo Yellow Handle with Vertical Grab Bar)
                    Box(
                        modifier = Modifier
                            .offset(
                                x = with(androidx.compose.ui.platform.LocalDensity.current) {
                                    (startX - 12.dp.toPx() / 2).coerceAtLeast(0f).toDp()
                                }
                            )
                            .width(14.dp)
                            .fillMaxHeight()
                            .clip(RoundedCornerShape(4.dp))
                            .background(Color(0xFFF5BA13))
                            .pointerInput(totalDurationMs) {
                                detectDragGestures { change, dragAmount ->
                                    change.consume()
                                    val deltaMs = ((dragAmount.x / widthPx) * totalDurationMs).toLong()
                                    val newStart = (startMs + deltaMs).coerceIn(0L, endMs - 1000L)
                                    startMs = newStart
                                    previewPositionMs = newStart
                                }
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        // Grab notch
                        Box(
                            modifier = Modifier
                                .width(2.5.dp)
                                .height(24.dp)
                                .clip(RoundedCornerShape(1.dp))
                                .background(Color(0xFF231B04))
                        )
                    }

                    // Draggable Right Handle (Clideo Yellow Handle with Vertical Grab Bar)
                    Box(
                        modifier = Modifier
                            .offset(
                                x = with(androidx.compose.ui.platform.LocalDensity.current) {
                                    (endX - 14.dp.toPx() / 2).coerceAtMost(widthPx - 14.dp.toPx()).toDp()
                                }
                            )
                            .width(14.dp)
                            .fillMaxHeight()
                            .clip(RoundedCornerShape(4.dp))
                            .background(Color(0xFFF5BA13))
                            .pointerInput(totalDurationMs) {
                                detectDragGestures { change, dragAmount ->
                                    change.consume()
                                    val deltaMs = ((dragAmount.x / widthPx) * totalDurationMs).toLong()
                                    val newEnd = (endMs + deltaMs).coerceIn(startMs + 1000L, totalDurationMs)
                                    endMs = newEnd
                                }
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        // Grab notch
                        Box(
                            modifier = Modifier
                                .width(2.5.dp)
                                .height(24.dp)
                                .clip(RoundedCornerShape(1.dp))
                                .background(Color(0xFF231B04))
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Playback Control & Timestamp (As seen in Clideo screenshot)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Preview Play/Pause Button
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .clip(RoundedCornerShape(24.dp))
                            .background(Color(0xFF141926))
                            .clickable {
                                isPreviewPlaying = !isPreviewPlaying
                                if (isPreviewPlaying && (previewPositionMs < startMs || previewPositionMs >= endMs)) {
                                    previewPositionMs = startMs
                                }
                            }
                            .padding(horizontal = 14.dp, vertical = 6.dp)
                    ) {
                        Icon(
                            imageVector = if (isPreviewPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                            contentDescription = if (isPreviewPlaying) "Pause" else "Play",
                            tint = Color(0xFFF5BA13),
                            modifier = Modifier.size(26.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (isPreviewPlaying) "Previewing" else "Preview Trim",
                            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                            color = Color.White
                        )
                    }

                    // Timestamp display: 01:07 / 03:45
                    Text(
                        text = "${formatDurationSimple(previewPositionMs)} / ${formatDurationSimple(totalDurationMs)}",
                        style = MaterialTheme.typography.bodyMedium.copy(fontFamily = FontFamily.Monospace, fontWeight = FontWeight.SemiBold),
                        color = Color.White
                    )
                }

                Spacer(modifier = Modifier.height(20.dp))
                HorizontalDivider(color = Color(0xFF1A2130), thickness = 1.dp)
                Spacer(modifier = Modifier.height(16.dp))

                // Radio Buttons: Extract Selected vs Delete Selected (Clideo screenshot)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .clickable { trimMode = TrimMode.EXTRACT_SELECTED }
                            .padding(6.dp)
                    ) {
                        RadioButton(
                            selected = trimMode == TrimMode.EXTRACT_SELECTED,
                            onClick = { trimMode = TrimMode.EXTRACT_SELECTED },
                            colors = RadioButtonDefaults.colors(selectedColor = Color(0xFF1E88E5), unselectedColor = Color(0xFF4A5568))
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "Extract Selected",
                            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
                            color = if (trimMode == TrimMode.EXTRACT_SELECTED) Color.White else TextSecondary
                        )
                    }

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .clickable { trimMode = TrimMode.DELETE_SELECTED }
                            .padding(6.dp)
                    ) {
                        RadioButton(
                            selected = trimMode == TrimMode.DELETE_SELECTED,
                            onClick = { trimMode = TrimMode.DELETE_SELECTED },
                            colors = RadioButtonDefaults.colors(selectedColor = Color(0xFF1E88E5), unselectedColor = Color(0xFF4A5568))
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "Delete Selected",
                            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
                            color = if (trimMode == TrimMode.DELETE_SELECTED) Color.White else TextSecondary
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // "Cut from:" Section with Time Boxes (Exact Clideo UI)
                Text(
                    text = "Cut from:",
                    style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Medium),
                    color = TextSecondary,
                    modifier = Modifier.fillMaxWidth(),
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Start Time Box with nudge controls
                    TimeInputPill(
                        timeLabel = formatTimePrecision(startMs),
                        onDecrease = {
                            startMs = (startMs - 500L).coerceAtLeast(0L)
                            previewPositionMs = startMs
                        },
                        onIncrease = {
                            startMs = (startMs + 500L).coerceAtMost(endMs - 1000L)
                            previewPositionMs = startMs
                        }
                    )

                    Spacer(modifier = Modifier.width(14.dp))
                    Text(text = "to", color = TextSecondary, fontSize = 14.sp)
                    Spacer(modifier = Modifier.width(14.dp))

                    // End Time Box with nudge controls
                    TimeInputPill(
                        timeLabel = formatTimePrecision(endMs),
                        onDecrease = {
                            endMs = (endMs - 500L).coerceAtLeast(startMs + 1000L)
                        },
                        onIncrease = {
                            endMs = (endMs + 500L).coerceAtMost(totalDurationMs)
                        }
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Quick Nudge Buttons: Trim start/end presets
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    QuickPresetChip(
                        label = "-10s Start",
                        modifier = Modifier.weight(1f),
                        onClick = {
                            startMs = (startMs + 10000L).coerceAtMost(endMs - 1000L)
                            previewPositionMs = startMs
                        }
                    )
                    QuickPresetChip(
                        label = "-30s Start",
                        modifier = Modifier.weight(1f),
                        onClick = {
                            startMs = (startMs + 30000L).coerceAtMost(endMs - 1000L)
                            previewPositionMs = startMs
                        }
                    )
                    QuickPresetChip(
                        label = "-15s End",
                        modifier = Modifier.weight(1f),
                        onClick = {
                            endMs = (endMs - 15000L).coerceAtLeast(startMs + 1000L)
                        }
                    )
                    QuickPresetChip(
                        label = "Reset Full",
                        modifier = Modifier.weight(1f),
                        onClick = {
                            startMs = 0L
                            endMs = totalDurationMs
                            previewPositionMs = 0L
                        }
                    )
                }

                Spacer(modifier = Modifier.height(20.dp))

                // Fade In & Fade Out Checkboxes (Clideo UI)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.clickable { fadeIn = !fadeIn }.padding(8.dp)
                    ) {
                        Checkbox(
                            checked = fadeIn,
                            onCheckedChange = { fadeIn = it },
                            colors = CheckboxDefaults.colors(checkedColor = Color(0xFF1E88E5), checkmarkColor = Color.White)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(text = "Fade in", color = Color.White, fontSize = 13.sp)
                    }

                    Spacer(modifier = Modifier.width(28.dp))

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.clickable { fadeOut = !fadeOut }.padding(8.dp)
                    ) {
                        Checkbox(
                            checked = fadeOut,
                            onCheckedChange = { fadeOut = it },
                            colors = CheckboxDefaults.colors(checkedColor = Color(0xFF1E88E5), checkmarkColor = Color.White)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(text = "Fade out", color = Color.White, fontSize = 13.sp)
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Final Output Duration Label
                Text(
                    text = "Final output — ${formatDurationSimple(outputDurationMs)}",
                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Medium),
                    color = TextSecondary,
                    modifier = Modifier.fillMaxWidth(),
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Format Selector: Format — MP3 ▾
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(text = "Format — ", color = TextSecondary, fontSize = 13.sp)
                    Box {
                        Row(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color(0xFF141926))
                                .clickable { isFormatDropdownOpen = true }
                                .padding(horizontal = 10.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(text = selectedFormat, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Spacer(modifier = Modifier.width(4.dp))
                            Icon(imageVector = Icons.Default.ArrowDropDown, contentDescription = null, tint = TextSecondary, modifier = Modifier.size(18.dp))
                        }

                        DropdownMenu(
                            expanded = isFormatDropdownOpen,
                            onDismissRequest = { isFormatDropdownOpen = false },
                            modifier = Modifier.background(Color(0xFF141926))
                        ) {
                            listOf("MP3", "WAV", "FLAC", "M4A").forEach { fmt ->
                                DropdownMenuItem(
                                    text = { Text(fmt, color = Color.White) },
                                    onClick = {
                                        selectedFormat = fmt
                                        isFormatDropdownOpen = false
                                    }
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))

                // Export Button (Clideo Vibrant Royal Blue)
                Button(
                    onClick = {
                        val config = TrimConfig(
                            startMs = startMs,
                            endMs = endMs,
                            mode = trimMode,
                            fadeIn = fadeIn,
                            fadeOut = fadeOut,
                            format = selectedFormat
                        )
                        onExportTrim(config)
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .testTag("clideo_export_btn"),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E88E5)),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(imageVector = Icons.Default.ContentCut, contentDescription = null, tint = Color.White)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Export",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = Color.White
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))
            }
        }
    }
}

@Composable
private fun TimeInputPill(
    timeLabel: String,
    onDecrease: () -> Unit,
    onIncrease: () -> Unit
) {
    Row(
        modifier = Modifier
            .clip(RoundedCornerShape(12.dp))
            .background(DarkSurface2)
            .border(1.dp, HairlineBorder, RoundedCornerShape(12.dp))
            .padding(horizontal = 6.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconButton(
            onClick = onDecrease,
            modifier = Modifier.size(28.dp)
        ) {
            Icon(imageVector = Icons.Default.Remove, contentDescription = "Decrease", tint = TextSecondary, modifier = Modifier.size(16.dp))
        }

        Text(
            text = timeLabel,
            style = MaterialTheme.typography.bodyMedium.copy(fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold),
            color = TextPrimary,
            modifier = Modifier.padding(horizontal = 8.dp)
        )

        IconButton(
            onClick = onIncrease,
            modifier = Modifier.size(28.dp)
        ) {
            Icon(imageVector = Icons.Default.Add, contentDescription = "Increase", tint = TextSecondary, modifier = Modifier.size(16.dp))
        }
    }
}

@Composable
private fun QuickPresetChip(
    label: String,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(DarkSurface2)
            .border(1.dp, HairlineBorder, RoundedCornerShape(8.dp))
            .clickable { onClick() }
            .padding(vertical = 6.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp, fontWeight = FontWeight.Medium),
            color = TextSecondary
        )
    }
}
