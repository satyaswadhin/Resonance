package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*
import com.example.viewmodel.ResonanceViewModel

@Composable
fun QueuesScreen(
    viewModel: ResonanceViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val activeQueueId by viewModel.activeQueueId.collectAsState()
    val multiQueues by viewModel.multiQueues.collectAsState()
    val isPlaying by viewModel.audioEngine.isPlaying.collectAsState()

    val currentQueue = multiQueues[activeQueueId] ?: multiQueues.values.first()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(AmoledBlack)
            .padding(horizontal = 16.dp, vertical = 10.dp)
    ) {
        // Musicolet Multi-Queue Header
        Text(
            text = "Musicolet Multi-Queues",
            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
            color = Color.White
        )
        Text(
            text = "Independent queues preserved simultaneously without losing playback positions",
            style = MaterialTheme.typography.bodySmall,
            color = TextSecondary
        )

        Spacer(modifier = Modifier.height(14.dp))

        // Queue Switcher Tabs (Queue 1, Queue 2, Queue 3)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            listOf(1 to "Queue 1 (Main)", 2 to "Queue 2 (Favs)", 3 to "Queue 3 (Bedtime)").forEach { (id, label) ->
                val isSelected = activeQueueId == id
                val qTracksCount = multiQueues[id]?.tracks?.size ?: 0
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(12.dp))
                        .background(if (isSelected) ResonanceCyan else Color(0xFF101520))
                        .border(1.dp, if (isSelected) ResonanceCyan else Color(0xFF222B3D), RoundedCornerShape(12.dp))
                        .clickable { viewModel.switchQueue(id) }
                        .padding(vertical = 10.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = label,
                            color = if (isSelected) AmoledBlack else Color.White,
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.SemiBold,
                                fontSize = 10.sp
                            )
                        )
                        Text(
                            text = "$qTracksCount tracks",
                            color = if (isSelected) Color(0xFF00363D) else TextMuted,
                            style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp)
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Queue Actions Bar (Shuffle, Clear, Count)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "${currentQueue.tracks.size} tracks in ${currentQueue.name}",
                style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold),
                color = ResonanceAmber
            )

            Row {
                IconButton(
                    onClick = {
                        viewModel.shuffleQueue(activeQueueId)
                        Toast.makeText(context, "Shuffled queue", Toast.LENGTH_SHORT).show()
                    },
                    modifier = Modifier.size(34.dp).testTag("shuffle_queue_btn")
                ) {
                    Icon(imageVector = Icons.Default.Shuffle, contentDescription = "Shuffle", tint = ResonanceCyan, modifier = Modifier.size(18.dp))
                }

                IconButton(
                    onClick = {
                        viewModel.clearQueue(activeQueueId)
                        Toast.makeText(context, "Cleared queue", Toast.LENGTH_SHORT).show()
                    },
                    modifier = Modifier.size(34.dp).testTag("clear_queue_btn")
                ) {
                    Icon(imageVector = Icons.Default.DeleteOutline, contentDescription = "Clear", tint = Color(0xFFFF5252), modifier = Modifier.size(18.dp))
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        if (currentQueue.tracks.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "This queue is empty.\nGo to Library and tap ➕ or 'Add to Queue' on any song!",
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextMuted,
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                itemsIndexed(currentQueue.tracks) { index, track ->
                    val isCurrentTrack = index == currentQueue.currentIndex
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(if (isCurrentTrack) Color(0xFF00333D) else Color(0xFF0D121B))
                            .border(1.dp, if (isCurrentTrack) ResonanceCyan else Color(0xFF1A2230), RoundedCornerShape(12.dp))
                            .clickable { viewModel.playTrackAtQueueIndex(index) }
                            .padding(horizontal = 12.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "${index + 1}",
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                            color = if (isCurrentTrack) ResonanceCyan else TextMuted,
                            modifier = Modifier.width(24.dp)
                        )

                        Spacer(modifier = Modifier.width(6.dp))

                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = track.title,
                                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
                                color = Color.White,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = "${track.artist} • ${track.formattedDuration}",
                                style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                                color = if (isCurrentTrack) ResonanceCyan else TextSecondary,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }

                        if (isCurrentTrack) {
                            Icon(
                                imageVector = if (isPlaying) Icons.Default.GraphicEq else Icons.Default.Pause,
                                contentDescription = "Playing",
                                tint = ResonanceCyan,
                                modifier = Modifier.size(20.dp).padding(end = 8.dp)
                            )
                        }

                        IconButton(
                            onClick = { viewModel.removeFromQueue(activeQueueId, index) },
                            modifier = Modifier.size(28.dp)
                        ) {
                            Icon(imageVector = Icons.Default.Close, contentDescription = "Remove", tint = TextMuted, modifier = Modifier.size(16.dp))
                        }
                    }
                }
            }
        }
    }
}
