package com.example.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Track
import com.example.ui.theme.ResonanceAmber
import com.example.ui.theme.ResonanceCyan
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun VinylPlatterView(
    track: Track?,
    isPlaying: Boolean,
    currentPositionMs: Long,
    durationMs: Long,
    onSeek: (Long) -> Unit,
    modifier: Modifier = Modifier
) {
    // Continuous 33 1/3 RPM rotation
    val infiniteTransition = rememberInfiniteTransition(label = "vinyl_rotate")
    val rotationAngle by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(1800, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "rotation"
    )

    val currentRotation = if (isPlaying) rotationAngle else 0f
    val progress = if (durationMs > 0) (currentPositionMs.toFloat() / durationMs.toFloat()).coerceIn(0f, 1f) else 0f

    // Tonearm angle sweeps from 20° (outer groove) to 55° (inner groove)
    val tonearmAngle = 20f + (progress * 35f)

    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(260.dp)
            .clip(RoundedCornerShape(20.dp))
            .background(Color(0xFF090C12))
            .border(1.dp, Color(0xFF1B2332), RoundedCornerShape(20.dp))
            .padding(12.dp)
            .testTag("vinyl_platter_view")
    ) {
        // Rotating Vinyl Disc
        Box(
            modifier = Modifier
                .size(230.dp)
                .align(Alignment.CenterStart)
                .padding(start = 10.dp)
                .rotate(currentRotation)
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val center = Offset(size.width / 2f, size.height / 2f)
                val radius = size.width / 2f

                // Outer edge
                drawCircle(color = Color(0xFF141720), radius = radius, center = center)

                // Concentric microgrooves
                for (r in 35 until radius.toInt() step 6) {
                    drawCircle(
                        color = Color(0xFF222836),
                        radius = r.toFloat(),
                        center = center,
                        style = Stroke(width = 0.8f)
                    )
                }

                // Center Record Label
                drawCircle(color = ResonanceAmber, radius = radius * 0.35f, center = center)
                drawCircle(color = Color(0xFF11141C), radius = radius * 0.10f, center = center)
            }
        }

        // Draggable Tonearm
        Box(
            modifier = Modifier
                .width(100.dp)
                .height(230.dp)
                .align(Alignment.TopEnd)
                .pointerInput(durationMs) {
                    detectDragGestures { change, dragAmount ->
                        change.consume()
                        val deltaRatio = dragAmount.y / size.height
                        val newPos = (currentPositionMs + (deltaRatio * durationMs)).toLong()
                        onSeek(newPos.coerceIn(0L, durationMs))
                    }
                }
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val pivot = Offset(size.width * 0.75f, 24.dp.toPx())
                val armLength = size.height * 0.78f
                val rad = Math.toRadians((tonearmAngle + 90).toDouble())
                val headX = pivot.x + (armLength * cos(rad)).toFloat()
                val headY = pivot.y + (armLength * sin(rad)).toFloat()

                // Arm Pivot
                drawCircle(color = Color(0xFF384358), radius = 10.dp.toPx(), center = pivot)
                drawCircle(color = Color(0xFF6B7B99), radius = 6.dp.toPx(), center = pivot)

                // Chrome Tonearm Rod
                drawLine(
                    color = Color(0xFFDCE2ED),
                    start = pivot,
                    end = Offset(headX, headY),
                    strokeWidth = 3.dp.toPx()
                )

                // Cartridge Head & Stylus
                drawCircle(color = ResonanceCyan, radius = 5.dp.toPx(), center = Offset(headX, headY))
            }
        }

        // 33 1/3 RPM Badge
        Text(
            text = "33⅓ RPM • Hi-Fi Direct",
            style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
            color = Color(0xFF6C768A),
            modifier = Modifier.align(Alignment.BottomEnd).padding(end = 8.dp, bottom = 4.dp)
        )
    }
}

@Composable
fun CassetteDeckView(
    track: Track?,
    isPlaying: Boolean,
    currentPositionMs: Long,
    durationMs: Long,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "cassette_reels")
    val reelRotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(2200, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "reelRotate"
    )

    val currentReelRot = if (isPlaying) reelRotation else 0f
    val progress = if (durationMs > 0) (currentPositionMs.toFloat() / durationMs.toFloat()).coerceIn(0f, 1f) else 0f
    val counter = (progress * 999).toInt()

    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(210.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(Color(0xFF12151D))
            .border(2.dp, Color(0xFF283042), RoundedCornerShape(16.dp))
            .padding(14.dp)
            .testTag("cassette_deck_view")
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // Cassette Header Label
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(6.dp))
                    .background(Color(0xFF1C2230))
                    .padding(horizontal = 12.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "TYPE II • CHROME [CrO2]",
                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                    color = ResonanceAmber
                )
                Text(
                    text = "COUNTER %03d".format(counter),
                    style = MaterialTheme.typography.labelSmall.copy(fontFamily = FontFamily.Monospace),
                    color = ResonanceCyan
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Transparent Tape Window
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .clip(RoundedCornerShape(10.dp))
                    .background(Color(0xFF0A0D14))
                    .border(1.dp, Color(0xFF2E384D), RoundedCornerShape(10.dp))
                    .padding(8.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxSize(),
                    horizontalArrangement = Arrangement.SpaceAround,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Left Spool
                    Box(
                        modifier = Modifier
                            .size(70.dp)
                            .rotate(currentReelRot)
                    ) {
                        Canvas(modifier = Modifier.fillMaxSize()) {
                            drawCircle(color = Color(0xFF382218), radius = size.width * (0.45f - (progress * 0.2f)))
                            drawCircle(color = Color.White, radius = 12.dp.toPx(), center = center)
                            drawCircle(color = Color.Black, radius = 6.dp.toPx(), center = center)
                        }
                    }

                    // Magnetic Tape Ribbon Bridge
                    Canvas(modifier = Modifier.width(60.dp).height(12.dp)) {
                        drawLine(
                            color = Color(0xFF3D251A),
                            start = Offset(0f, size.height / 2f),
                            end = Offset(size.width, size.height / 2f),
                            strokeWidth = 5.dp.toPx()
                        )
                    }

                    // Right Spool
                    Box(
                        modifier = Modifier
                            .size(70.dp)
                            .rotate(currentReelRot)
                    ) {
                        Canvas(modifier = Modifier.fillMaxSize()) {
                            drawCircle(color = Color(0xFF382218), radius = size.width * (0.25f + (progress * 0.2f)))
                            drawCircle(color = Color.White, radius = 12.dp.toPx(), center = center)
                            drawCircle(color = Color.Black, radius = 6.dp.toPx(), center = center)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ChronographDialView(
    currentPositionMs: Long,
    durationMs: Long,
    onSeek: (Long) -> Unit,
    modifier: Modifier = Modifier
) {
    val progress = if (durationMs > 0) (currentPositionMs.toFloat() / durationMs.toFloat()).coerceIn(0f, 1f) else 0f
    val needleAngle = progress * 360f

    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(230.dp)
            .clip(RoundedCornerShape(20.dp))
            .background(Color(0xFF090B10))
            .border(1.dp, Color(0xFF1E2638), RoundedCornerShape(20.dp))
            .padding(16.dp)
            .testTag("chronograph_dial_view")
    ) {
        Canvas(
            modifier = Modifier
                .size(190.dp)
                .align(Alignment.Center)
                .pointerInput(durationMs) {
                    detectDragGestures { change, _ ->
                        change.consume()
                        val center = Offset(size.width / 2f, size.height / 2f)
                        val touch = change.position
                        val rad = Math.atan2((touch.y - center.y).toDouble(), (touch.x - center.x).toDouble())
                        var deg = Math.toDegrees(rad).toFloat() + 90f
                        if (deg < 0) deg += 360f
                        val ratio = deg / 360f
                        onSeek((ratio * durationMs).toLong())
                    }
                }
        ) {
            val center = Offset(size.width / 2f, size.height / 2f)
            val radius = size.width / 2f

            // Outer Brushed Bezel
            drawCircle(color = Color(0xFF131822), radius = radius, center = center)
            drawCircle(
                color = Color(0xFF2A3448),
                radius = radius,
                center = center,
                style = Stroke(width = 3.dp.toPx())
            )

            // Chronograph 60-Second Radial Tick Marks
            for (i in 0 until 60) {
                val tickRad = Math.toRadians((i * 6 - 90).toDouble())
                val isMajor = (i % 5 == 0)
                val innerR = if (isMajor) radius * 0.78f else radius * 0.88f
                val outerR = radius * 0.94f
                val start = Offset(center.x + (innerR * cos(tickRad)).toFloat(), center.y + (innerR * sin(tickRad)).toFloat())
                val end = Offset(center.x + (outerR * cos(tickRad)).toFloat(), center.y + (outerR * sin(tickRad)).toFloat())

                drawLine(
                    color = if (isMajor) ResonanceCyan else Color(0xFF333E54),
                    start = start,
                    end = end,
                    strokeWidth = if (isMajor) 2.dp.toPx() else 1.dp.toPx()
                )
            }

            // Scrubbing Needle Hand
            val needleRad = Math.toRadians((needleAngle - 90).toDouble())
            val needleEnd = Offset(
                center.x + (radius * 0.75f * cos(needleRad)).toFloat(),
                center.y + (radius * 0.75f * sin(needleRad)).toFloat()
            )

            drawLine(
                color = ResonanceAmber,
                start = center,
                end = needleEnd,
                strokeWidth = 3.dp.toPx(),
                cap = StrokeCap.Round
            )

            // Center Pin
            drawCircle(color = Color.White, radius = 5.dp.toPx(), center = center)
            drawCircle(color = ResonanceAmber, radius = 2.dp.toPx(), center = center)
        }
    }
}
