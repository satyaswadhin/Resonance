package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.model.BackgroundStyle
import com.example.model.ECHO_PRESETS
import com.example.model.EchoThemeSettings
import com.example.ui.theme.*

@Composable
fun EchoThemeDialog(
    themeSettings: EchoThemeSettings,
    onUpdateTheme: (EchoThemeSettings) -> Unit,
    onDismiss: () -> Unit
) {
    var selectedPreset by remember { mutableStateOf(themeSettings.activePresetName) }
    var customHue by remember { mutableStateOf(themeSettings.customHue) }
    var backgroundStyle by remember { mutableStateOf(themeSettings.backgroundStyle) }
    var isLiquidGlass by remember { mutableStateOf(themeSettings.isLiquidGlassEnabled) }
    var isWavyProgress by remember { mutableStateOf(themeSettings.isWavyProgressEnabled) }
    var dynamicAlbumArt by remember { mutableStateOf(themeSettings.dynamicAlbumArtColor) }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(24.dp),
            color = DarkSurface1,
            border = androidx.compose.foundation.BorderStroke(1.dp, HairlineBorder),
            modifier = Modifier.fillMaxWidth().padding(4.dp)
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                // Header
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(themeSettings.accentGlowColor),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Palette,
                            contentDescription = null,
                            tint = themeSettings.accentColor,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "Appearance & Audiophile Themes",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = TextPrimary
                        )
                        Text(
                            text = "Color combination presets & liquid glass styling",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Section 1: Echo Color Presets
                Text(
                    text = "Color Combinations (Presets)",
                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                    color = TextPrimary
                )
                Spacer(modifier = Modifier.height(8.dp))

                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    items(ECHO_PRESETS) { preset ->
                        val isSelected = selectedPreset == preset.name && !dynamicAlbumArt
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(12.dp))
                                .background(if (isSelected) preset.glowColor else DarkSurface2)
                                .border(1.5.dp, if (isSelected) preset.primaryColor else HairlineBorder, RoundedCornerShape(12.dp))
                                .clickable {
                                    selectedPreset = preset.name
                                    dynamicAlbumArt = false
                                    onUpdateTheme(
                                        themeSettings.copy(
                                            accentColor = preset.primaryColor,
                                            accentGlowColor = preset.glowColor,
                                            activePresetName = preset.name,
                                            dynamicAlbumArtColor = false
                                        )
                                    )
                                }
                                .padding(horizontal = 12.dp, vertical = 8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(16.dp)
                                        .clip(CircleShape)
                                        .background(preset.primaryColor)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = preset.name,
                                    fontSize = 11.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                    color = if (isSelected) TextPrimary else TextSecondary
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Section 2: Custom HSL Hue Picker
                Text(
                    text = "Custom Accent Hue (${customHue.toInt()}°)",
                    style = MaterialTheme.typography.labelMedium,
                    color = TextSecondary
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Slider(
                        value = customHue,
                        onValueChange = { hue ->
                            customHue = hue
                            selectedPreset = "Custom (${hue.toInt()}°)"
                            dynamicAlbumArt = false
                            val customColor = Color.hsv(hue, 0.75f, 1.0f)
                            onUpdateTheme(
                                themeSettings.copy(
                                    accentColor = customColor,
                                    accentGlowColor = customColor.copy(alpha = 0.2f),
                                    activePresetName = "Custom (${hue.toInt()}°)",
                                    customHue = hue,
                                    dynamicAlbumArtColor = false
                                )
                            )
                        },
                        valueRange = 0f..360f,
                        modifier = Modifier.weight(1f)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Box(
                        modifier = Modifier
                            .size(24.dp)
                            .clip(CircleShape)
                            .background(Color.hsv(customHue, 0.75f, 1.0f))
                            .border(1.dp, Color.White, CircleShape)
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Section 3: Background Styles
                Text(
                    text = "Background Base Style",
                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                    color = TextPrimary
                )
                Spacer(modifier = Modifier.height(8.dp))

                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    BackgroundStyle.values().forEach { style ->
                        val isSelected = backgroundStyle == style
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(10.dp))
                                .background(if (isSelected) DarkSurface3 else DarkSurface2)
                                .border(1.dp, if (isSelected) themeSettings.accentColor else HairlineBorder, RoundedCornerShape(10.dp))
                                .clickable {
                                    backgroundStyle = style
                                    onUpdateTheme(themeSettings.copy(backgroundStyle = style))
                                }
                                .padding(horizontal = 12.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(text = style.displayName, fontSize = 12.sp, color = if (isSelected) TextPrimary else TextSecondary)
                            if (isSelected) {
                                Icon(imageVector = Icons.Default.Check, contentDescription = null, tint = themeSettings.accentColor, modifier = Modifier.size(16.dp))
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Section 4: Echo Liquid Glass & Wavy Progress Toggles
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(DarkSurface2)
                        .border(1.dp, HairlineBorder, RoundedCornerShape(12.dp))
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(text = "Echo Liquid Glass (Glassmorphism)", style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold), color = TextPrimary)
                        Text(text = "Translucent frosted surfaces with glowing borders", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                    }
                    Switch(
                        checked = isLiquidGlass,
                        onCheckedChange = {
                            isLiquidGlass = it
                            onUpdateTheme(themeSettings.copy(isLiquidGlassEnabled = it))
                        }
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(DarkSurface2)
                        .border(1.dp, HairlineBorder, RoundedCornerShape(12.dp))
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(text = "Echo Wavy Sine-Wave Scrubber", style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold), color = TextPrimary)
                        Text(text = "Signature fluid wavy progress bar animation", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                    }
                    Switch(
                        checked = isWavyProgress,
                        onCheckedChange = {
                            isWavyProgress = it
                            onUpdateTheme(themeSettings.copy(isWavyProgressEnabled = it))
                        }
                    )
                }

                Spacer(modifier = Modifier.height(18.dp))

                Button(
                    onClick = onDismiss,
                    colors = ButtonDefaults.buttonColors(containerColor = themeSettings.accentColor),
                    modifier = Modifier.fillMaxWidth().testTag("close_theme_dialog_btn")
                ) {
                    Text("Apply & Close", color = Color.Black, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}
