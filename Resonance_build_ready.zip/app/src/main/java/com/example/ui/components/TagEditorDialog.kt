package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import com.example.data.parser.Id3Editor
import com.example.model.Track
import com.example.ui.theme.ResonanceCyan
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun TagEditorDialog(
    track: Track,
    onSave: (Track, Id3Editor.EditableMetadata) -> Unit,
    onDismiss: () -> Unit
) {
    var title by remember { mutableStateOf(track.title) }
    var artist by remember { mutableStateOf(track.artist) }
    var album by remember { mutableStateOf(track.album) }
    var albumArtist by remember { mutableStateOf(track.albumArtist) }
    var genre by remember { mutableStateOf(track.genres.joinToString("; ")) }
    var year by remember { mutableStateOf(track.year.toString()) }
    var trackNumber by remember { mutableStateOf(track.trackNumber.toString()) }
    var discNumber by remember { mutableStateOf(track.discNumber.toString()) }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = Color(0xFF0F131C),
            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF252E40)),
            modifier = Modifier.fillMaxWidth().padding(8.dp)
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                Text(
                    text = "Offline ID3 / Vorbis Tag Editor",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = Color.White
                )
                Text(
                    text = "Directly updates file headers with multi-artist and genre delimiter support",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary
                )

                Spacer(modifier = Modifier.height(14.dp))

                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Track Title") },
                    modifier = Modifier.fillMaxWidth(),
                    colors = tagFieldColors()
                )

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = artist,
                    onValueChange = { artist = it },
                    label = { Text("Artists (Use ';' or '/' to split)") },
                    modifier = Modifier.fillMaxWidth(),
                    colors = tagFieldColors()
                )

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = album,
                    onValueChange = { album = it },
                    label = { Text("Album") },
                    modifier = Modifier.fillMaxWidth(),
                    colors = tagFieldColors()
                )

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = albumArtist,
                    onValueChange = { albumArtist = it },
                    label = { Text("Album Artist") },
                    modifier = Modifier.fillMaxWidth(),
                    colors = tagFieldColors()
                )

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = genre,
                    onValueChange = { genre = it },
                    label = { Text("Genre (e.g. Rock / Alternative)") },
                    modifier = Modifier.fillMaxWidth(),
                    colors = tagFieldColors()
                )

                Spacer(modifier = Modifier.height(8.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = year,
                        onValueChange = { year = it },
                        label = { Text("Year") },
                        modifier = Modifier.weight(1f),
                        colors = tagFieldColors()
                    )
                    OutlinedTextField(
                        value = trackNumber,
                        onValueChange = { trackNumber = it },
                        label = { Text("Track #") },
                        modifier = Modifier.weight(1f),
                        colors = tagFieldColors()
                    )
                    OutlinedTextField(
                        value = discNumber,
                        onValueChange = { discNumber = it },
                        label = { Text("Disc #") },
                        modifier = Modifier.weight(1f),
                        colors = tagFieldColors()
                    )
                }

                Spacer(modifier = Modifier.height(18.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    TextButton(onClick = onDismiss) {
                        Text("Cancel", color = TextSecondary)
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = {
                            val metadata = Id3Editor.EditableMetadata(
                                title = title,
                                artist = artist,
                                album = album,
                                albumArtist = albumArtist,
                                genre = genre,
                                year = year.toIntOrNull() ?: track.year,
                                trackNumber = trackNumber.toIntOrNull() ?: track.trackNumber,
                                discNumber = discNumber.toIntOrNull() ?: track.discNumber
                            )
                            onSave(track, metadata)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = ResonanceCyan),
                        modifier = Modifier.testTag("save_id3_tags_btn")
                    ) {
                        Text("Save Tags", color = Color.Black, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
private fun tagFieldColors() = OutlinedTextFieldDefaults.colors(
    focusedTextColor = TextPrimary,
    unfocusedTextColor = TextSecondary,
    focusedBorderColor = ResonanceCyan,
    unfocusedBorderColor = Color(0xFF293245),
    focusedLabelColor = ResonanceCyan,
    unfocusedLabelColor = TextSecondary
)
