package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.Bedtime
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.RepeatMode
import com.example.model.Track
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.viewmodel.ResonanceViewModel
import com.example.viewmodel.ScreenTab

/**
 * NowPlayingScreen redesigned to match the modern Android music player aesthetic
 * (SimpMusic / ViMusic / InnerTune) shown in the reference video:
 * - Scalloped 8-petal flower play/pause button
 * - Premium dark ambient gradients
 * - Album artwork with ambient glow & vinyl disc mode
 * - Title, artist, download/info pill, heart toggle
 * - Rounded modern seekbar
 * - Floating quick action pill (Queue, dynamic countdown Sleep Timer, Lyrics, Shuffle, Repeat)
 * - Full-screen synchronized lyrics mode with click-to-seek
 * - Expandable queue ("Continue Playing")
 */
@Composable
fun NowPlayingScreen(
    viewModel: ResonanceViewModel,
    modifier: Modifier = Modifier
) {
    val currentTrack by viewModel.audioEngine.currentTrack.collectAsState()
    val isPlaying by viewModel.audioEngine.isPlaying.collectAsState()
    val sleepTimer by viewModel.audioEngine.sleepTimer.collectAsState()
    val themeSettings by viewModel.echoThemeSettings.collectAsState()
    val shuffleMode by viewModel.shuffleMode.collectAsState()
    val repeatMode by viewModel.repeatMode.collectAsState()
    val lyrics by viewModel.currentLyrics.collectAsState()
    val lyricsOffset by viewModel.lyricsOffsetMs.collectAsState()
    val isLrcCreatorOpen by viewModel.isLrcCreatorOpen.collectAsState()
    val currentQueue by viewModel.currentQueueTracks.collectAsState()

    var showSleepTimerDialog by remember { mutableStateOf(false) }
    var showQueueDrawer by remember { mutableStateOf(false) }
    var isLyricsMode by remember { mutableStateOf(false) }
    var showTrackActionMenu by remember { mutableStateOf(false) }
    var isFavorite by remember { mutableStateOf(false) }
    var isVinylMode by remember { mutableStateOf(false) }

    // Vinyl spinning animation (hardware accelerated via graphicsLayer)
    val infiniteTransition = rememberInfiniteTransition(label = "vinyl_spin")
    val vinylRotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 8000, easing = LinearEasing),
            repeatMode = androidx.compose.animation.core.RepeatMode.Restart
        ),
        label = "vinyl_angle"
    )

    // Dynamic ambient dark gradient based on theme accent & dark background
    val ambientTopColor = remember(themeSettings.accentColor, themeSettings.backgroundStyle) {
        themeSettings.accentColor.copy(alpha = 0.18f)
    }
    val ambientBottomColor = themeSettings.backgroundStyle.color

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(
                        ambientTopColor,
                        ambientBottomColor.copy(alpha = 0.95f),
                        ambientBottomColor
                    )
                )
            )
            .windowInsetsPadding(WindowInsets.systemBars)
    ) {
        // Fullscreen Lyrics View Overlay
        if (isLyricsMode) {
            val currentPositionMs by viewModel.audioEngine.currentPositionMs.collectAsState()
            FullScreenSyncedLyricsView(
                lyrics = lyrics,
                currentPositionMs = currentPositionMs,
                offsetMs = lyricsOffset,
                trackTitle = currentTrack?.title ?: "No track",
                trackArtist = currentTrack?.artist ?: "Unknown Artist",
                isPlaying = isPlaying,
                accentColor = themeSettings.accentColor,
                onSeekToTimestamp = { viewModel.audioEngine.seekTo(it) },
                onTogglePlayPause = { viewModel.audioEngine.togglePlayPause() },
                onAdjustOffset = { viewModel.adjustLyricsOffset(it) },
                onOpenLrcCreator = { viewModel.isLrcCreatorOpen.value = true },
                onClose = { isLyricsMode = false }
            )
        } else {
            // Main Now Playing Player View
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 22.dp, vertical = 8.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                // Top Header Row
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = { viewModel.selectTab(ScreenTab.HOME) },
                        modifier = Modifier
                            .size(42.dp)
                            .clip(CircleShape)
                            .background(DarkSurface2)
                            .border(1.dp, HairlineBorder, CircleShape)
                            .testTag("collapse_player_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Default.KeyboardArrowDown,
                            contentDescription = "Collapse",
                            tint = TextPrimary,
                            modifier = Modifier.size(26.dp)
                        )
                    }

                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "NOW PLAYING",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.ExtraBold,
                                letterSpacing = 2.sp
                            ),
                            color = themeSettings.accentColor
                        )
                        Text(
                            text = currentTrack?.audioQualityBadge ?: "Hi-Res Master",
                            style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
                            color = TextSecondary
                        )
                    }

                    IconButton(
                        onClick = { showTrackActionMenu = true },
                        modifier = Modifier
                            .size(42.dp)
                            .clip(CircleShape)
                            .background(DarkSurface2)
                            .border(1.dp, HairlineBorder, CircleShape)
                            .testTag("player_options_menu_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Default.MoreVert,
                            contentDescription = "Options",
                            tint = TextPrimary,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Hero Artwork / Vinyl Center View (Tappable to toggle vinyl or lyrics)
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .padding(vertical = 12.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth(0.88f)
                            .aspectRatio(1f)
                            .shadow(
                                elevation = 24.dp,
                                shape = if (isVinylMode) CircleShape else RoundedCornerShape(28.dp),
                                ambientColor = themeSettings.accentColor.copy(alpha = 0.45f),
                                spotColor = themeSettings.accentColor.copy(alpha = 0.65f)
                            )
                            .clip(if (isVinylMode) CircleShape else RoundedCornerShape(28.dp))
                            .background(
                                Brush.radialGradient(
                                    listOf(
                                        themeSettings.accentColor.copy(alpha = 0.28f),
                                        DarkSurface2,
                                        DarkSurface1
                                    )
                                )
                            )
                            .border(
                                1.5.dp,
                                themeSettings.accentColor.copy(alpha = 0.45f),
                                if (isVinylMode) CircleShape else RoundedCornerShape(28.dp)
                            )
                            .clickable { isVinylMode = !isVinylMode },
                        contentAlignment = Alignment.Center
                    ) {
                        if (isVinylMode) {
                            // Spinning Vinyl Disc
                            Box(
                                modifier = Modifier
                                    .fillMaxSize(0.92f)
                                    .graphicsLayer { rotationZ = if (isPlaying && isVinylMode) vinylRotation else 0f }
                                    .clip(CircleShape)
                                    .background(DarkSurface1)
                                    .border(2.dp, HairlineBorder, CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                // Concentric vinyl grooves
                                Box(
                                    modifier = Modifier
                                        .fillMaxSize(0.7f)
                                        .clip(CircleShape)
                                        .border(1.dp, HairlineBorder, CircleShape)
                                )
                                Box(
                                    modifier = Modifier
                                        .fillMaxSize(0.42f)
                                        .clip(CircleShape)
                                        .background(themeSettings.accentColor),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(24.dp)
                                            .clip(CircleShape)
                                            .background(Color.Black)
                                    )
                                }
                            }
                        } else {
                            // High-Res Artwork Cover Card
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Box(
                                    modifier = Modifier
                                        .size(130.dp)
                                        .clip(RoundedCornerShape(24.dp))
                                        .background(DarkSurface3)
                                        .border(1.dp, themeSettings.accentColor.copy(alpha = 0.5f), RoundedCornerShape(24.dp)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.MusicNote,
                                        contentDescription = null,
                                        tint = themeSettings.accentColor,
                                        modifier = Modifier.size(68.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.height(14.dp))
                                Text(
                                    text = currentTrack?.album ?: "Local Audio",
                                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.SemiBold),
                                    color = TextSecondary,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                    }
                }

                // Track Info & Actions Row (Title, Artist, Download, Heart)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = currentTrack?.title ?: "Select a Track",
                            style = MaterialTheme.typography.headlineSmall.copy(
                                fontWeight = FontWeight.Bold,
                                fontSize = 23.sp
                            ),
                            color = TextPrimary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = currentTrack?.artist ?: "Unknown Artist",
                            style = MaterialTheme.typography.bodyMedium.copy(
                                fontWeight = FontWeight.Medium
                            ),
                            color = themeSettings.accentColor,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        // Quick Audio Inspector / Equalizer shortcut button
                        IconButton(
                            onClick = {
                                currentTrack?.let { viewModel.inspectTrack(it) }
                            },
                            modifier = Modifier
                                .size(42.dp)
                                .clip(CircleShape)
                                .background(DarkSurface2)
                                .border(1.dp, HairlineBorder, CircleShape)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Info,
                                contentDescription = "Audio Info",
                                tint = TextSecondary,
                                modifier = Modifier.size(20.dp)
                            )
                        }

                        Spacer(modifier = Modifier.width(8.dp))

                        // Heart / Favorite Button
                        IconButton(
                            onClick = { isFavorite = !isFavorite },
                            modifier = Modifier
                                .size(42.dp)
                                .clip(CircleShape)
                                .background(if (isFavorite) Color(0x33FF5252) else DarkSurface2)
                                .border(1.dp, if (isFavorite) Color(0x66FF5252) else HairlineBorder, CircleShape)
                                .testTag("player_favorite_btn")
                        ) {
                            Icon(
                                imageVector = if (isFavorite) Icons.Default.Favorite else Icons.Outlined.FavoriteBorder,
                                contentDescription = "Favorite",
                                tint = if (isFavorite) Color(0xFFFF5252) else TextSecondary,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Modern Seekbar (isolated to eliminate parent screen recomposition)
                NowPlayingSeekBar(
                    audioEngine = viewModel.audioEngine,
                    accentColor = themeSettings.accentColor
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Playback Controls Row: Prev, Signature Flower Play/Pause, Next
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Previous Track Button
                    IconButton(
                        onClick = { viewModel.playPreviousTrack() },
                        modifier = Modifier
                            .size(54.dp)
                            .clip(CircleShape)
                            .background(DarkSurface2)
                            .border(1.dp, HairlineBorder, CircleShape)
                            .testTag("echo_prev_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Default.SkipPrevious,
                            contentDescription = "Previous",
                            tint = TextPrimary,
                            modifier = Modifier.size(30.dp)
                        )
                    }

                    // Signature Scalloped Flower / Starburst Play Button
                    FlowerPlayButton(
                        isPlaying = isPlaying,
                        onClick = { viewModel.audioEngine.togglePlayPause() },
                        size = 72.dp,
                        containerColor = Color.White,
                        contentColor = Color(0xFF0C0F17),
                        testTag = "echo_play_pause_btn"
                    )

                    // Next Track Button
                    IconButton(
                        onClick = { viewModel.playNextTrack() },
                        modifier = Modifier
                            .size(54.dp)
                            .clip(CircleShape)
                            .background(DarkSurface2)
                            .border(1.dp, HairlineBorder, CircleShape)
                            .testTag("echo_next_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Default.SkipNext,
                            contentDescription = "Next",
                            tint = TextPrimary,
                            modifier = Modifier.size(30.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(18.dp))

                // Floating Quick Action Pill Bar:
                // [Queue] [Sleep Timer (with dynamic remaining badge)] [Lyrics] [Shuffle] [Repeat]
                // Flanked by circular 3-dots More button
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Main Pill Container
                    Surface(
                        shape = RoundedCornerShape(32.dp),
                        color = if (themeSettings.isLiquidGlassEnabled) LiquidGlassSurface else DarkSurface2,
                        border = androidx.compose.foundation.BorderStroke(1.dp, HairlineBorder),
                        modifier = Modifier
                            .weight(1f)
                            .height(54.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(horizontal = 8.dp),
                            horizontalArrangement = Arrangement.SpaceEvenly,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            // 1. Queue Drawer Button
                            IconButton(
                                onClick = { showQueueDrawer = !showQueueDrawer },
                                modifier = Modifier
                                    .size(40.dp)
                                    .testTag("echo_bottom_queue_block")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.QueueMusic,
                                    contentDescription = "Queue",
                                    tint = if (showQueueDrawer) themeSettings.accentColor else TextSecondary,
                                    modifier = Modifier.size(22.dp)
                                )
                            }

                            // 2. Sleep Timer Button (Shows dynamic timer badge like "44:39" when active)
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(20.dp))
                                    .background(if (sleepTimer.isActive) themeSettings.accentGlowColor else Color.Transparent)
                                    .clickable { showSleepTimerDialog = true }
                                    .padding(horizontal = if (sleepTimer.isActive) 10.dp else 6.dp, vertical = 6.dp)
                                    .testTag("echo_bottom_sleep_timer_block"),
                                contentAlignment = Alignment.Center
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Outlined.Bedtime,
                                        contentDescription = "Sleep Timer",
                                        tint = if (sleepTimer.isActive) themeSettings.accentColor else TextSecondary,
                                        modifier = Modifier.size(20.dp)
                                    )
                                    if (sleepTimer.isActive) {
                                        Spacer(modifier = Modifier.width(4.dp))
                                        val mins = sleepTimer.remainingSeconds / 60
                                        val secs = sleepTimer.remainingSeconds % 60
                                        Text(
                                            text = "%02d:%02d".format(mins, secs),
                                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                            color = themeSettings.accentColor
                                        )
                                    }
                                }
                            }

                            // 3. Lyrics Mode Button
                            IconButton(
                                onClick = { isLyricsMode = true },
                                modifier = Modifier.size(40.dp).testTag("echo_bottom_lyrics_block")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Mic,
                                    contentDescription = "Lyrics",
                                    tint = TextSecondary,
                                    modifier = Modifier.size(22.dp)
                                )
                            }

                            // 4. Shuffle Toggle
                            IconButton(
                                onClick = { viewModel.toggleShuffleMode() },
                                modifier = Modifier.size(40.dp).testTag("echo_shuffle_btn")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Shuffle,
                                    contentDescription = "Shuffle",
                                    tint = if (shuffleMode) themeSettings.accentColor else TextSecondary,
                                    modifier = Modifier.size(20.dp)
                                )
                            }

                            // 5. Repeat Toggle
                            IconButton(
                                onClick = { viewModel.toggleRepeatMode() },
                                modifier = Modifier.size(40.dp).testTag("echo_repeat_btn")
                            ) {
                                Icon(
                                    imageVector = if (repeatMode == RepeatMode.ONE) Icons.Default.RepeatOne else Icons.Default.Repeat,
                                    contentDescription = "Repeat",
                                    tint = if (repeatMode != RepeatMode.OFF) themeSettings.accentColor else TextSecondary,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                    }

                    // Flanked Circular 3-dots Overflow Button
                    IconButton(
                        onClick = { showTrackActionMenu = true },
                        modifier = Modifier
                            .size(54.dp)
                            .clip(CircleShape)
                            .background(DarkSurface2)
                            .border(1.dp, HairlineBorder, CircleShape)
                    ) {
                        Icon(
                            imageVector = Icons.Default.MoreHoriz,
                            contentDescription = "More Options",
                            tint = TextPrimary,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))
            }
        }

        // Expandable Queue Drawer ("Continue Playing" sheet)
        AnimatedVisibility(
            visible = showQueueDrawer,
            enter = slideInVertically(initialOffsetY = { it }) + fadeIn(),
            exit = slideOutVertically(targetOffsetY = { it }) + fadeOut(),
            modifier = Modifier.align(Alignment.BottomCenter)
        ) {
            Surface(
                shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp),
                color = DarkSurface1,
                border = androidx.compose.foundation.BorderStroke(1.dp, HairlineBorder),
                modifier = Modifier
                    .fillMaxWidth()
                    .fillMaxHeight(0.65f)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(20.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "Continue Playing",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                color = TextPrimary
                            )
                            Text(
                                text = "${currentQueue.size} songs in queue",
                                style = MaterialTheme.typography.bodySmall,
                                color = themeSettings.accentColor
                            )
                        }

                        IconButton(onClick = { showQueueDrawer = false }) {
                            Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = TextSecondary)
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        itemsIndexed(currentQueue) { index, track ->
                            val isCurrent = track.id == currentTrack?.id
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(14.dp))
                                    .background(if (isCurrent) themeSettings.accentGlowColor else DarkSurface2)
                                    .border(1.dp, if (isCurrent) themeSettings.accentColor.copy(alpha = 0.5f) else HairlineBorder, RoundedCornerShape(14.dp))
                                    .clickable { viewModel.playTrackAtQueueIndex(index) }
                                    .padding(horizontal = 12.dp, vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                if (isCurrent) {
                                    Icon(
                                        imageVector = Icons.Default.GraphicEq,
                                        contentDescription = "Playing",
                                        tint = themeSettings.accentColor,
                                        modifier = Modifier.size(18.dp)
                                    )
                                } else {
                                    Text(
                                        text = "${index + 1}",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = TextMuted,
                                        modifier = Modifier.width(20.dp)
                                    )
                                }

                                Spacer(modifier = Modifier.width(10.dp))

                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = track.title,
                                        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
                                        color = if (isCurrent) themeSettings.accentColor else TextPrimary,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Text(
                                        text = track.artist,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = TextSecondary,
                                        maxLines = 1
                                    )
                                }

                                Text(
                                    text = track.formattedDuration,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = TextMuted
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    // Sleep Timer Dialog
    if (showSleepTimerDialog) {
        SleepTimerDialog(
            sleepTimer = sleepTimer,
            accentColor = themeSettings.accentColor,
            onSetSleepTimer = { mins, finishLast ->
                viewModel.audioEngine.setSleepTimer(mins, finishLast)
                showSleepTimerDialog = false
            },
            onCancelSleepTimer = {
                viewModel.audioEngine.cancelSleepTimer()
                showSleepTimerDialog = false
            },
            onDismiss = { showSleepTimerDialog = false }
        )
    }

    // Song Context Menu Bottom Sheet
    if (showTrackActionMenu) {
        currentTrack?.let { track ->
            TrackActionBottomSheet(
                track = track,
                accentColor = themeSettings.accentColor,
                onCutAudio = {
                    showTrackActionMenu = false
                    viewModel.openTrimmer(track)
                },
                onRename = {
                    showTrackActionMenu = false
                    viewModel.openRenamer(track)
                },
                onDelete = {
                    showTrackActionMenu = false
                    viewModel.openDeleter(track)
                },
                onEditTags = {
                    showTrackActionMenu = false
                    viewModel.isTagEditorOpen.value = true
                },
                onInspectInfo = {
                    showTrackActionMenu = false
                    viewModel.inspectTrack(track)
                },
                onPlayNext = {
                    showTrackActionMenu = false
                    viewModel.enqueueNext(track)
                },
                onAddToQueue = {
                    showTrackActionMenu = false
                    viewModel.addToQueue(1, track)
                },
                onDismiss = { showTrackActionMenu = false },
                onShowLyrics = {
                    showTrackActionMenu = false
                    isLyricsMode = true
                },
                onSetSleepTimer = {
                    showTrackActionMenu = false
                    showSleepTimerDialog = true
                }
            )
        }
    }

    // Tag Editor Dialog
    val isTagEditorOpen by viewModel.isTagEditorOpen.collectAsState()
    if (isTagEditorOpen) {
        currentTrack?.let { track ->
            TagEditorDialog(
                track = track,
                onSave = { targetTrack, metadata ->
                    viewModel.saveTrackMetadata(targetTrack, metadata)
                    viewModel.isTagEditorOpen.value = false
                },
                onDismiss = { viewModel.isTagEditorOpen.value = false }
            )
        }
    }

    // Track Detail Inspector Dialog
    val inspectedTrack by viewModel.inspectedTrack.collectAsState()
    inspectedTrack?.let { track ->
        TrackDetailDialog(
            track = track,
            onDismiss = { viewModel.inspectTrack(null) }
        )
    }

    // LRC Syncer Creator Dialog
    if (isLrcCreatorOpen) {
        val currentPositionMs by viewModel.audioEngine.currentPositionMs.collectAsState()
        LyricsCreatorDialog(
            currentPositionMs = currentPositionMs,
            onSaveLyrics = { lrcText: String ->
                viewModel.saveCreatedLyrics(lrcText)
            },
            onDismiss = { viewModel.isLrcCreatorOpen.value = false }
        )
    }
}

@Composable
private fun NowPlayingSeekBar(
    audioEngine: com.example.engine.ResonanceAudioEngine,
    accentColor: Color,
    modifier: Modifier = Modifier
) {
    val currentPositionMs by audioEngine.currentPositionMs.collectAsState()
    val durationMs by audioEngine.durationMs.collectAsState()

    var isUserSeeking by remember { mutableStateOf(false) }
    var seekFraction by remember { mutableFloatStateOf(0f) }

    val progressFraction = remember(currentPositionMs, durationMs, isUserSeeking) {
        if (isUserSeeking) seekFraction
        else if (durationMs > 0) (currentPositionMs.toFloat() / durationMs.toFloat()).coerceIn(0f, 1f)
        else 0f
    }

    Column(modifier = modifier.fillMaxWidth()) {
        Slider(
            value = progressFraction,
            onValueChange = {
                isUserSeeking = true
                seekFraction = it
            },
            onValueChangeFinished = {
                val targetMs = (seekFraction * durationMs).toLong()
                audioEngine.seekTo(targetMs)
                isUserSeeking = false
            },
            colors = SliderDefaults.colors(
                thumbColor = Color.White,
                activeTrackColor = accentColor,
                inactiveTrackColor = DarkSurface3
            ),
            modifier = Modifier.fillMaxWidth().testTag("player_slider")
        )

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 6.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            val displayPos = if (isUserSeeking) (seekFraction * durationMs).toLong() else currentPositionMs
            Text(
                text = formatTimestamp(displayPos),
                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Medium),
                color = TextSecondary
            )
            Text(
                text = formatTimestamp(durationMs),
                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Medium),
                color = TextSecondary
            )
        }
    }
}

private fun formatTimestamp(ms: Long): String {
    val totalSeconds = (ms / 1000).coerceAtLeast(0)
    val minutes = totalSeconds / 60
    val seconds = totalSeconds % 60
    return "%02d:%02d".format(minutes, seconds)
}
