package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.parser.M3uParser
import com.example.model.Track
import com.example.ui.components.TagEditorDialog
import com.example.ui.theme.*
import com.example.viewmodel.ResonanceViewModel
import java.io.File

@Composable
fun FolderBrowserScreen(
    viewModel: ResonanceViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val currentPath by viewModel.currentFolderPath.collectAsState()
    val folderNodes by viewModel.folderNodes.collectAsState()
    val allTracks by viewModel.allTracks.collectAsState()
    val filterSettings by viewModel.filterSettings.collectAsState()

    var editingTrack by remember { mutableStateOf<Track?>(null) }
    var showFilterSheet by remember { mutableStateOf(false) }

    // Filter tracks belonging to current folder or display all
    val folderTracks = remember(currentPath, allTracks) {
        val tracksInDir = allTracks.filter { it.filePath.startsWith(currentPath) }
        if (tracksInDir.isNotEmpty()) tracksInDir else allTracks
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(AmoledBlack)
            .padding(horizontal = 16.dp, vertical = 10.dp)
    ) {
        // Top Breadcrumb & Storage Path Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(14.dp))
                .background(Color(0xFF0E121B))
                .border(1.dp, Color(0xFF1E2536), RoundedCornerShape(14.dp))
                .padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                IconButton(
                    onClick = { viewModel.navigateUpFolder() },
                    modifier = Modifier.size(34.dp).testTag("folder_up_btn")
                ) {
                    Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Up", tint = ResonanceCyan)
                }
                Spacer(modifier = Modifier.width(6.dp))
                Column {
                    Text(
                        text = "Directory Path",
                        style = MaterialTheme.typography.labelSmall,
                        color = TextMuted
                    )
                    Text(
                        text = currentPath,
                        style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold),
                        color = Color.White,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            // Quick Filters Button
            IconButton(
                onClick = { showFilterSheet = true },
                modifier = Modifier
                    .clip(CircleShape)
                    .background(Color(0xFF1B2232))
                    .testTag("filter_settings_btn")
            ) {
                Icon(imageVector = Icons.Default.Tune, contentDescription = "Filter", tint = ResonanceAmber)
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Actions Row (Scan Refresh, Export M3U8 Playlist)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "${folderTracks.size} Audio Files (${filterSettings.minDurationSecs}s+ filter)",
                style = MaterialTheme.typography.labelMedium,
                color = TextSecondary
            )

            Row {
                TextButton(
                    onClick = {
                        val exportFile = File(context.cacheDir, "Resonance_Queue.m3u8")
                        val success = M3uParser.exportToM3u8("Resonance Playlist", folderTracks, exportFile)
                        if (success) {
                            Toast.makeText(context, "Exported .m3u8 to ${exportFile.name}", Toast.LENGTH_SHORT).show()
                        }
                    },
                    modifier = Modifier.testTag("export_m3u8_btn")
                ) {
                    Icon(imageVector = Icons.Default.FileDownload, contentDescription = null, modifier = Modifier.size(16.dp), tint = ResonanceCyan)
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Export .M3U8", color = ResonanceCyan, fontSize = 11.sp)
                }

                IconButton(
                    onClick = { viewModel.refreshLibraryScan() },
                    modifier = Modifier.testTag("refresh_scan_btn")
                ) {
                    Icon(imageVector = Icons.Default.Refresh, contentDescription = "Rescan", tint = TextSecondary)
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Folder & Track Lazy List
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // Subdirectories in current folder
            items(folderNodes) { node ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0xFF0A0D15))
                        .border(1.dp, Color(0xFF19202E), RoundedCornerShape(12.dp))
                        .clickable { viewModel.refreshFolderHierarchy(node.path) }
                        .padding(horizontal = 12.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Folder,
                        contentDescription = null,
                        tint = if (node.isBlacklisted) Color(0xFFFF5252) else ResonanceCyan,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = node.name,
                            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
                            color = Color.White
                        )
                        Text(
                            text = if (node.isBlacklisted) "Blacklisted (Ignored)" else "${node.trackCount} tracks",
                            style = MaterialTheme.typography.labelSmall,
                            color = if (node.isBlacklisted) Color(0xFFFF5252) else TextSecondary
                        )
                    }

                    // Blacklist toggle button
                    IconButton(
                        onClick = { viewModel.toggleFolderBlacklist(node.path) },
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            imageVector = if (node.isBlacklisted) Icons.Default.Block else Icons.Default.CheckCircle,
                            contentDescription = "Toggle Blacklist",
                            tint = if (node.isBlacklisted) Color(0xFFFF5252) else Color(0xFF384358),
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }

            // Audio Tracks in folder
            items(folderTracks) { track ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0xFF0E121B))
                        .clickable { viewModel.playTrackFromLibrary(track) }
                        .padding(horizontal = 12.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Audio Format Badge
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (track.format == "FLAC") Color(0xFF00333D) else Color(0xFF1E2536)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = track.format,
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, fontSize = 10.sp),
                            color = if (track.format == "FLAC") ResonanceCyan else ResonanceAmber
                        )
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = track.title,
                            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
                            color = Color.White,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = "${track.artist} • ${track.formattedDuration}",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }

                    // Enqueue Next action
                    IconButton(
                        onClick = {
                            viewModel.enqueueNext(track)
                            Toast.makeText(context, "Added '${track.title}' to play next", Toast.LENGTH_SHORT).show()
                        },
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(imageVector = Icons.Default.PlaylistAdd, contentDescription = "Play Next", tint = ResonanceCyan, modifier = Modifier.size(18.dp))
                    }

                    // ID3 Tag Editor action
                    IconButton(
                        onClick = { editingTrack = track },
                        modifier = Modifier.size(32.dp).testTag("edit_tag_track_${track.id}")
                    ) {
                        Icon(imageVector = Icons.Default.Edit, contentDescription = "Edit Tags", tint = TextSecondary, modifier = Modifier.size(18.dp))
                    }
                }
            }
        }
    }

    // Filter Settings Bottom Sheet Dialog
    if (showFilterSheet) {
        AlertDialog(
            onDismissRequest = { showFilterSheet = false },
            title = { Text("Folder Filters & Whitelisting", color = Color.White) },
            text = {
                Column {
                    Text(
                        text = "Min-Duration Filter (Hide voice notes & ringtones):",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf(0, 30, 60, 120).forEach { secs ->
                            val isSel = filterSettings.minDurationSecs == secs
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (isSel) ResonanceCyan else Color(0xFF1E2536))
                                    .clickable { viewModel.updateMinDuration(secs) }
                                    .padding(vertical = 8.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = if (secs == 0) "All" else "${secs}s+",
                                    color = if (isSel) AmoledBlack else TextPrimary,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Text(
                        text = "Ignored Blacklists: /WhatsApp, /Notifications, /Ringtones, /Voice Notes",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color(0xFFFF8A80)
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = { showFilterSheet = false },
                    colors = ButtonDefaults.buttonColors(containerColor = ResonanceCyan)
                ) {
                    Text("Apply", color = Color.Black)
                }
            },
            containerColor = Color(0xFF0F1420)
        )
    }

    // ID3 Tag Editor Modal
    editingTrack?.let { track ->
        TagEditorDialog(
            track = track,
            onSave = { targetTrack, metadata ->
                viewModel.saveTrackMetadata(targetTrack, metadata)
                editingTrack = null
                Toast.makeText(context, "Saved updated metadata", Toast.LENGTH_SHORT).show()
            },
            onDismiss = { editingTrack = null }
        )
    }
}
