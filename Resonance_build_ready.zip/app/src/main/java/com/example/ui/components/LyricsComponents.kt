package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.model.LrcLine
import com.example.ui.theme.*
import kotlinx.coroutines.launch

@Composable
fun LyricsView(
    lyrics: List<LrcLine>,
    currentPositionMs: Long,
    offsetMs: Long,
    onSeekToTimestamp: (Long) -> Unit,
    onAdjustOffset: (Long) -> Unit,
    onOpenLrcCreator: () -> Unit,
    modifier: Modifier = Modifier
) {
    val effectivePos = currentPositionMs + offsetMs
    val listState = rememberLazyListState()
    val coroutineScope = rememberCoroutineScope()

    // Find active line
    val activeIndex = remember(effectivePos, lyrics) {
        val idx = lyrics.indexOfLast { it.timeMs <= effectivePos }
        if (idx >= 0) idx else 0
    }

    LaunchedEffect(activeIndex) {
        if (lyrics.isNotEmpty() && activeIndex in lyrics.indices) {
            coroutineScope.launch {
                listState.animateScrollToItem(activeIndex)
            }
        }
    }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(Color(0xFF090C12))
            .border(1.dp, Color(0xFF1B2332), RoundedCornerShape(18.dp))
            .padding(14.dp)
            .testTag("lyrics_view")
    ) {
        // Lyrics Header with Offset adjustment and Syncer trigger
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Synced Lyrics (.lrc)",
                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                color = Color.White
            )

            Row(verticalAlignment = Alignment.CenterVertically) {
                // Offset Adjustment Buttons (+ / - 50ms)
                IconButton(
                    onClick = { onAdjustOffset(-50L) },
                    modifier = Modifier.size(32.dp).testTag("lyric_offset_minus_btn")
                ) {
                    Icon(imageVector = Icons.Default.Remove, contentDescription = "-50ms", tint = TextSecondary, modifier = Modifier.size(16.dp))
                }
                Text(
                    text = "${offsetMs}ms",
                    style = MaterialTheme.typography.labelSmall,
                    color = if (offsetMs != 0L) ResonanceAmber else TextSecondary
                )
                IconButton(
                    onClick = { onAdjustOffset(50L) },
                    modifier = Modifier.size(32.dp).testTag("lyric_offset_plus_btn")
                ) {
                    Icon(imageVector = Icons.Default.Add, contentDescription = "+50ms", tint = TextSecondary, modifier = Modifier.size(16.dp))
                }

                Spacer(modifier = Modifier.width(6.dp))

                // Built-in LRC syncer tool button
                IconButton(
                    onClick = onOpenLrcCreator,
                    modifier = Modifier
                        .size(32.dp)
                        .clip(CircleShape)
                        .background(Color(0xFF1B2232))
                        .testTag("open_lrc_creator_btn")
                ) {
                    Icon(
                        imageVector = Icons.Default.EditNote,
                        contentDescription = "Sync Lyrics Creator",
                        tint = ResonanceCyan,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        if (lyrics.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(120.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "No synced lyrics found.\nTap edit icon above to paste and stamp line timestamps!",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextMuted,
                    textAlign = TextAlign.Center
                )
            }
        } else {
            LazyColumn(
                state = listState,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(180.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                itemsIndexed(lyrics) { index, line ->
                    val isActive = index == activeIndex
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (isActive) Color(0xFF101928) else Color.Transparent)
                            .clickable { onSeekToTimestamp(line.timeMs) }
                            .padding(horizontal = 8.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = line.text,
                            style = if (isActive) MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold) else MaterialTheme.typography.bodyMedium,
                            color = if (isActive) ResonanceCyan else TextSecondary,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun LyricsCreatorDialog(
    currentPositionMs: Long,
    onSaveLyrics: (String) -> Unit,
    onDismiss: () -> Unit
) {
    var rawText by remember { mutableStateOf("") }
    var stampedLines by remember { mutableStateOf<List<Pair<Long, String>>>(emptyList()) }
    var currentLineIndex by remember { mutableStateOf(0) }

    val unStamptedLines = remember(rawText) {
        rawText.lines().map { it.trim() }.filter { it.isNotBlank() }
    }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = Color(0xFF0F131C),
            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF252E40)),
            modifier = Modifier.fillMaxWidth().padding(8.dp)
        ) {
            Column(modifier = Modifier.padding(18.dp)) {
                Text(
                    text = "Offline LRC Syncer / Creator",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = Color.White
                )
                Text(
                    text = "Listen to track & tap 'Stamp Line' at each sentence to build an accurate .lrc file",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary
                )

                Spacer(modifier = Modifier.height(12.dp))

                if (unStamptedLines.isEmpty()) {
                    OutlinedTextField(
                        value = rawText,
                        onValueChange = { rawText = it },
                        label = { Text("Paste Plain Lyrics Here") },
                        placeholder = { Text("First line of song...\nSecond line...") },
                        modifier = Modifier.fillMaxWidth().height(160.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextSecondary,
                            focusedBorderColor = ResonanceCyan,
                            unfocusedBorderColor = Color(0xFF283144)
                        )
                    )
                } else {
                    // Stamping Mode
                    Text(
                        text = "Next Line to Stamp (${currentLineIndex + 1}/${unStamptedLines.size}):",
                        style = MaterialTheme.typography.labelSmall,
                        color = ResonanceAmber
                    )
                    val nextLine = unStamptedLines.getOrNull(currentLineIndex) ?: "All lines stamped!"
                    Text(
                        text = "\"$nextLine\"",
                        style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.SemiBold),
                        color = Color.White,
                        modifier = Modifier.padding(vertical = 8.dp)
                    )

                    Button(
                        onClick = {
                            if (currentLineIndex < unStamptedLines.size) {
                                stampedLines = stampedLines + Pair(currentPositionMs, unStamptedLines[currentLineIndex])
                                currentLineIndex++
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = ResonanceCyan),
                        modifier = Modifier.fillMaxWidth().testTag("stamp_current_line_btn")
                    ) {
                        Text("Stamp Line at Current Position", color = Color.Black, fontWeight = FontWeight.Bold)
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    TextButton(onClick = onDismiss) {
                        Text("Cancel", color = TextSecondary)
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = {
                            val output = buildString {
                                for ((ms, line) in stampedLines) {
                                    val totalSec = ms / 1000
                                    val min = totalSec / 60
                                    val sec = totalSec % 60
                                    val hundredths = (ms % 1000) / 10
                                    append(String.format("[%02d:%02d.%02d]%s\n", min, sec, hundredths, line))
                                }
                            }
                            onSaveLyrics(output)
                        },
                        enabled = stampedLines.isNotEmpty(),
                        colors = ButtonDefaults.buttonColors(containerColor = ResonanceAmber)
                    ) {
                        Text("Save .LRC File", color = Color.Black, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

/**
 * Full-screen immersive synchronized lyrics view matching the video.
 */
@Composable
fun FullScreenSyncedLyricsView(
    lyrics: List<LrcLine>,
    currentPositionMs: Long,
    offsetMs: Long,
    trackTitle: String,
    trackArtist: String,
    isPlaying: Boolean,
    accentColor: Color,
    onSeekToTimestamp: (Long) -> Unit,
    onTogglePlayPause: () -> Unit,
    onAdjustOffset: (Long) -> Unit,
    onOpenLrcCreator: () -> Unit,
    onClose: () -> Unit,
    modifier: Modifier = Modifier
) {
    val effectivePos = currentPositionMs + offsetMs
    val listState = rememberLazyListState()
    val coroutineScope = rememberCoroutineScope()

    val activeIndex = remember(effectivePos, lyrics) {
        val idx = lyrics.indexOfLast { it.timeMs <= effectivePos }
        if (idx >= 0) idx else 0
    }

    LaunchedEffect(activeIndex) {
        if (lyrics.isNotEmpty() && activeIndex in lyrics.indices) {
            coroutineScope.launch {
                listState.animateScrollToItem((activeIndex - 2).coerceAtLeast(0))
            }
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(AmoledBlack)
            .testTag("fullscreen_lyrics_view")
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 20.dp, vertical = 12.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onClose,
                    modifier = Modifier
                        .size(42.dp)
                        .clip(CircleShape)
                        .background(DarkSurface2)
                        .border(1.dp, HairlineBorder, CircleShape)
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Close Lyrics",
                        tint = TextPrimary,
                        modifier = Modifier.size(22.dp)
                    )
                }

                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.weight(1f).padding(horizontal = 8.dp)) {
                    Text(
                        text = trackTitle,
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = TextPrimary,
                        maxLines = 1,
                        textAlign = TextAlign.Center
                    )
                    Text(
                        text = "Synchronized Lyrics",
                        style = MaterialTheme.typography.labelSmall,
                        color = accentColor
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = { onAdjustOffset(-50L) },
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Remove, contentDescription = "-50ms", tint = TextSecondary, modifier = Modifier.size(16.dp))
                    }
                    Text(
                        text = "${offsetMs}ms",
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.SemiBold),
                        color = if (offsetMs != 0L) ChampagneGold else TextSecondary
                    )
                    IconButton(
                        onClick = { onAdjustOffset(50L) },
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Add, contentDescription = "+50ms", tint = TextSecondary, modifier = Modifier.size(16.dp))
                    }
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            if (lyrics.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "No synced lyrics available for this song.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = TextSecondary,
                            textAlign = TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(14.dp))
                        Button(
                            onClick = onOpenLrcCreator,
                            colors = ButtonDefaults.buttonColors(containerColor = accentColor)
                        ) {
                            Icon(imageVector = Icons.Default.EditNote, contentDescription = null, tint = Color.Black)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Create / Time-Stamp Lyrics", color = Color.Black, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            } else {
                LazyColumn(
                    state = listState,
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentPadding = PaddingValues(vertical = 40.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    itemsIndexed(lyrics) { index, line ->
                        val isActive = index == activeIndex
                        Text(
                            text = line.text,
                            style = if (isActive) {
                                MaterialTheme.typography.headlineSmall.copy(
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 24.sp,
                                    lineHeight = 32.sp
                                )
                            } else {
                                MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Medium,
                                    fontSize = 18.sp,
                                    lineHeight = 26.sp
                                )
                            },
                            color = if (isActive) TextPrimary else TextSecondary.copy(alpha = 0.55f),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onSeekToTimestamp(line.timeMs) }
                                .padding(vertical = 4.dp)
                        )
                    }
                }
            }

            // Floating Mini-Playback Bottom Controller Card
            Surface(
                shape = RoundedCornerShape(22.dp),
                color = DarkSurface2,
                border = androidx.compose.foundation.BorderStroke(1.dp, HairlineBorder),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Box(
                        modifier = Modifier
                            .size(42.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(accentColor.copy(alpha = 0.2f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.MusicNote,
                            contentDescription = null,
                            tint = accentColor,
                            modifier = Modifier.size(24.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = trackTitle,
                            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                            color = TextPrimary,
                            maxLines = 1
                        )
                        Text(
                            text = trackArtist,
                            style = MaterialTheme.typography.labelSmall,
                            color = accentColor,
                            maxLines = 1
                        )
                    }

                    FlowerPlayButton(
                        isPlaying = isPlaying,
                        onClick = onTogglePlayPause,
                        size = 46.dp,
                        containerColor = Color.White,
                        contentColor = Color.Black
                    )
                }
            }
        }
    }
}

