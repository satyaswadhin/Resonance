package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.Bedtime
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.model.Track
import com.example.ui.theme.*

/**
 * Modern expanded song context menu bottom sheet / modal
 * matching the video with top quick actions (Radio, Add, Share)
 * and comprehensive actions.
 */
@Composable
fun TrackActionBottomSheet(
    track: Track,
    accentColor: Color,
    onCutAudio: () -> Unit,
    onRename: () -> Unit,
    onDelete: () -> Unit,
    onEditTags: () -> Unit,
    onInspectInfo: () -> Unit,
    onPlayNext: () -> Unit,
    onAddToQueue: () -> Unit,
    onDismiss: () -> Unit,
    onShowLyrics: (() -> Unit)? = null,
    onSetSleepTimer: (() -> Unit)? = null
) {
    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(26.dp),
            color = DarkSurface1,
            border = androidx.compose.foundation.BorderStroke(1.dp, HairlineBorder),
            modifier = Modifier
                .fillMaxWidth()
                .padding(4.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                // Track Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(50.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .background(accentColor.copy(alpha = 0.22f))
                            .border(1.dp, accentColor.copy(alpha = 0.4f), RoundedCornerShape(14.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.MusicNote,
                            contentDescription = null,
                            tint = accentColor,
                            modifier = Modifier.size(26.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(14.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = track.title,
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = Color.White,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = "${track.artist} • ${track.audioQualityBadge}",
                            style = MaterialTheme.typography.bodySmall,
                            color = accentColor,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }

                    IconButton(onClick = onDismiss, modifier = Modifier.size(32.dp)) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = TextSecondary, modifier = Modifier.size(20.dp))
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Top 3 Quick Action Buttons as in Video: [Radio] [Add] [Share]
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    QuickActionButton(
                        icon = Icons.Default.Radio,
                        label = "Radio",
                        modifier = Modifier.weight(1f),
                        accentColor = accentColor,
                        onClick = {
                            onDismiss()
                            onPlayNext()
                        }
                    )
                    QuickActionButton(
                        icon = Icons.Default.PlaylistAdd,
                        label = "Add",
                        modifier = Modifier.weight(1f),
                        accentColor = accentColor,
                        onClick = {
                            onDismiss()
                            onAddToQueue()
                        }
                    )
                    QuickActionButton(
                        icon = Icons.Default.Share,
                        label = "Share",
                        modifier = Modifier.weight(1f),
                        accentColor = accentColor,
                        onClick = {
                            onDismiss()
                            // Share intent can be opened or toast
                        }
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))
                HorizontalDivider(color = Color(0xFF1E283C), thickness = 1.dp)
                Spacer(modifier = Modifier.height(10.dp))

                // Action 1: Clideo Audio Cutter / Trimmer (Featured)
                ActionItemRow(
                    title = "Cut / Trim Music (Clideo Editor)",
                    subtitle = "Trim start/end, extract or delete sections with waveform",
                    icon = Icons.Default.ContentCut,
                    iconColor = Color(0xFF1E88E5),
                    containerColor = Color(0x221E88E5),
                    tag = "action_cut_audio",
                    onClick = {
                        onDismiss()
                        onCutAudio()
                    }
                )

                // Action 2: Rename File & Track
                ActionItemRow(
                    title = "Rename Music File",
                    subtitle = "Change file name on disk and track title",
                    icon = Icons.Default.DriveFileRenameOutline,
                    iconColor = accentColor,
                    tag = "action_rename_file",
                    onClick = {
                        onDismiss()
                        onRename()
                    }
                )

                // Action 3: Delete File Permanently
                ActionItemRow(
                    title = "Delete Music File",
                    subtitle = "Permanently remove audio file from device storage",
                    icon = Icons.Default.DeleteOutline,
                    iconColor = Color(0xFFFF5252),
                    containerColor = Color(0x1AFF5252),
                    tag = "action_delete_file",
                    onClick = {
                        onDismiss()
                        onDelete()
                    }
                )

                // Action 4: Edit ID3 Tags
                ActionItemRow(
                    title = "Edit ID3 / Metadata Tags",
                    subtitle = "Edit title, artist, album, genre, year headers",
                    icon = Icons.Default.Edit,
                    iconColor = TextSecondary,
                    tag = "action_edit_tags",
                    onClick = {
                        onDismiss()
                        onEditTags()
                    }
                )

                // Action 5: Audio File Inspector
                ActionItemRow(
                    title = "Audio File Inspector (Pi Info)",
                    subtitle = "View exact bit depth, sample rate, bitrate & path",
                    icon = Icons.Default.Info,
                    iconColor = TextSecondary,
                    tag = "action_inspect_file",
                    onClick = {
                        onDismiss()
                        onInspectInfo()
                    }
                )

                // Action 6: Play Next
                ActionItemRow(
                    title = "Play Next",
                    subtitle = "Queue this track immediately after current song",
                    icon = Icons.Default.PlaylistPlay,
                    iconColor = TextSecondary,
                    tag = "action_play_next",
                    onClick = {
                        onDismiss()
                        onPlayNext()
                    }
                )

                // Action 7: Add to Queue
                ActionItemRow(
                    title = "Add to Queue",
                    subtitle = "Append track to current playback queue",
                    icon = Icons.Default.QueueMusic,
                    iconColor = TextSecondary,
                    tag = "action_add_to_queue",
                    onClick = {
                        onDismiss()
                        onAddToQueue()
                    }
                )

                // Action 8: Show Lyrics
                onShowLyrics?.let { showLyricsAction ->
                    ActionItemRow(
                        title = "Show Lyrics",
                        subtitle = "View synchronized scrolling LRC lyrics",
                        icon = Icons.Default.Mic,
                        iconColor = accentColor,
                        tag = "action_show_lyrics",
                        onClick = {
                            onDismiss()
                            showLyricsAction()
                        }
                    )
                }

                // Action 9: Sleep Timer
                onSetSleepTimer?.let { timerAction ->
                    ActionItemRow(
                        title = "Sleep Timer",
                        subtitle = "Schedule automatic playback pause",
                        icon = Icons.Outlined.Bedtime,
                        iconColor = TextSecondary,
                        tag = "action_sleep_timer",
                        onClick = {
                            onDismiss()
                            timerAction()
                        }
                    )
                }
            }
        }
    }
}

@Composable
private fun QuickActionButton(
    icon: ImageVector,
    label: String,
    modifier: Modifier = Modifier,
    accentColor: Color,
    onClick: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(16.dp),
        color = DarkSurface2,
        border = androidx.compose.foundation.BorderStroke(1.dp, HairlineBorder),
        modifier = modifier
            .clickable { onClick() }
    ) {
        Column(
            modifier = Modifier.padding(vertical = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(imageVector = icon, contentDescription = label, tint = TextPrimary, modifier = Modifier.size(22.dp))
            Spacer(modifier = Modifier.height(4.dp))
            Text(text = label, style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.SemiBold), color = TextSecondary)
        }
    }
}

@Composable
private fun ActionItemRow(
    title: String,
    subtitle: String,
    icon: ImageVector,
    iconColor: Color,
    containerColor: Color = Color.Transparent,
    tag: String,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(containerColor)
            .clickable { onClick() }
            .padding(horizontal = 8.dp, vertical = 9.dp)
            .testTag(tag),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(38.dp)
                .clip(CircleShape)
                .background(DarkSurface2)
                .border(1.dp, HairlineBorder, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Icon(imageVector = icon, contentDescription = null, tint = iconColor, modifier = Modifier.size(20.dp))
        }

        Spacer(modifier = Modifier.width(12.dp))

        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
                color = TextPrimary
            )
            Text(
                text = subtitle,
                style = MaterialTheme.typography.labelSmall,
                color = TextSecondary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}
