package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.parser.AutoEqParser
import com.example.data.parser.FolderScanner
import com.example.data.parser.LrcParser
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Resonance", appName)
    }

    @Test
    fun `test multi value artist delimiter splitting`() {
        val raw = "Pink Floyd; David Gilmour / Roger Waters & Richard Wright"
        val artists = FolderScanner.splitMultiValues(raw)
        assertTrue(artists.contains("Pink Floyd"))
        assertTrue(artists.contains("David Gilmour"))
        assertTrue(artists.contains("Roger Waters"))
        assertTrue(artists.contains("Richard Wright"))
    }

    @Test
    fun `test lrc parser with word timestamps`() {
        val lrc = """
            [00:15.50]First line of high resolution music
            [00:22.00]<00:22.00>Word1 <00:22.50>Word2 <00:23.00>Word3
        """.trimIndent()
        val lines = LrcParser.parse(lrc)
        assertEquals(2, lines.size)
        assertEquals(15500L, lines[0].timeMs)
        assertEquals(22000L, lines[1].timeMs)
        assertEquals(3, lines[1].words.size)
    }

    @Test
    fun `test autoeq profile parsing`() {
        val rawGraphicEq = "GraphicEQ: 31 2.5; 62 3.0; 125 1.5; 1000 -1.0; 8000 2.0"
        val profile = AutoEqParser.parseAutoEqText(rawGraphicEq, "TestProfile")
        assertEquals("TestProfile", profile.name)
        assertEquals(2.5f, profile.graphicBandGains[31] ?: 0f, 0.1f)
    }
}
