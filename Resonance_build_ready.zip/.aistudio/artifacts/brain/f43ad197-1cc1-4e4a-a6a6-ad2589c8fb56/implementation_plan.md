# Resonance: Pure Offline Hi-Res Music Player

Resonance is a deterministic, privacy-first local audio player engineered exclusively for offline high-resolution playback, true folder-hierarchy browsing, studio-grade DSP equalizer with AutoEQ profile support, synchronized lyrics, tactile mechanical skins, and intelligent sleep/bedtime automation.

---

> [!IMPORTANT]
> **User Clarifications & Design Direction Confirmed:**
> - **Default Player Screen:** Configured to launch in **Sleep & Bedtime Mode** by default, placing the fade-out sleep timer, ambient dimmed controls, and "finish last song before sleep" toggle front and center, while allowing seamless one-tap switching to AMOLED Glassmorphism, Retro Vinyl Platter, Analog Cassette Deck, and Chronograph scrubber views.
> - **File Discovery & Scanners:** Dual-mode architecture combining Android MediaStore discovery and direct Storage Access Framework (SAF) tree traversal to browse true disk paths (`/Internal Storage/Music/...`), honoring folder whitelists, blacklists, and minimum track duration filters (e.g. ignoring audio < 30s).
> - **Audio Engine & DSP:** Deterministic 10-band Graphic EQ coupled with Parametric EQ (filter types: Peak, Low-Shelf, High-Shelf, Band-Pass with exact Hz, gain dB, and Q-factor), AutoEQ preset importing, independent pitch and tempo shift, ReplayGain volume normalization, and channel balance.

---

## 1. Overview & Core Concept

- **What It Does**: A standalone, ad-free music workstation that plays local audio files (FLAC, ALAC, WAV, MP3, AAC, OGG, Opus) directly from device storage without internet access or telemetry.
- **Target Audience**: Audiophiles, album purists, students, and night-time listeners who demand studio sound quality, gapless playback, precise tag editing, synced lyrics creation, and battery-efficient bedtime audio controls.
- **Key Value**: Direct disk-level control without cluttered ringtones or voice memos, zero online distractions, and tactile retro audio hardware aesthetics.

---

## 2. User Experience & Visual Design

### Key User Flows

```
┌────────────────────────────────────────────────────────────────────────┐
│                        App Navigation Bar                              │
├─────────────────┬──────────────────┬─────────────────┬─────────────────┤
│  1. Now Playing │ 2. Library &     │ 3. Equalizer    │ 4. Analytics    │
│     & Sleep Hub │    Folder Tree   │    & DSP Studio │    & Playlists  │
└─────────────────┴──────────────────┴─────────────────┴─────────────────┘
```

1. **Sleep & Now Playing Hub (Default)**:
   - Floating header with Sleep Timer status (e.g., "Pauses in 28 min • Finishing track").
   - Quick timer wheel presets (15m, 30m, 45m, 60m, Custom) with gentle 60-second fade-out curve.
   - Real-time amplitude waveform seekbar with draggable A–B looping flags.
   - Dynamic skin switcher:
     - **Sleep Minimalist**: True pitch-black AMOLED (#000000) with dimmed glowing typography.
     - **Glassmorphic Modern**: Dynamic blur overlays sampled from album artwork via Median Cut color quantization.
     - **Retro Vinyl Platter**: Smooth 33⅓ RPM rotating record with a draggable tonearm needle for scratching/scrubbing.
     - **Dual-Reel Analog Cassette**: Animated spinning tape reels with tape counter readout.
     - **Mechanical Chronograph**: Rotary brushed-metal dial for fine-grained scrub control.
   - Tap-to-seek synchronized lyrics overlay with millisecond offset adjustment and built-in timestamp syncer.

2. **Folder-Hierarchy Browser & Library**:
   - Breadcrumb navigation (`Root > Music > Hi-Res > FLAC`) showing real folder structure.
   - Whitelist & Blacklist directory manager (e.g., exclude `WhatsApp Audio`, `Notifications`, `Recordings`).
   - Duration filter slider (e.g., hide clips < 30s or < 60s).
   - Multi-value delimiter parsing (splits artists like `Artist A / Artist B` or `Rock; Indie` into separate profiles).
   - Lossless CUE sheet virtual splitter: parses `.cue` sheet files to present multi-track albums without altering source `.flac`.
   - Batch offline ID3 tag editor: edit Title, Artist, Album, Genre, Year, Track/Disc numbers directly.
   - M3U / M3U8 / PLS playlist import & export to storage.

3. **Parametric & Graphic EQ Studio**:
   - 10-band graphic equalizer with preamp slider (-12dB to +12dB).
   - Parametric EQ band manager: Add custom parametric peak, low-shelf, and high-shelf filters with custom Q-factor and frequency.
   - AutoEQ `.txt` and `.csv` curve importer with output device binding (Wired 3.5mm, USB DAC, Bluetooth, Speaker).
   - Real-time Pitch & Tempo DSP: independent speed (0.25x – 3.0x) and pitch adjustment (-12 to +12 semitones) or linked tape mode.
   - ReplayGain normalization reader (`REPLAYGAIN_TRACK_GAIN` / `ALBUM_GAIN`) with target dB calibration and Left/Right balance slider.

4. **Offline Listening Analytics & Rule-Based Smart Playlists**:
   - Device-local SQLite / Room analytics: Total listening hours, play counts, skip counts, weekly top artists/tracks.
   - Smart playlist rule builder (e.g. `Genre == 'Jazz' AND Bitrate >= 320 AND PlayCount > 5`).
   - JSON / CSV export for listening history.

### Visual Identity & Theme Tokens

- **Aesthetic Direction**: High-craft utilitarian luxury, pitch-black deep AMOLED (#000000) with vibrant dynamic accent tints.
- **Palette Tokens**:
  - `Background`: `#000000` (Pure pitch-black for AMOLED power saving)
  - `Surface`: `#0D0E12` (Subtle smoky obsidian)
  - `SurfaceVariant`: `#161820` (Tactile panel card)
  - `Primary Accent`: `#00E5FF` (Precision cyan glow)
  - `Secondary Accent`: `#FF9100` (Warm amber vacuum tube glow)
  - `Text Primary`: `#F0F2F5` / `Text Secondary`: `#8E929E`
- **Typography**: Clean monospace readouts for sample rate/bitrate badges (`24-bit / 96 kHz FLAC`), high-contrast modern sans-serif for track titles and folder paths.

---

## 3. Key Product Decisions & Trade-Offs

- **Decision 1: Sleep Mode Default Experience**
  - *Chosen Approach*: The primary player screen opens directly into the Sleep & Bedtime mode with the sleep timer, ambient low-light controls, and "finish last song" toggle immediately accessible, with persistent toggles to change the skin.
  - *Why*: Directly aligns with user preference while preserving rapid access to the full-featured player and library.
- **Decision 2: Audio Engine Architecture (Media3 + Android AudioTrack & System DSP)**
  - *Chosen Approach*: Leverage Android `MediaPlayer` / `AudioTrack` paired with `AudioEffect` (System Equalizer, Environmental Reverb, BassBoost) and software DSP processors (pitch/tempo scaling, ReplayGain software scaling, crossfade volume ramping coroutines, and gapless dual-player pre-buffering).
  - *Why*: Guaranteed bit-exact compatibility across Android 7.0–15 without requiring native NDK compilation issues in the container, while delivering gapless transitions and pitch/tempo shifting.
- **Decision 3: Offline Data & Analytics Persistence (Room Database)**
  - *Chosen Approach*: Use Android Room with KSP to store folder whitelist/blacklist rules, play analytics, smart playlist queries, and cached metadata, leaving audio files untouched except when the user explicitly triggers the ID3 Tag Editor.
  - *Why*: Instantaneous query performance, zero battery drain from re-parsing thousands of tags on disk, and reactive Flow updates.

---

## 4. Technical Architecture & Data Strategy

### System Component Diagram

```
┌────────────────────────────────────────────────────────────────────────┐
│                        Jetpack Compose UI Layer                        │
├─────────────────┬──────────────────┬─────────────────┬─────────────────┤
│ Sleep & Player  │ Folder Browser & │ Studio EQ &     │ Smart Playlists │
│ Screen (Skins)  │ Tag Editor View  │ DSP Studio View │ & Analytics     │
└────────┬────────┴────────┬─────────┴────────┬────────┴────────┬────────┘
         │                 │                  │                 │
┌────────▼─────────────────▼──────────────────▼─────────────────▼────────┐
│               ResonancePlayerViewModel (MVVM StateFlow)                │
└────────────────────────────────────┬───────────────────────────────────┘
                                     │
┌────────────────────────────────────▼───────────────────────────────────┐
│                     ResonanceAudioEngineService                        │
│  ┌───────────────────────┬──────────────────────┬───────────────────┐  │
│  │ Dual-Player Gapless   │ Crossfade Ramping    │ Pitch & Tempo DSP │  │
│  │ Preload & Playback    │ Coroutine Engine     │ (Sonic/Playback)  │  │
│  ├───────────────────────┼──────────────────────┼───────────────────┤  │
│  │ 10-Band Graphic &     │ ReplayGain Parser    │ Lock-Screen Media │  │
│  │ Parametric EQ Module  │ & Balance Controller │ Notification      │  │
│  └───────────────────────┴──────────────────────┴───────────────────┘  │
└────────────────────────────────────┬───────────────────────────────────┘
                                     │
┌────────────────────────────────────▼───────────────────────────────────┐
│                     Storage & Persistence Layer                        │
│  ┌───────────────────────────────┬───────────────────────────────────┐ │
│  │ Room Database:                │ Local File System & MediaStore:   │ │
│  │ • Tracks & Play History       │ • SAF Folder Tree Traversal       │ │
│  │ • Whitelist / Blacklist Rules │ • ID3v2 & Vorbis Tag Parser       │ │
│  │ • Smart Playlist SQL Engine   │ • LRC / Enhanced LRC Synced Files │ │
│  │ • AutoEQ Presets & Output Map │ • M3U / M3U8 Playlist File I/O    │ │
│  └───────────────────────────────┴───────────────────────────────────┘ │
└────────────────────────────────────────────────────────────────────────┘
```

### Key Data Entities & State Flows

1. **`Track`**: File URI, disk path, title, artist, album, duration, bitrate, sample rate, bit depth, format (FLAC, MP3, etc.), replayGainTrack, replayGainAlbum, cueSheetUri, embeddedArtworkUri.
2. **`SleepTimerConfig`**: Remaining seconds, isActive, finishLastSongFirst, fadeOutDurationSeconds (default 60s), initialVolume.
3. **`EqConfig`**: Graphic bands (31Hz, 63Hz, 125Hz, 250Hz, 500Hz, 1kHz, 2kHz, 4kHz, 8kHz, 16kHz), preamp dB, parametric filters list (frequency, gain, Q, type), enabled output routing.
4. **`LyricsData`**: List of timestamped lines (`timeMs`, `text`) and word-level timestamps for enhanced karaoke-style lyric highlight.

---

### Step-by-Step Implementation Sequence

1. **Platform Identity & Resources**: Update `metadata.json` and `strings.xml` to "Resonance Music Player", declare required permissions (`READ_MEDIA_AUDIO`, `READ_EXTERNAL_STORAGE`, `FOREGROUND_SERVICE`, `POST_NOTIFICATIONS`) in `AndroidManifest.xml`.
2. **Room Database Layer**: Setup Entities, DAOs, and RoomDatabase for tracks, play analytics, folder rules, and smart playlists.
3. **Audio Engine & Playback Service**: Implement `ResonanceAudioService` supporting foreground playback notification, lock-screen controls, dual-player gapless transitions, crossfade volume ramping, pitch/tempo control, and sleep timer with fade-out.
4. **Equalizer & DSP Engine**: Implement the 10-band graphic EQ and parametric DSP model with AutoEQ profile parsing (.txt/.csv).
5. **Folder & Tag Utilities**: Implement recursive folder hierarchy scanner, whitelist/blacklist filter, min-duration filter, CUE sheet parser, ID3 metadata reader/writer, and M3U/M3U8 parser.
6. **Lyrics & Time-Stamping Engine**: Implement `.lrc` and enhanced word-by-word reader, interactive tap-to-seek, offset corrector, and built-in offline timestamp creator.
7. **Compose UI & Interactive Skins**:
   - Modern AMOLED Glassmorphism player with real-time waveform visualizer and A-B loop markers.
   - Bedtime/Sleep timer control hub with circular timer dial and fade-out switches.
   - Retro Vinyl Platter with spinning vinyl and draggable tonearm.
   - Analog Cassette Deck with spinning reels.
   - Mechanical Chronograph dial.
   - Folder tree file explorer with whitelist/blacklist toggles and breadcrumbs.
   - Equalizer studio screen with interactive sliders, curve visualization, and AutoEQ loader.
   - Smart playlist builder and listening analytics chart view.
8. **Verification**: Run `compile_applet` to guarantee error-free compilation and clean build output.
